import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

/*
 * use the same way as angular official date pipe
 * i.e. {{ dateObj | myDate:'medium' }}      // output is 'Jun 15, 2015, 9:43:11 PM'
 *   - `'short'`: equivalent to `'M/d/yy, h:mm a'` (e.g. `6/15/15, 9:03 AM`)
 *   - `'medium'`: equivalent to `'MMM d, y, h:mm:ss a'` (e.g. `Jun 15, 2015, 9:03:01 AM`)
 *   - `'long'`: equivalent to `'MMMM d, y, h:mm:ss a z'` (e.g. `June 15, 2015 at 9:03:01 AM GMT+1`)
 *   - `'full'`: equivalent to `'EEEE, MMMM d, y, h:mm:ss a zzzz'` (e.g. `Monday, June 15, 2015 at
 * 9:03:01 AM GMT+01:00`)
 *   - `'shortDate'`: equivalent to `'M/d/yy'` (e.g. `6/15/15`)
 *   - `'mediumDate'`: equivalent to `'MMM d, y'` (e.g. `Jun 15, 2015`)
 *   - `'longDate'`: equivalent to `'MMMM d, y'` (e.g. `June 15, 2015`)
 *   - `'fullDate'`: equivalent to `'EEEE, MMMM d, y'` (e.g. `Monday, June 15, 2015`)
 *   - `'shortTime'`: equivalent to `'h:mm a'` (e.g. `9:03 AM`)
 *   - `'mediumTime'`: equivalent to `'h:mm:ss a'` (e.g. `9:03:01 AM`)
 *   - `'longTime'`: equivalent to `'h:mm:ss a z'` (e.g. `9:03:01 AM GMT+1`)
 *   - `'fullTime'`: equivalent to `'h:mm:ss a zzzz'` (e.g. `9:03:01 AM GMT+01:00`)
 *  - `timezone` to be used for formatting. It understands UTC/GMT and the continental US time zone
 *  abbreviations, but for general use, use a time zone offset, for example,
 *  `'+0430'` (4 hours, 30 minutes east of the Greenwich meridian)
 *  If not specified, the local system timezone of the end-user's browser will be used.
 *  - `locale` is a `string` defining the locale to use (uses the current {@link LOCALE_ID} by
 * default)
* */

@Pipe({
    name: 'myDate'
})
export class SafeDatePipe implements PipeTransform {
    constructor(private datePipe: DatePipe) {
    }

    public transform(date: any, format?: any, addDays?: number, timezone?: string): string {
        let result: string;
        let temp: any;
        try {
            if (addDays) {
                date = new Date(date);
                date = new Date(date.setDate(date.getDate() + addDays));
            }
            temp = this.datePipe.transform(date, format, timezone)
            result = temp ? temp : 'Unknown';
        } catch (error) {
            try {
                // safari can't transfer date like this: '2017-10-20 05:33:22.343'
                temp = this.datePipe.transform(date.substr(0, 10), format, timezone);
                result = temp ? temp : 'Unknown'
            } catch (error) {
                result = date;
            }
        }
        return result || 'Unknown';
    }
}

