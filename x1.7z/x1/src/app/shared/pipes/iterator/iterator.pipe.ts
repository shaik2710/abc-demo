import { isEmpty } from 'lodash';
import { Pipe, PipeTransform } from '@angular/core';



@Pipe({
  name: 'iterator'
})

export class IteratorPipe implements PipeTransform {
    public transform(obj: {}, keyRename?: string, valueRename?: string): {}[] {
      const objects = [] ;
      if (obj && !isEmpty(obj)) {
        const keys = Object.keys(obj);
        for(let i=0; i< keys.length; i++) {
          objects.push({[keyRename || 'key']: keys[i], [valueRename || 'value']: keys[i]});
          // objects.push({[keyRename || 'key']: keys[i], [valueRename || 'value']: obj[keys[i]]});
        } 
      }
      return objects;
    }
}
