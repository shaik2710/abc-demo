export const NAME: RegExp = /^[a-zA-ZÀ-úÀ-ÖØ-öø-ÿ'\-\s]*$/;
