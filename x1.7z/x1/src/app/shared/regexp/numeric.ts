export const NUMERIC: RegExp = /[0-9]/;
export const DECIMALSNUMERIC: RegExp = /^\d*\.?\d*$/;
