import { dateInputsHaveChanged } from "@angular/material/datepicker/datepicker-input-base";

export class Sort {
    private sortOrder = 1;
    private collator = new Intl.Collator(undefined, {
        numeric: true,
        sensitivity: "base",
    });

    constructor() {

    }

    public startSort(property: any, order: string, type: string = "" ) {
        if ( order === "desc") {
            this.sortOrder = -1;
        }
        return (a: { [x: string]: string; }, b: { [x: string]: string; }) => {
            if (type === 'date'){
                return this.sortData({ a: new Date(a[property]), b: new Date(b[property]) });
            } 
            else {
                return this.collator.compare(a[property], b[property]) * this.sortOrder;    
            }
        }
    }

    public sortData({ a, b }: { a: any; b: any; }) {
        if (a < b) {
            return -1 * this.sortOrder;
        } else if(a > b) {
            return 1 * this.sortOrder; 
        } else {
            return 0 * this.sortOrder;
        }
    }
}