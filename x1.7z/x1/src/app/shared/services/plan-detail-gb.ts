export class PlanDetailsGB {
    public lineCovgCode?: string | null | undefined;
    public lineCovgDesc?: string | undefined;
    public eligibity?: string | null | undefined;

    constructor(details?: any) {
      if (details) {
        this.lineCovgCode = details.lineCovgCode;
        this.lineCovgDesc = details.lineCovgDesc;
        this.eligibity = details.eligibity;
      }
    }
}
