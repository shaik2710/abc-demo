import { Injectable } from '@angular/core';
import { Observable, throwError, of as observableOf } from 'rxjs';
import { catchError, retry , map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlanDetailsService {

  constructor(private http: HttpClient) { }

  public getStandardPlanPC(): Observable<any> {
    const path = 'https://jsonPlaceholder.typicode.com/users';
    return this.http.get(path)
    .pipe(map( res => {
        return res;
    }), catchError((err) => {
      return observableOf(err);
    }));
  }

  public getStandardPlanGB(): Observable<any> {
    const path = 'https://jsonPlaceholder.typicode.com/users';
    return this.http.get(path)
    .pipe(map( res => {
        return res;
    }), catchError((err) => {
      return observableOf(err);
    }));
  }

  // public getAllTodos(): Observable<Todo[]> {
  //   return this.http
  //     .get(API_URL + '/todos')
  //     .pipe(map(response => {
  //       const todos = response.json();
  //       return todos.map((todo) => new Todo(todo));
  //     }));
  //     .catch(this.handleError);
  // }
}
