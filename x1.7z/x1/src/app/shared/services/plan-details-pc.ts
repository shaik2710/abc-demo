export class PlanDetailsPC {
    public compPlan: string | null | undefined;
    public mlob: number | undefined;
    public mlobDesc: string | null | undefined;
    public reptCode: number | undefined ;
    public reptDesc: string | null | undefined ;
    public custElibiity: string | null | undefined;
    public pymtEligibity: string | null | undefined;

    constructor(details?: any) {
      if (details) {
        this.compPlan = details.compPlan;
        this.mlob = details.mlob;
        this.mlobDesc = details.mlobDesc;
        this.reptCode = details.reptCode;
        this.reptDesc = details.reptDesc;
        this.custElibiity = details.custElibiity;
        this.pymtEligibity = details.pymtEligibity;
      }
    }
}
