import { Directive, ElementRef, EventEmitter, Output, HostListener } from '@angular/core';

@Directive({
  selector: '[myClickOutside]'
})
export class ClickOutsideDirective {

  @Output() public myClickOutside: any = new EventEmitter();

  @HostListener('document:click', ['$event.target'])
  public onClick(targetElement: any): void {
    const clickedInside = this._elementRef.nativeElement.contains(targetElement);
    if (!clickedInside) {
        this.myClickOutside.emit(null);
    }
}
  constructor(private _elementRef: ElementRef) {
  }
}

