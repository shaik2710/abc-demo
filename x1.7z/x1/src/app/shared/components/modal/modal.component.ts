import { Component, OnInit, TemplateRef, Type } from '@angular/core';
import { ModalRef } from './modal-ref';

@Component({
  selector: 'app-modal-popup',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})

export class ModalComponent implements OnInit {
  contentType!: 'template' | 'string' | 'component';
  content: any;
  context: any;
  data: any;

  constructor(private ref: ModalRef) {}

  close() {
    this.ref.close(null);
  }

  ngOnInit() {
    this.content = this.ref.content;
    this.data = this.ref.data;

    if (typeof this.content === 'string') {
      this.contentType = 'string';
    } else if (this.content instanceof TemplateRef) {
      this.contentType = 'template';
      this.context = {
        close: this.ref.close.bind(this.ref)
      };
    } else {
      this.contentType = 'component';
    }
  }

}
