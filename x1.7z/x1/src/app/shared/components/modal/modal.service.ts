import { Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { ComponentPortal, PortalInjector } from '@angular/cdk/portal';
import { Injectable, Injector, TemplateRef, Type } from '@angular/core';
import { ModalRef } from './modal-ref';
import {ModalComponent } from './modal.component';

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  constructor(private overlay: Overlay, private injector: Injector) {}

  open<R = any, T = any>(
    content: string | TemplateRef<any> | Type<any>,
    data: T
  ): ModalRef<R> {
    const configs = new OverlayConfig({
      hasBackdrop: true,
      backdropClass: 'modal-background'
    });

    const overlayRef = this.overlay.create(configs);

    const myOverlayRef = new ModalRef<R, T>(overlayRef, content, data);

    const injector = this.createInjector(myOverlayRef, this.injector);
    overlayRef.attach(new ComponentPortal(ModalComponent, null, injector));

    return myOverlayRef;
  }

  // tslint:disable-next-line:typedef
  createInjector(ref: ModalRef, inj: Injector) {
    const injectorTokens = new WeakMap([[ModalRef, ref]]);
    return new PortalInjector(inj, injectorTokens);
  }
}