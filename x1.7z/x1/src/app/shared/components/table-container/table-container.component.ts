import { Component, OnInit, ViewChild, Input, TemplateRef } from '@angular/core';
import { ModalService } from '../modal/modal.service';
import { ComponentType } from '@angular/cdk/portal';
import { SubscribeComponent } from '../examples/subscribe/subscribe.component';
import { FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-table-container',
  templateUrl: './table-container.component.html',
  styleUrls: ['./table-container.component.scss']
})
export class TableContainerComponent implements OnInit{
  @Input() public showMore = true;
  @Input() public demoGBTable: Array<any> = [{}];
  @Input() public dataTableHeader: Array<any> = [{}];
  @Input() public title?: string;
  content = 'A simple string content modal overlay';
  record: any;

  frmSubscribe = this.fb.group({
    complan: '',
    mlob: '',
    mlob_desc:'',
    rpt_line_code: '',
    cal_elty:'',
    rpt_line_desc:'',
    pay_elty:''
  });

  subscribeComponent = SubscribeComponent;

  subscribeData = null;
  yesNoComponentResponse = null;
  yesNoTemplateResponse = null;

//   demoGBTable: Array<any> =  [
//   {
//   item1: "Middle Market",
//   item2: "1234",
//   item3: "Construction Excess Risk Umbrella",
//   item4: "1111",
//   item5: "4321",
//   item6: "Demo",
//   item7: "Ineligible",

// }, {
//   item1: "Middle Market",
//   item2: "5678",
//   item3: "Contractors Pollution Liability",
//   item4: "2222",
//   item5: "8765",
//   item6: "UI",
//   item7: "Eligible",
// },
// {
//   item1: "Middle Market",
//   item2: "9110",
//   item3: "Contractors Prof Protective Indemnity",
//   item4: "3333",
//   item5: "0912",
//   item6: "Awsome",
//   item7: "Ineligible",
// },{
//   item1: "Middle Market",
//   item2: "5678",
//   item3: "Contractors Pollution Liability",
//   item4: "2222",
//   item5: "8765",
//   item6: "UI",
//   item7: "Eligible",
// },{
//   item1: "Middle Market",
//   item2: "5678",
//   item3: "Contractors Pollution Liability",
//   item4: "2222",
//   item5: "8765",
//   item6: "UI",
//   item7: "Eligible",
// },{
//   item1: "Middle Market",
//   item2: "5678",
//   item3: "Contractors Pollution Liability",
//   item4: "2222",
//   item5: "8765",
//   item6: "UI",
//   item7: "Eligible",
// },{
//   item1: "Middle Market",
//   item2: "5678",
//   item3: "Contractors Pollution Liability",
//   item4: "2222",
//   item5: "8765",
//   item6: "UI",
//   item7: "Eligible",
// },{
//   item1: "Middle Market",
//   item2: "5678",
//   item3: "Contractors Pollution Liability",
//   item4: "2222",
//   item5: "8765",
//   item6: "UI",
//   item7: "Eligible",
// },{
//   item1: "Middle Market",
//   item2: "5678",
//   item3: "Contractors Pollution Liability",
//   item4: "2222",
//   item5: "8765",
//   item6: "UI",
//   item7: "Eligible",
// }];
constructor(private overlayService: ModalService, private fb: FormBuilder) { }

ngOnInit(): void {
  console.log('dataTableHeader', this.dataTableHeader);
  console.log('demoGBTable', this.demoGBTable);
}


public open(content: TemplateRef<any> | ComponentType<any> | string, data: any): void{
  this.record = data;
  this.frmSubscribe = this.fb.group({
    complan: this.record.complan,
    mlob:  this.record.mlob,
    mlob_desc:  this.record.mlob_desc,
    rpt_line_code:  this.record.rpt_line_code,
    cal_elty:  this.record.cal_elty,
    rpt_line_desc:  this.record.rpt_line_desc,
    pay_elty:  this.record.pay_elty
  });
  const ref = this.overlayService.open(content, data);
  
  

  ref.afterClosed$.subscribe(res => {
    console.log(this.record);
    if (typeof content === 'string') {
      console.log(res);
    } else if (content === this.subscribeComponent) {
      this.subscribeData = res.data;
    }
  });
}

}
