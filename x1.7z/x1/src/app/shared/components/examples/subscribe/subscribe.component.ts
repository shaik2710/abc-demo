import { Component, OnInit, Input } from '@angular/core';
import { ModalRef } from '../../modal/modal-ref';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.scss']
})
export class SubscribeComponent implements OnInit {
  @Input() public data: Array<any> = [{}];
  frmSubscribe = this.fb.group({
    name: 'John Doe',
    email: [
      'johndoe@gmail.com',
      Validators.compose([Validators.email, Validators.required])
    ]
  });

  constructor(private fb: FormBuilder, private ref: ModalRef) {}

  ngOnInit() {
    console.log(this.data);
  }

  submit() {
    this.ref.close(this.frmSubscribe.value);
  }

  cancel() {
    this.ref.close(null);
  }
}
