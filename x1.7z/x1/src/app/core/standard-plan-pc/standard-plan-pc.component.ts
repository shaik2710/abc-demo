import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import {  PlanDetailsService } from 'src/app/shared/services/plan-details.service';
interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-standard-plan-pc',
  templateUrl: './standard-plan-pc.component.html',
  styleUrls: ['./standard-plan-pc.component.scss']
})

export class StandardPlanPcComponent implements OnInit {
  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  websiteList: any = ['2018', '2019', '2020', '2021'];
  segmentList: any = ['middle market' , 'global speciality'];
  eligibilityList: any = ['Eligible' , 'Ineligible'];
  public demoGBTable: Array<any> =  [
    {
    complan: "Middle Market",
    mlob: "1234",
    mlob_desc: "Construction Excess Risk Umbrella",
    rpt_line_code: "2522",
    rpt_line_desc: "description reproting 8765",
    cal_elty: "Ineligible",
    pay_elty: "Eligible"

  }, {
    complan: "Aiddle Market",
    mlob: "5678",
    mlob_desc: "Contractors Pollution Liability",
    rpt_line_code: "2222",
    rpt_line_desc: "reproting Desc",
    cal_elty: "Eligible",
    pay_elty: "InEligible",
  },
  {
    complan: "Ziddle Market",
    mlob: "9110",
    mlob_desc: "Contractors Prof Protective Indemnity",
    rpt_line_code: "3333",
    rpt_line_desc: "0912 description",
    cal_elty: "Eligible",
    pay_elty: "Eligible",
  },{
    complan: "Piddle Market",
    mlob: "5678",
    mlob_desc: "Qontractors Pollution Liability",
    rpt_line_code: "2222",
    rpt_line_desc: "8765",
    cal_elty: "Ineligible",
    pay_elty: "InEligible",
  },{
    complan: "Abddle Market",
    mlob: "5678",
    mlob_desc: "Contractors Pollution Liability",
    rpt_line_code: "2222",
    rpt_line_desc: "8765",
    cal_elty: "Eligible",
    pay_elty: "Eligible",
  },{
    complan: "Middle Market",
    mlob: "5678",
    mlob_desc: "Zontractors Pollution Liability",
    rpt_line_code: "2222",
    rpt_line_desc: " reproting 8765",
    cal_elty: "Ineligible",
    pay_elty: "Eligible",
  },{
    complan: "Ciddle Market",
    mlob: "5678",
    mlob_desc: "Contractors Pollution Liability",
    rpt_line_code: "2222",
    rpt_line_desc: "description reproting 8765",
    cal_elty: "Ineligible",
    pay_elty: "Eligible"
  },{
    complan: "Biddle Market",
    mlob: "5678",
    mlob_desc: "Contractors Pollution Liability",
    rpt_line_code: "2222",
    rpt_line_desc: "87 reproting 65",
    cal_elty: "Ineligible",
    pay_elty: "Ineligible",
  },{
    complan: "Criddle Market",
    mlob: "5678",
    mlob_desc: "Aontractors Pollution Liability",
    rpt_line_code: "2222",
    rpt_line_desc: "reproting 8765",
    cal_elty: "Ineligible",
    pay_elty: "Ineligible",
  }];
  public dataTableHeader: Array<any> = [
    { id: 'complan', header: 'Comp Plan' },
    { id: 'mlob', header: 'MLOB' },
    { id: 'mlob_desc', header: 'MLOB_Description'},
    { id: 'rpt_line_code', header: 'Reporting Line Of Code' },
    { id: 'rpt_line_desc', header: 'Reporting Line Descrtiption' },
    { id: 'cal_elty', header: 'Calculation Eligibity'},
    { id: 'pay_elty', header: 'Payment Eligibity'}
  ];
  public showMore = true;
  public year: string = '2021';
  public title: string = 'Standard Plan MLOB Eligiblity';
  constructor(public fb: FormBuilder , private planDetailsService: PlanDetailsService) { }

  ngOnInit(): void {
    // this.getStandardPlanPCData();
  }

  /**
   * Function to hide the side bar
   */
  toggle(){
    this.showMore = !this.showMore;
  }

  public getStandardPlanPCData(): void {
    this.planDetailsService.getStandardPlanPC().subscribe(data => {
      this.demoGBTable = data ? data : this.demoGBTable ;
  });

}
}
