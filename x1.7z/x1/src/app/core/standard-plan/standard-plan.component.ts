import { Component, OnInit } from '@angular/core';
import { PlanDetailsService } from '../../shared/services/plan-details.service';

@Component({
  selector: 'app-standard-plan',
  templateUrl: './standard-plan.component.html',
  styleUrls: ['./standard-plan.component.scss']
})
export class StandardPlanComponent implements OnInit {
  showFiller = false;
  public demoGBTable: Array<any> =  [
    {
    lineCovgCode: 'STD',
    lineCovgDesc: 'Short Time Disability',
    eligiblity: 'Eligiblie'
    },
    {
      lineCovgCode: 'LTD',
      lineCovgDesc: 'Long Time Disability',
      eligiblity: 'Eligiblie'
    },
    {
        lineCovgCode: 'LTD',
        lineCovgDesc: 'Long Time Disability',
        eligiblity: 'Eligiblie'
    },
    {
      lineCovgCode: 'STD',
      lineCovgDesc: 'Short Time Disability',
      eligiblity: 'Eligiblie'
      },
      {
        lineCovgCode: "LTD",
        lineCovgDesc: "Long Time Disability",
        eligiblity: "InEligible"
      },
      {
          lineCovgCode: "STD",
          lineCovgDesc: "Short Time Disability",
          eligiblity: "InEligible"
      },
    ];
    public dataTableHeader: Array<any> = [
      { id: 'lineCovgCode', header: 'Line Coverage Code' },
      { id: 'lineCovgDesc', header: 'Line Coverage Description' },
      { id: 'eligiblity', header: 'Eligbility'}
    ];
    public title = 'Standard Plan GB Eligibility';

  public currentItem: boolean;

  public showMore: boolean;
      value: any = '2018';
      eligible: any = true;
      inEligible: any = false;
      middleMarket: any = true;
      globalSpeciality: any = false;
  constructor( private planDetailsService: PlanDetailsService) {
    this.showMore = true;
    this.currentItem = true;
  }

  ngOnInit(): void {
     
    //  this.getStandardPlanGBData();
  }

  public getStandardPlanGBData(): void {
    this.planDetailsService.getStandardPlanGB().subscribe(data => {
      this.demoGBTable = data;
    });
  }

  public tableData(value: any) {
    if (value === 'true') {
      this.currentItem = true;
    } else if (value === 'false') {
      this.currentItem = false;
    }
  }

  /**
   * Function to change the hide side bar
   */
  public toggle(){
    this.showMore = !this.showMore;
  }

}
