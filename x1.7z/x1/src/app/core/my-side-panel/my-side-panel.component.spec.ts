import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MySidePanelComponent } from './my-side-panel.component';

describe('MySidePanelComponent', () => {
  let component: MySidePanelComponent;
  let fixture: ComponentFixture<MySidePanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MySidePanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MySidePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
