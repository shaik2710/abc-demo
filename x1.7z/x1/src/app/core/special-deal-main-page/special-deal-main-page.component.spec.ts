import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialDealMainPageComponent } from './special-deal-main-page.component';

describe('SpecialDealMainPageComponent', () => {
  let component: SpecialDealMainPageComponent;
  let fixture: ComponentFixture<SpecialDealMainPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpecialDealMainPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecialDealMainPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
