import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { CUSTOM_ELEMENTS_SCHEMA,  NO_ERRORS_SCHEMA } from '@angular/core';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { OverlayModule } from '@angular/cdk/overlay';
import { AppComponent } from './app.component';
import { HomeComponent } from '././core/home/home.component';
import { StandardPlanComponent } from '././core/standard-plan/standard-plan.component';
import { SpecialDealComponent } from '././core/special-deal/special-deal.component';
import { StandardPlanPcComponent } from '././core/standard-plan-pc/standard-plan-pc.component';
import { IteratorPipe } from './shared/pipes/iterator/iterator.pipe';
import { MoneyPipe } from './shared/pipes/money/money.pipe';
import { CheckboxDirective } from './shared/directives/checkbox/checkbox.directive';
import { ClickOutsideDirective } from './shared/directives/click/my-click-outside.directive';
import { HeaderComponent } from './core/header/header.component';
import { MySidePanelComponent } from './core/my-side-panel/my-side-panel.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SideBarComponent } from './shared/components/side-bar/side-bar.component';
import { TableContainerComponent } from './shared/components/table-container/table-container.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModalComponent } from './shared/components/modal/modal.component';
import { DropDownMultiselectComponent } from './shared/components/drop-down-multiselect/drop-down-multiselect.component';
import { SearchComponent } from './shared/components/search/search.component';
import { SpecialDealMainPageComponent } from './core/special-deal-main-page/special-deal-main-page.component';
import { NewDealComponent } from './core/new-deal/new-deal.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import {MatSelectModule} from '@angular/material/select';
import {MatCardModule} from '@angular/material/card';
import { SortDirective } from './shared/directives/sort.directive';
import { SubscribeComponent } from './shared/components/examples/subscribe/subscribe.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    StandardPlanComponent,
    SpecialDealComponent,
    StandardPlanPcComponent,
    IteratorPipe,
    MoneyPipe,
    CheckboxDirective,
    ClickOutsideDirective,
    HeaderComponent,
    MySidePanelComponent,
    SideBarComponent,
    TableContainerComponent,
    ModalComponent,
    DropDownMultiselectComponent,
    SearchComponent,
    SpecialDealMainPageComponent,
    NewDealComponent,
    SubscribeComponent,
    SortDirective,
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatCardModule,
    FormsModule,
    MatListModule,
    MatIconModule,
    MatToolbarModule,
    MatDividerModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatSidenavModule,
    ReactiveFormsModule,
    NgbModule,
    OverlayModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [

    NO_ERRORS_SCHEMA , CUSTOM_ELEMENTS_SCHEMA
  ],
  entryComponents: [ModalComponent, SubscribeComponent]
})
export class AppModule { }
