import * as ɵngcc0 from '@angular/core';
export declare class MedalliaFeedbackService {
    constructor();
    medalliaFeedbackFormLoad(medalliaFormid: number): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<MedalliaFeedbackService, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<MedalliaFeedbackService>;
}

//# sourceMappingURL=medallia-feedback.service.d.ts.map