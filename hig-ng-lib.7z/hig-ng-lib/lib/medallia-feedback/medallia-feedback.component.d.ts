import { MedalliaFeedbackService } from './medallia-feedback.service';
import * as ɵngcc0 from '@angular/core';
export declare class MedalliaFeedbackComponent {
    private medalliaFeedbackService;
    medalliaFormId: number;
    feedbackText: string;
    constructor(medalliaFeedbackService: MedalliaFeedbackService);
    loadMedallia(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<MedalliaFeedbackComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<MedalliaFeedbackComponent, "lib-medallia-feedback", never, { "medalliaFormId": "medalliaFormId"; "feedbackText": "feedbackText"; }, {}, never, never>;
}

//# sourceMappingURL=medallia-feedback.component.d.ts.map