import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './medallia-feedback.component';
import * as ɵngcc2 from '@angular/common';
export declare class MedalliaFeedbackModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<MedalliaFeedbackModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<MedalliaFeedbackModule, [typeof ɵngcc1.MedalliaFeedbackComponent], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.MedalliaFeedbackComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<MedalliaFeedbackModule>;
}

//# sourceMappingURL=medallia-feedback.module.d.ts.map