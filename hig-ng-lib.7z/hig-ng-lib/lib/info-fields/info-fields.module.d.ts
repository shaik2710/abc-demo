import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './messaging/messaging.component';
import * as ɵngcc2 from './paragraph/paragraph.component';
import * as ɵngcc3 from './heading/heading.component';
import * as ɵngcc4 from './list/list.component';
import * as ɵngcc5 from '@angular/common';
import * as ɵngcc6 from '../pipes/pipes.module';
export declare class InfoFieldsModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<InfoFieldsModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<InfoFieldsModule, [typeof ɵngcc1.MessagingComponent, typeof ɵngcc2.ParagraphComponent, typeof ɵngcc3.HeadingComponent, typeof ɵngcc4.ListComponent], [typeof ɵngcc5.CommonModule, typeof ɵngcc6.PipesModule], [typeof ɵngcc1.MessagingComponent, typeof ɵngcc2.ParagraphComponent, typeof ɵngcc3.HeadingComponent, typeof ɵngcc4.ListComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<InfoFieldsModule>;
}

//# sourceMappingURL=info-fields.module.d.ts.map