import { OnInit } from '@angular/core';
import { FieldConfig } from '../../form-fields/model/field';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import * as ɵngcc0 from '@angular/core';
export declare class HeadingComponent extends FieldComponentBase implements OnInit {
    private eventAggregatorService;
    field: FieldConfig;
    constructor(eventAggregatorService: EventAggregatorService);
    ngOnInit(): void;
    onLinkClick(event: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HeadingComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<HeadingComponent, "lib-heading", never, {}, {}, never, never>;
}

//# sourceMappingURL=heading.component.d.ts.map