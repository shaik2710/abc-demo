export declare class Message {
    messageType: string;
    messageTitle: string;
    messageText: string;
    messageLinkUrl?: string;
    linkTitle?: string;
    linkText?: string;
    denyCode?: string;
}
