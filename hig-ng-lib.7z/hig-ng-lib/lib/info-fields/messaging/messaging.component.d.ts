import { OnInit, AfterViewInit, ElementRef } from '@angular/core';
import { Message } from './message';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { TealiumDataService } from 'ng-tealium';
import { TitleCasePipe } from '@angular/common';
import * as ɵngcc0 from '@angular/core';
export declare class MessagingComponent extends FieldComponentBase implements OnInit, AfterViewInit {
    private elt;
    private tealiumDataService;
    message: Message;
    isCustomHtml: boolean;
    infoMsg: boolean;
    successMsg: boolean;
    warningMsg: boolean;
    dangerMsg: boolean;
    denyCodeText: string;
    messageLinkUrl: string;
    messageBxHide: boolean;
    msg: any;
    titleCase: TitleCasePipe;
    constructor(elt: ElementRef, tealiumDataService: TealiumDataService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    renderMsgBox(messageType: string): void;
    messageBoxHideCheck(): void;
    trackLinkClick(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<MessagingComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<MessagingComponent, "lib-messaging", never, { "message": "message"; "isCustomHtml": "isCustomHtml"; }, {}, never, [".message-content"]>;
}

//# sourceMappingURL=messaging.component.d.ts.map