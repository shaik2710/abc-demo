import { OnInit } from '@angular/core';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { FieldConfig } from '../../form-fields/model/field';
import * as ɵngcc0 from '@angular/core';
export declare class ListComponent extends FieldComponentBase implements OnInit {
    field: FieldConfig;
    constructor();
    ngOnInit(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ListComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<ListComponent, "lib-list", never, {}, {}, never, never>;
}

//# sourceMappingURL=list.component.d.ts.map