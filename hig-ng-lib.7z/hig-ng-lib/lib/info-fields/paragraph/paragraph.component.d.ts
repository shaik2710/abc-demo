import { OnInit } from '@angular/core';
import { FieldConfig } from '../../form-fields/model/field';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import * as ɵngcc0 from '@angular/core';
export declare class ParagraphComponent extends FieldComponentBase implements OnInit {
    private eventAggregatorService;
    field: FieldConfig;
    constructor(eventAggregatorService: EventAggregatorService);
    ngOnInit(): void;
    onLinkClick(event: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ParagraphComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<ParagraphComponent, "lib-paragraph", never, {}, {}, never, never>;
}

//# sourceMappingURL=paragraph.component.d.ts.map