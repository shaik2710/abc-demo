import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './loading-indicator.component';
import * as ɵngcc2 from '@angular/common';
export declare class LoadingIndicatorModule {
    static forRoot(): ModuleWithProviders<LoadingIndicatorModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LoadingIndicatorModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<LoadingIndicatorModule, [typeof ɵngcc1.LoadingIndicatorComponent], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.LoadingIndicatorComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<LoadingIndicatorModule>;
}
export * from './loading-indicator.component';

//# sourceMappingURL=loading-indicator.module.d.ts.map