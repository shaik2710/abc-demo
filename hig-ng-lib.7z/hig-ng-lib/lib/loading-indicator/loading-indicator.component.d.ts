import * as ɵngcc0 from '@angular/core';
export declare class LoadingIndicatorComponent {
    style?: 'spinner' | 'shimmer';
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LoadingIndicatorComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<LoadingIndicatorComponent, "lib-loading-indicator", never, { "style": "style"; }, {}, never, never>;
}

//# sourceMappingURL=loading-indicator.component.d.ts.map