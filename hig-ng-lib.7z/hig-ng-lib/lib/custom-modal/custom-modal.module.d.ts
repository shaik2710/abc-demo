import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './custom-modal.component';
import * as ɵngcc2 from '@angular/common';
export declare class CustomModalModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CustomModalModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<CustomModalModule, [typeof ɵngcc1.CustomModalComponent], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.CustomModalComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<CustomModalModule>;
}

//# sourceMappingURL=custom-modal.module.d.ts.map