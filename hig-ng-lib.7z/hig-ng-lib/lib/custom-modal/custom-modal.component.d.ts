import { EventEmitter, Injector } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class CustomModalComponent {
    /**
     * document reference variable
     */
    private document;
    /**
     * renderer reference variable
     */
    private renderer;
    /**
     * flag to show the footer section
     */
    showFooter: boolean;
    /**
     * flag to show the header section
     */
    showHeader: boolean;
    /**
     * for alert icon in the header section
     */
    showAlertIconHeader: boolean;
    /**
     * display body
     */
    showBody: any;
    /**
     * modal tile
     */
    title: string;
    /**
     * to show the header content, this flag goes with showHeader attribute
     */
    hideHeaderContent: boolean;
    /**
     * Setting default iconType as Success Check Mark
     */
    iconType: string;
    /**
     * modal id
     */
    modalId: string;
    /**
     * modal size - large/medium/small
     */
    modalSize?: 'large' | 'medium' | 'small';
    /**
     * to display close('X') icon at the top right corner of the modal
     */
    showCloseIcon: boolean;
    /**
     * event emitter on close event of popup
     */
    close: EventEmitter<any>;
    /**
     * visible and visible animate are used in showing and hiding the modal
     */
    visible: boolean;
    /**
     * flag to enable animation
     */
    visibleAnimate: boolean;
    /**
     * to hide modal when clicked outside of modal
     */
    hideOnClickAnyWhere: boolean;
    constructor(injector: Injector);
    show(): void;
    hide(): void;
    /**
     * Keyboard Navigation Handlers
     */
    handleKeydownEvent(event: KeyboardEvent): void;
    /**
     * click anywhere outside the modal box the popup(session timeout) will close
     */
    clickedOutBox(event: any): void;
    /**
      * Provides the class required according to the modalSize input
      */
    getModalSizeClass(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CustomModalComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<CustomModalComponent, "lib-custom-modal", never, { "showFooter": "showFooter"; "showHeader": "showHeader"; "showAlertIconHeader": "showAlertIconHeader"; "hideHeaderContent": "hideHeaderContent"; "iconType": "iconType"; "showCloseIcon": "showCloseIcon"; "showBody": "showBody"; "title": "title"; "modalId": "modalId"; "modalSize": "modalSize"; "hideOnClickAnyWhere": "hideOnClickAnyWhere"; }, { "close": "close"; }, never, [".app-modal-header", ".app-modal-body", ".app-modal-footer"]>;
}

//# sourceMappingURL=custom-modal.component.d.ts.map