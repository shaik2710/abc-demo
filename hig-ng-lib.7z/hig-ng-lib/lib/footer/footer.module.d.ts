import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './footer.component';
import * as ɵngcc2 from '@angular/common';
export declare class FooterModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FooterModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<FooterModule, [typeof ɵngcc1.FooterComponent], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.FooterComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<FooterModule>;
}

//# sourceMappingURL=footer.module.d.ts.map