import { OnInit } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class FooterComponent implements OnInit {
    contactUsLink: string;
    contactUsLinkLabel: string;
    legalNoticeLink: string;
    legalNoticeLinkLabel: string;
    privacyPolicyLink: string;
    privacyPolicyLinkLabel: string;
    accessibilityStatementLink: string;
    accessibilityStatementLinkLabel: string;
    currentDate: number;
    poweredBy: boolean;
    constructor();
    ngOnInit(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FooterComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<FooterComponent, "lib-footer", never, { "contactUsLink": "contactUsLink"; "contactUsLinkLabel": "contactUsLinkLabel"; "legalNoticeLink": "legalNoticeLink"; "legalNoticeLinkLabel": "legalNoticeLinkLabel"; "privacyPolicyLink": "privacyPolicyLink"; "privacyPolicyLinkLabel": "privacyPolicyLinkLabel"; "accessibilityStatementLink": "accessibilityStatementLink"; "accessibilityStatementLinkLabel": "accessibilityStatementLinkLabel"; "poweredBy": "poweredBy"; "currentDate": "currentDate"; }, {}, never, never>;
}

//# sourceMappingURL=footer.component.d.ts.map