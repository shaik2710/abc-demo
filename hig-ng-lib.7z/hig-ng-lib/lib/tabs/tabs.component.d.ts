import { QueryList, AfterContentInit, OnInit, OnDestroy, ComponentFactoryResolver, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { TabComponent } from './tab.component';
import { Subscription } from 'rxjs';
import * as ɵngcc0 from '@angular/core';
export declare class TabsComponent implements OnInit, OnDestroy, AfterContentInit {
    private router;
    private componentFactoryResolver;
    private unsubscribe;
    routerSubscription: Subscription;
    subscribeToRouteEvents: boolean;
    tabs: QueryList<TabComponent>;
    tabChange: EventEmitter<TabComponent>;
    constructor(router: Router, componentFactoryResolver: ComponentFactoryResolver);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    /**
     * Loops through tabs and selects active tab based on status or current url
     */
    private markActiveTab;
    loadComponent(tab: TabComponent, component: any, inputData?: any): void;
    selectTab(tab: TabComponent): void;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<TabsComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<TabsComponent, "lib-tabs", never, { "subscribeToRouteEvents": "subscribeToRouteEvents"; }, { "tabChange": "tabChange"; }, ["tabs"], ["*"]>;
}

//# sourceMappingURL=tabs.component.d.ts.map