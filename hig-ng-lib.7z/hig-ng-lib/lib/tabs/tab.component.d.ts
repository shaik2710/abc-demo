import { EventEmitter } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class TabComponent {
    icon: string;
    customClass: string | string[] | {
        [key: string]: boolean;
    };
    tabTitle: string;
    url: string;
    active: boolean;
    isLoaded: boolean;
    dynamicTabPlaceholder: any;
    accTabChange: EventEmitter<TabComponent>;
    constructor();
    selectTab(tab: TabComponent): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<TabComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<TabComponent, "lib-tab", never, { "icon": "icon"; "active": "active"; "customClass": "customClass"; "tabTitle": "tabTitle"; "url": "url"; }, { "accTabChange": "accTabChange"; }, never, ["*"]>;
}

//# sourceMappingURL=tab.component.d.ts.map