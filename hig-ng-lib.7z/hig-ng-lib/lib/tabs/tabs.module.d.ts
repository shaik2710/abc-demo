import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './tabs.component';
import * as ɵngcc2 from './tab.component';
import * as ɵngcc3 from '@angular/common';
export declare class TabsModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<TabsModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<TabsModule, [typeof ɵngcc1.TabsComponent, typeof ɵngcc2.TabComponent], [typeof ɵngcc3.CommonModule], [typeof ɵngcc1.TabsComponent, typeof ɵngcc2.TabComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<TabsModule>;
}
export * from './tabs.component';
export * from './tab.component';

//# sourceMappingURL=tabs.module.d.ts.map