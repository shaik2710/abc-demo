import { Subject } from 'rxjs';
export interface FormValidator {
    name: string;
    action?: string;
    message: string;
    operator?: string;
    value?: any;
    minLength?: number;
    maxLength?: number;
    min?: number;
    max?: number;
    pattern?: string;
    globalModifiers?: string;
}
export interface TooltipConfig {
    useBodyWidth: boolean;
    useMobileConfig: boolean;
    enableSingleTooltip?: boolean;
    offsetDifference?: number;
    maxWidthDifference: number;
    label?: any;
    iconClass?: string;
    placement?: string;
}
/**
 * Behavior configuration for logic
 */
export interface Behavior {
    /**
     * For logical behavior type will have 2 possible values  (logic and statement)
     *
     * logic: If type is logic that means you need to have multiple
     *  statements to perform nested operation and (statements and operator) will be mandatory field
     *
     * statement: if type is statement that means it will not have further statements to execute
     */
    type?: string;
    /**
     * action property can have two possible value (show/disable)
     */
    action?: string;
    /**
     * operator property can have logical symbol and string (AND, OR, ===, >, <, <=, >=, !==)
     */
    operator?: string;
    /**
     * for selected field possible value for comparison
     */
    value?: any;
    /**
     * field name which is used for value comparison
     */
    name?: string;
    /**
     * statements is an Array of type of Behavior which containes nested logic
     */
    statements?: Behavior[];
}
/**
 * AddressValidationConfig configuration class
 */
export interface AddressValidationConfig {
    /**
     * endpointUrl for the trillium API call
     */
    endpointUrl: string;
    /**
     * version required for the data power call
     */
    version: string;
    /**
     * clientId required for the data power call
     */
    clientId: string;
    /**
     * target env if any
     */
    targetEnv?: string;
    /**
     * session env of CIAM
     */
    sessionEnv?: string;
}
/**
 * FieldConfig is the interface to configure all the fields used for form engine or used individually.
 * All the properties are kept optional bacause its being used by different fields.
 */
export interface FieldConfig {
    /**
     * Label is used to show field label
     * If lable is not passed or left blank in the field configuration, lable element will not be created in the DOM.
     */
    label?: string;
    /**
     * Name is the unique field name for each fields, for info fields(messaging, paragraph etc.)
     * name is not mandatory, where as for actionable fields name is required property to create
     *  formControl with same name.
     */
    name?: string;
    inputType?: string;
    options?: any[];
    collections?: any;
    type?: string;
    value?: any;
    validations?: FormValidator[];
    eventName?: string;
    validationAction?: string;
    widthClass?: string;
    showField?: boolean;
    isTealiumAllowed?: boolean;
    message?: any;
    isCustomHtml?: boolean;
    styleType?: string;
    isPii?: boolean;
    buttons?: any;
    readOnly?: boolean;
    dataDl?: any;
    subType?: string;
    children?: FieldConfig[];
    className?: string;
    extraLabel?: string;
    extraText?: string;
    helpText?: string;
    disabled?: boolean;
    placeHolder?: string;
    groupBy?: string;
    maxAllowed?: number;
    notFoundText?: string;
    bindLabel?: string;
    bindValue?: string;
    labelClass?: string;
    inputClass?: string;
    minLength?: number;
    maxLength?: number;
    subTypes?: string;
    checkboxLabel?: string;
    checkboxLabelHelpText?: string;
    isCheckboxAlt?: boolean;
    typeahead$?: Subject<string>;
    minTermLength?: number;
    customColWidth?: number;
    /**
     * add a show/hide button to vertical radio inputs with options longer than this length
     * choose what the show/hide text will be
     */
    showMoreLessAfterIndex?: number;
    showMoreText?: string;
    showLessText?: string;
    /** metric text to display for metric fields. E.g. feet, miles, lbs., etc. */
    metric?: string;
    /**
     * option for the input field checkbox default selection
     */
    checkboxSelected?: boolean;
    defaultValue?: string;
    setMinDate?: number;
    setMaxDate?: number;
    hideDefaultDate?: boolean;
    /**
     * behaviors property used for having logical statements to show/hide or enable/disable current field
     *
     * Its applicable only for form engine
     */
    behaviors?: Behavior[];
    hasHtml?: boolean;
    tooltipConfig?: TooltipConfig;
    decimalPlaces?: number;
    minValue?: number;
    maxValue?: number;
    icon?: string;
    btnClass?: string;
    /**
     * standardizeAddress property used to enable/disable trillium validation for the address component
     */
    standardizeAddress?: boolean;
    /**
     * Header and body text for address verification warning message
     */
    warningTextHeadline?: string;
    warningTextMessage?: string;
    /**
     * googleAutofill property enable/disable google autofill behaviour for address component
     */
    googleAutofill?: boolean;
    /**
     * Trillium configurations
     */
    addressValidationConfig?: AddressValidationConfig;
    /**
     * trigger standardizeAddressEvent
     */
    standardizeAddressEvent?: string;
    /**
     * show verification modal on address component for successful cleanse
     */
    showAddressVerificationModal?: boolean;
    /**
     * should the address component broadcast all field events?
     */
    broadcastAddressFieldEvents?: boolean;
    /**
     * show/hide optional field APT in address component
     */
    showApt?: boolean;
    /**
     * Custom label used for APT field in address component
     */
    aptFieldLabel?: string;
    /**
     * show/hide optional field AddressLine2 in address component
     */
    showAddressLine2?: boolean;
    /**
     * Custom label used for AddressLine2 field in address component
     */
    addressLine2Label?: string;
    /**
     * labelEvent used to trigger event from the label if there is some custom handling required
     */
    labelEvent?: string;
    /**
     * Property for address component to determine whether to display US states only
     * or display all states including the US territories and the military states
     * For ex: if this boolean is true, 50 states of the US will be
     * available in the state drop down
     */
    showUSOnlyStates?: boolean;
    /**
     * this will send the unmasked value or send the masked value the user is seeing in the input etc
     */
    unMaskedPhoneNumber?: boolean;
    multiple?: boolean;
    /**
     * add a title when there is no label to make the form WCAG complaint
     */
    title?: string;
    /**
     * This can be used to send custom tealium tags for analytics
     */
    customTealiumData?: any;
    /**
     * This can be used to specify the field pattern to match and error message if the entry doesn't match
     * Allows for use of regular expressions with global modifiers
     */
    patternMatch?: {
        pattern: any;
        patternMessage: string;
        globalModifiers?: string;
    };
    isPII?: any;
    /**
     * this is used to display comma separated currency while typing
     */
    displayCommaOnTyping?: boolean;
    /**
     * this is needed for existing E2E test in EBC. There are common steps which looks fr common IDs
     */
    id?: string;
}
