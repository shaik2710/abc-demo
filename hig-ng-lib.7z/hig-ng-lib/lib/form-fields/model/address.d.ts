import { FormBuilder, FormGroup } from '@angular/forms';
export declare class Address {
    sequenceNo?: string;
    addressCleanse?: string;
    qualityCode?: string;
    addressLine1: string;
    addressLineOne?: string;
    addressLineTwo?: string;
    addressLine2?: string;
    city: string;
    county?: string;
    state: string;
    zipCode: string;
    postalCode?: string;
    apt?: string;
    name1?: string;
    name2?: string;
    name3?: string;
    addressStandardized?: boolean;
    static formatAddressString(data: Address, fieldName?: string): string;
    static formatAddress(data: Address, fieldName?: string): string[];
    constructor(options?: {
        addressLine1?: string;
        addressLine2?: string;
        city?: string;
        county?: string;
        state?: string;
        zipCode?: string;
        addressStandardized?: boolean;
    });
}
export declare class AddressForm {
    private fb;
    constructor(fb: FormBuilder);
    createNewFormGroup(data?: Address): FormGroup;
}
