import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './radio.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '../form-helper/form-helper.module';
import * as ɵngcc5 from '../../pipes/pipes.module';
import * as ɵngcc6 from '../../tooltip/tooltip.module';
export declare class RadioModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<RadioModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<RadioModule, [typeof ɵngcc1.RadioComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule, typeof ɵngcc3.ReactiveFormsModule, typeof ɵngcc4.FormHelperModule, typeof ɵngcc5.PipesModule, typeof ɵngcc6.HigTooltipModule], [typeof ɵngcc1.RadioComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<RadioModule>;
}

//# sourceMappingURL=radio.module.d.ts.map