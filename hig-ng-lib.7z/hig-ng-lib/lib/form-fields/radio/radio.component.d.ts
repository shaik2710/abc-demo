import { FieldConfig } from '../model/field';
import { FormGroup } from '@angular/forms';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import { TealiumDataService } from 'ng-tealium';
import * as ɵngcc0 from '@angular/core';
export declare class RadioComponent extends FieldComponentBase {
    private eventAggregatorService;
    private tealiumdatasvc;
    true: any;
    field: FieldConfig;
    hideOptions: boolean;
    group: FormGroup;
    constructor(eventAggregatorService: EventAggregatorService, tealiumdatasvc: TealiumDataService);
    selectHandler(): void;
    getPlainTextLabel(): string;
    toggleHideOptions(event: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<RadioComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<RadioComponent, "lib-radio", never, { "group": "group"; }, {}, never, never>;
}

//# sourceMappingURL=radio.component.d.ts.map