import { OnInit } from '@angular/core';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import { TealiumDataService } from 'ng-tealium';
import * as ɵngcc0 from '@angular/core';
export declare class TextareaComponent extends FieldComponentBase implements OnInit {
    private eventAggregatorService;
    private tealiumdatasvc;
    _hasError: boolean;
    errorMessage: string;
    constructor(eventAggregatorService: EventAggregatorService, tealiumdatasvc: TealiumDataService);
    ngOnInit(): void;
    contentChangeHandler(event: any): void;
    getPlainTextLabel(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<TextareaComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<TextareaComponent, "lib-textarea", never, {}, {}, never, never>;
}

//# sourceMappingURL=textarea.component.d.ts.map