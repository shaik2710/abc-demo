import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './textarea.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '../../tooltip/tooltip.module';
import * as ɵngcc4 from '../form-helper/form-helper.module';
import * as ɵngcc5 from '@angular/forms';
import * as ɵngcc6 from '../../pipes/pipes.module';
export declare class TextareaModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<TextareaModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<TextareaModule, [typeof ɵngcc1.TextareaComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.HigTooltipModule, typeof ɵngcc4.FormHelperModule, typeof ɵngcc5.FormsModule, typeof ɵngcc5.ReactiveFormsModule, typeof ɵngcc6.PipesModule], [typeof ɵngcc1.TextareaComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<TextareaModule>;
}

//# sourceMappingURL=textarea.module.d.ts.map