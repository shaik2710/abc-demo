import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Address } from '../model/address';
import { AddressValidationConfig } from '../model/field';
import * as ɵngcc0 from '@angular/core';
export interface RequestPayload {
    request: Address[];
}
export interface ResponsePayload {
    addresses: Address[];
}
export declare class ExtendedHttpHeaders extends HttpHeaders {
    errorHandler?: Function;
}
export declare const usOnlyStates: {
    key: string;
    value: string;
}[];
export declare const usTerritories: {
    key: string;
    value: string;
}[];
export declare const armedForces: {
    key: string;
    value: string;
}[];
export declare class AddressService {
    private http;
    /**
     * url for global address standardization service
     *
     * cache service responses
     */
    private responseCache;
    constructor(http: HttpClient);
    /**
    * Caches validation request by provided Address key
    * @param trilliumConfig
    * @param requestAddress
    */
    standardizeAddress(addressValidationConfig: AddressValidationConfig, requestAddress: any, fieldName?: string): Observable<ResponsePayload>;
    /**
     * this method maps the request which IBA address service expects.
     * The reason for this method is, our existing address model and IBM address request payload have different field names.
     * Ex: our model have addressLine1 and IBM api expects in addressLineOne
     * @param address
     */
    mapAddressForStandardize(address: any): Address;
    /**
     * return address object for standardize
     * @param requestAddress
     * @param fieldName
     */
    getAddressForStandardize(requestAddress: any, fieldName: string): Address;
    /**
     * Submits request to address validation service
     * @param addressValidationConfig
     * @param requestBody
     */
    submitRequest(addressValidationConfig: AddressValidationConfig, requestBody: RequestPayload): Observable<ResponsePayload>;
    /**
     * custom error handler for bubbling up error returned from service
     * @param request
     */
    handleError(request: any): Observable<never>;
    /**
     * return all the states including US territories and military
     */
    getAllStates(): {
        key: string;
        value: string;
    }[];
    /**
     * return US Only states
     */
    getUSOnlyStates(): {
        key: string;
        value: string;
    }[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AddressService, never>;
}

//# sourceMappingURL=address.service.d.ts.map