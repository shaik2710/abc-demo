import { ModuleWithProviders } from '@angular/core';
import { GoogleConfig } from '../../google-autocomplete/api-key-config.service';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './address.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '../form-helper/form-helper.module';
import * as ɵngcc5 from '../../info-fields/info-fields.module';
import * as ɵngcc6 from '../input/input.module';
import * as ɵngcc7 from '../../google-autocomplete/google-autocomplete.module';
import * as ɵngcc8 from '../../custom-modal/custom-modal.module';
import * as ɵngcc9 from 'ng-tealium';
export declare class AddressModule {
    static forRoot(config: GoogleConfig): ModuleWithProviders<AddressModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AddressModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AddressModule, [typeof ɵngcc1.AddressComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.ReactiveFormsModule, typeof ɵngcc3.FormsModule, typeof ɵngcc4.FormHelperModule, typeof ɵngcc5.InfoFieldsModule, typeof ɵngcc6.InputModule, typeof ɵngcc7.GoogleAutocompleteModule, typeof ɵngcc8.CustomModalModule, typeof ɵngcc9.TealiumModule], [typeof ɵngcc1.AddressComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AddressModule>;
}

//# sourceMappingURL=address.module.d.ts.map