import { OnInit, OnDestroy, OnChanges } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, AbstractControl, ValidationErrors } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { AddressService } from './address.service';
import { Address } from '../model/address';
import { FormUtilitiesService } from '../form-helper/form-helper.module';
import { FieldConfig, AddressValidationConfig, FormValidator } from '../model/field';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import { TealiumDataService } from 'ng-tealium';
import { CustomModalComponent } from '../../custom-modal/custom-modal.component';
import * as ɵngcc0 from '@angular/core';
export interface AddressValidations {
    addressLine1: FormValidator[];
    city: FormValidator[];
    state: FormValidator[];
    zipCode: FormValidator[];
}
export declare class AddressComponent implements OnInit, OnDestroy, OnChanges {
    formUtils: FormUtilitiesService;
    private ref;
    private fb;
    private eventAggregatorService;
    private addressService;
    private tealiumDataService;
    addressValidationConfig: AddressValidationConfig;
    googleAutofill: boolean;
    group: FormGroup;
    field: FieldConfig;
    id: string;
    /** real-time postal address standardization / validation **/
    standardizeAddress: boolean;
    warningTextHeadline: string;
    warningTextMessage: string;
    verificationModalRef: CustomModalComponent;
    verificationHeader: string;
    verificationBody: string;
    qualityCode: number;
    standardizationAttempts: number;
    /** end real-time postal address standardization / validation **/
    formErrors: Object;
    formData: {};
    /**
     * states property holds list all the state to papulate in the dropdown
     */
    states: any[];
    /**
     * Subscription property
     */
    subsManager: Subscription;
    /**
     * hasError holds boolean value for each fields in address component
     */
    hasError: {};
    /**
     * hasError holds error messages for each fields in address component
     */
    errorMessage: {};
    /**
     * bind with select field for the state selection
     */
    selectedState: any;
    /**
     * all the possible address fields, required for dynamic control creation and validations
     */
    addressFields: string[];
    /**
     * Default address validations messages
     */
    addressValidations: AddressValidations;
    messageConfig: FieldConfig;
    cleansedLocation: any;
    constructor(formUtils: FormUtilitiesService, ref: ChangeDetectorRef, fb: FormBuilder, eventAggregatorService: EventAggregatorService, addressService: AddressService, tealiumDataService: TealiumDataService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * are we using the address standardization service?
     */
    subscribeAddressStandarization(): void;
    /**
     * method return form validity for address validations
     */
    isFormValid(): boolean;
    /**
     * subscribeEventAggregator subscribe broadcasted event for address validations.
     */
    subscribeEventAggregator(): void;
    /**
     * Calls address standardization / validation service, updates form group value w/validated address if a match was made
     *
     * Alerts user to non-matches and allows user to update address and re-validate or proceed without any changes
     */
    validateAddress(control?: AbstractControl): Observable<ValidationErrors>;
    /**
     * Broadcast any time a field is changed so the application can react based on which field it is
     * @param fieldName
     * @param event
     */
    broadcastFieldEvent(fieldName: string, event?: any): void;
    /**
    * Close the verification modal and react based on user choice to accept or reject cleansed address
    * @param acceptCleanse
    */
    closeVerificationModal(acceptCleanse: boolean): void;
    /**
    * On successful cleanse, patch values provided from cleansing API to the form
    */
    patchValues(): void;
    /**
     * map address fields value with formData
     * @param address
     */
    mapAddressValues(address: Address): any;
    stateChange(): void;
    /**
     * Google Address method used to set form address fields from selected Google Place response object
     * @param response Google Place response object: https://developers.google.com/places/web-service/details
     */
    handleAddressChange(response: any): void;
    /**
     * sets validation errorMessage for the invalid field
     * @param fieldName
     */
    validateError(fieldName: string): boolean;
    /**
     * create form controls for the address component
     * @param updated
     */
    createControl(updated?: boolean): void;
    /**
     * return control name for the selected field
     * @param fieldName
     */
    getFieldControlName(fieldName: string): string;
    analyticsUpdate(eventLabel: string, eventId: string, eventValue?: string): void;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AddressComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AddressComponent, "lib-address", never, { "field": "field"; "standardizeAddress": "standardizeAddress"; "warningTextHeadline": "warningTextHeadline"; "warningTextMessage": "warningTextMessage"; "verificationHeader": "verificationHeader"; "verificationBody": "verificationBody"; "googleAutofill": "googleAutofill"; "addressValidationConfig": "addressValidationConfig"; "id": "id"; "group": "group"; }, {}, never, never>;
}

//# sourceMappingURL=address.component.d.ts.map