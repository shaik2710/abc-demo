import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './select.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '../form-helper/form-helper.module';
import * as ɵngcc5 from '../../tooltip/tooltip.module';
import * as ɵngcc6 from '../../pipes/pipes.module';
export declare class SelectModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<SelectModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<SelectModule, [typeof ɵngcc1.SelectComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule, typeof ɵngcc3.ReactiveFormsModule, typeof ɵngcc4.FormHelperModule, typeof ɵngcc5.HigTooltipModule, typeof ɵngcc6.PipesModule], [typeof ɵngcc1.SelectComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<SelectModule>;
}

//# sourceMappingURL=select.module.d.ts.map