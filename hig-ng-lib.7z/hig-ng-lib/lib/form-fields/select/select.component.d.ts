import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import { FieldConfig } from '../model/field';
import { FormGroup } from '@angular/forms';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { TealiumDataService } from 'ng-tealium';
import * as ɵngcc0 from '@angular/core';
export declare class SelectComponent extends FieldComponentBase {
    private eventAggregatorService;
    private tealiumdatasvc;
    field: FieldConfig;
    group: FormGroup;
    constructor(eventAggregatorService: EventAggregatorService, tealiumdatasvc: TealiumDataService);
    selectHandler(): void;
    getPlainTextLabel(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<SelectComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<SelectComponent, "lib-select", never, {}, {}, never, never>;
}

//# sourceMappingURL=select.component.d.ts.map