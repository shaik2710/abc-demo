import { OnInit, OnDestroy } from '@angular/core';
import { FieldConfig } from '../model/field';
import { FormGroup, AbstractControl } from '@angular/forms';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import { TealiumDataService } from 'ng-tealium';
import { FormUtilitiesService } from '../form-helper/form-utilities.service';
import { Subscription } from 'rxjs';
import * as ɵngcc0 from '@angular/core';
export declare class InputComponent extends FieldComponentBase implements OnInit, OnDestroy {
    private eventAggregatorService;
    private tealiumdatasvc;
    private formUtilitiesService;
    true: any;
    field: FieldConfig;
    group: FormGroup;
    resetSubscription: Subscription;
    currentFieldControl: AbstractControl;
    constructor(eventAggregatorService: EventAggregatorService, tealiumdatasvc: TealiumDataService, formUtilitiesService: FormUtilitiesService);
    ngOnInit(): void;
    getTypes(subType: string): string;
    /**
     * conditions for input disable
     * checks for checkbox selected first and then disabled
     */
    isDisabled(): true;
    inputChacked(event: any): void;
    changeHandler(event: any): void;
    getPlainTextLabel(): string;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<InputComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<InputComponent, "lib-input", never, { "field": "field"; "group": "group"; }, {}, never, never>;
}

//# sourceMappingURL=input.component.d.ts.map