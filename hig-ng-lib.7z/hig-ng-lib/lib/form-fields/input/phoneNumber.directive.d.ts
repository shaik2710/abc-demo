import { ElementRef, OnInit } from '@angular/core';
import { NgControl } from '@angular/forms';
import * as ɵngcc0 from '@angular/core';
export declare class PhoneNumberDirective implements OnInit {
    private el;
    private control;
    maxLength: number;
    unMaskedPhoneNumber: boolean;
    /**
     * this flag sends the unmasked phone number to the control when it is true.
     * When it is not passed the masked phone number is sent to the control in the form xxx-xxx-xxxx
     */
    unMaskedValue: number;
    constructor(el: ElementRef, control: NgControl);
    ngOnInit(): void;
    onInput(): void;
    onKeyPress(event: any): boolean;
    handleWindowChange(event: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<PhoneNumberDirective, [null, { optional: true; }]>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<PhoneNumberDirective, "[libPhoneNumber]", never, { "unMaskedPhoneNumber": "unMaskedPhoneNumber"; }, {}, never>;
}

//# sourceMappingURL=phoneNumber.directive.d.ts.map