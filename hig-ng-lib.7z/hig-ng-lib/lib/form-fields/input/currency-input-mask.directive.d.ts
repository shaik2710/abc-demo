/**
 * Used the refrence from following URL for this directive
 * https://stackblitz.com/edit/angular-u2vcwn?file=app%2Fcurrency-input-mask%2Fcurrency-input-mask.directive.ts
 */
import { OnInit, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { DecimalPipe } from '@angular/common';
import * as ɵngcc0 from '@angular/core';
export declare const CURRENCY_INPUT_MASK_DIRECTIVE_VALUE_ACCESSOR: any;
export declare class CurrencyInputMaskDirective implements ControlValueAccessor, OnInit {
    private elementRef;
    private decimalPipe;
    /**
     * decimalPlaces input field
     */
    decimalPlaces: number;
    displayCommaOnTyping: boolean;
    private el;
    private onModelChange;
    private onModelTouched;
    private lastNumVal;
    private DECIMAL_MARK;
    constructor(elementRef: ElementRef, decimalPipe: DecimalPipe);
    ngOnInit(): void;
    /**
     * Handle Focus event
     * @param event
     */
    handleFocus(event: any): void;
    /**
     * handle cut event
     * @param event
     */
    handleCut(event: any): void;
    /**
     * handle keypress event
     * @param event
     */
    handleKeypress(event: any): void;
    /**
     * handle keyup event
     * @param event
     */
    handleKeyup(event: any): void;
    /**
     * show/hide commas in currency field
     */
    private displayCommaInCurrency;
    /**
     * handle input event
     * @param event
     */
    handleInput(event: any): void;
    /**
     * handle blur event
     * @param event
     */
    handleBlur(event: any): void;
    /**
     * register callback function for change
     * @param callbackFunction
     */
    registerOnChange(callbackFunction: Function): void;
    /**
     * register callback function for touched
     * @param callbackFunction
     */
    registerOnTouched(callbackFunction: Function): void;
    /**
     * set disable state
     * @param value
     */
    setDisabledState(value: boolean): void;
    /**
     * write back input value
     * @param numValue
     */
    writeValue(numValue: number): void;
    /**
     * mask input value
     * @param numVal
     */
    private maskInput;
    /**
     * Update input value
     */
    private inputUpdated;
    /**
     * decimal handling
     */
    private restrictDecimalValue;
    /**
     * based on the input of decimalPlaces apply decimal formatting
     * @param str
     */
    private transformWithPipe;
    /**
     * return unmasked value
     * @param value
     */
    private getUnmaskedValue;
    /**
     * Update input value
     * @param value
     * @param savePosition
     */
    private updateInputValue;
    /**
     * return input value
     */
    private getInputValue;
    /**
     * converts string to decimal
     * @param str
     */
    private convertStrToDecimal;
    /**
     * converts decimal to string
     * @param n
     */
    private convertDecimalToStr;
    /**
     * check if its numeric
     * @param n
     */
    private isNumeric;
    private saveCursorPosition;
    /**
     * maintains cusrsor position
     * @param position
     */
    private setCursorPosition;
    /**
     * isIdxBetweenSelection
     * @param idx
     */
    private isIdxBetweenSelection;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CurrencyInputMaskDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<CurrencyInputMaskDirective, "[libCurrencyInputMask]", never, { "decimalPlaces": "decimalPlaces"; "displayCommaOnTyping": "displayCommaOnTyping"; }, {}, never>;
}

//# sourceMappingURL=currency-input-mask.directive.d.ts.map