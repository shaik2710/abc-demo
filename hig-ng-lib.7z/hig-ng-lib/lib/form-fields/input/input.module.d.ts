import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './input.component';
import * as ɵngcc2 from './numbers-only.directive';
import * as ɵngcc3 from './currency-input-mask.directive';
import * as ɵngcc4 from './phoneNumber.directive';
import * as ɵngcc5 from '@angular/common';
import * as ɵngcc6 from '../../tooltip/tooltip.module';
import * as ɵngcc7 from '../form-helper/form-helper.module';
import * as ɵngcc8 from '@angular/forms';
import * as ɵngcc9 from '../../pipes/pipes.module';
import * as ɵngcc10 from 'ng-tealium';
export declare class InputModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<InputModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<InputModule, [typeof ɵngcc1.InputComponent, typeof ɵngcc2.NumbersOnlyDirective, typeof ɵngcc3.CurrencyInputMaskDirective, typeof ɵngcc4.PhoneNumberDirective], [typeof ɵngcc5.CommonModule, typeof ɵngcc6.HigTooltipModule, typeof ɵngcc7.FormHelperModule, typeof ɵngcc8.FormsModule, typeof ɵngcc9.PipesModule, typeof ɵngcc8.ReactiveFormsModule, typeof ɵngcc10.TealiumModule], [typeof ɵngcc1.InputComponent, typeof ɵngcc2.NumbersOnlyDirective, typeof ɵngcc3.CurrencyInputMaskDirective, typeof ɵngcc4.PhoneNumberDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<InputModule>;
}

//# sourceMappingURL=input.module.d.ts.map