import { ElementRef } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class NumbersOnlyDirective {
    private el;
    elemRef: ElementRef;
    onlyNumber: boolean;
    zipCode: boolean;
    decimalPlaces: string;
    minValue: string;
    maxValue: string;
    exceptionKeyCodes: number[];
    constructor(el: ElementRef);
    onKeyDown(event: any): void;
    onKeyPress(event: any): void;
    onPaste($clipBoardevent: any): void;
    pasteFormattedText(pattern: RegExp, $clipBoardevent: any): void;
    onDrop(event: DragEvent): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NumbersOnlyDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NumbersOnlyDirective, "[libNumbersOnly]", never, { "onlyNumber": "onlyNumber"; "zipCode": "zipCode"; "decimalPlaces": "decimalPlaces"; "minValue": "minValue"; "maxValue": "maxValue"; }, {}, never>;
}

//# sourceMappingURL=numbers-only.directive.d.ts.map