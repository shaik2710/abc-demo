import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './datepicker.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '../../tooltip/tooltip.module';
import * as ɵngcc5 from '../form-helper/form-helper.module';
import * as ɵngcc6 from '../../pipes/pipes.module';
import * as ɵngcc7 from 'ngx-bootstrap/datepicker';
import * as ɵngcc8 from 'ng-tealium';
export declare class DatepickerModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DatepickerModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<DatepickerModule, [typeof ɵngcc1.DatepickerComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule, typeof ɵngcc3.ReactiveFormsModule, typeof ɵngcc4.HigTooltipModule, typeof ɵngcc5.FormHelperModule, typeof ɵngcc6.PipesModule, typeof ɵngcc7.BsDatepickerModule, typeof ɵngcc8.TealiumModule], [typeof ɵngcc1.DatepickerComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<DatepickerModule>;
}

//# sourceMappingURL=datepicker.module.d.ts.map