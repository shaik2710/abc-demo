import { OnInit, EventEmitter, OnDestroy } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker/public_api';
import { FieldConfig } from '../model/field';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import * as ɵngcc0 from '@angular/core';
export declare class DatepickerComponent extends FieldComponentBase implements OnInit, OnDestroy {
    private fb;
    private eventAggregatorService;
    field: FieldConfig;
    group: FormGroup;
    dateChange: EventEmitter<any>;
    minDate: Date;
    maxDate: Date;
    dateFieldValue: Date;
    colorTheme: string;
    bsConfig: Partial<BsDatepickerConfig>;
    /**
     * Subscription property
     */
    subManager: Subscription;
    constructor(fb: FormBuilder, eventAggregatorService: EventAggregatorService);
    ngOnInit(): void;
    /**
     * subscribeEventAggregator subscribe broadcasted event for datepicker validations.
     */
    subscribeEventAggregator(): void;
    /**
     * common method to update form control
     */
    updateControl(updated?: boolean): void;
    bsValueChangeHandler(date: Date): void;
    /**
   * This method gets triggered when date UI gets hidden
   * we will manually set the control to touched
   */
    setTouched(): void;
    getPlainTextLabel(): string;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DatepickerComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<DatepickerComponent, "lib-datepicker", never, { "field": "field"; "group": "group"; }, { "dateChange": "dateChange"; }, never, never>;
}

//# sourceMappingURL=datepicker.component.d.ts.map