import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { FormValidator, FieldConfig } from '../model/field';
import * as ɵngcc0 from '@angular/core';
export declare class FormUtilitiesService {
    private fb;
    emailRegEx: RegExp;
    constructor(fb: FormBuilder);
    static getPlainTextLabel(field: FieldConfig): string;
    /**
     * Walks a form chain and marks all controls dirty and emits event
     * @param group
     */
    markControlsDirty(group: FormGroup | FormArray): void;
    /**
     * Converts a given form groups errors to an abject with user friend errors
     * @param form
     * @param validationMessages
     * @param force
     */
    validateForm(form: FormGroup, validationMessages: any, force?: boolean): {};
    /**
     * Flattens potentially nested FormGroups and FormArrays to single array of controls
     * @param group
     */
    flattenForm(group: FormGroup | FormArray): FormControl[];
    /**
     * Angular doesn't wait for async validators to complete. So the form may be invalid if the validators have not resolved.
     * Invokes every controls synchronous and asynchronous validators and returns a boolean indicating whether or not all validation passed
     * @param formGroup
     */
    validateFormAsynchronously(formGroup: FormGroup): Promise<boolean>;
    /**
     * Custom email validator
     */
    validateEmail(): (c: FormControl) => {
        required: boolean;
    };
    /**
     * Find any input elements on the page that are in a invalid state and focus on the first
     */
    focusInvalid(selector?: string): void;
    /**
     * Enables/Disables button and sets loading text while disabled
     * @param selector
     * @param loadingMessage
     */
    toggleButton(selector: string, loadingMessage?: string): void;
    /**
     * binds validations with field if applicable
     * @param validations
     */
    bindValidations(validations: FormValidator[], field: FieldConfig): null;
    /**
     * Validates each fields in the form
     * @param formGroup
     */
    validateAllFormFields(formGroup: FormGroup): void;
    /**
     * Create form control for the given options
     * @param option
     */
    createFormControl(option: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormUtilitiesService, never>;
}

//# sourceMappingURL=form-utilities.service.d.ts.map