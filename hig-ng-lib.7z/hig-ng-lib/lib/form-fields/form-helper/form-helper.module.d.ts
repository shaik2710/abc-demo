import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './validation-error/validation-error.component';
import * as ɵngcc2 from './form-group-highlight.directive';
import * as ɵngcc3 from '@angular/common';
export declare class FormHelperModule {
    static forRoot(): ModuleWithProviders<FormHelperModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormHelperModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<FormHelperModule, [typeof ɵngcc1.ValidationErrorComponent, typeof ɵngcc2.FormGroupHighlightDirective], [typeof ɵngcc3.CommonModule], [typeof ɵngcc1.ValidationErrorComponent, typeof ɵngcc2.FormGroupHighlightDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<FormHelperModule>;
}
export * from './form-utilities.service';
export * from './validation-error/validation-error.component';
export * from './form-group-highlight.directive';

//# sourceMappingURL=form-helper.module.d.ts.map