import { ElementRef, AfterViewInit } from '@angular/core';
import { FieldConfig } from '../model/field';
import { Subscription } from 'rxjs';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import * as ɵngcc0 from '@angular/core';
export declare class FormGroupHighlightDirective implements AfterViewInit {
    private eventAggregatorService;
    private el?;
    field: FieldConfig;
    private inputEl;
    private parentEl;
    private eventEl;
    subscription: Subscription;
    constructor(eventAggregatorService: EventAggregatorService, el?: ElementRef);
    ngAfterViewInit(): void;
    /**
     * Handle event for the label element if there is html content in the innerHtml
     * @param event
     */
    handleEvent(event: any): void;
    getInputValidity(inputEl: any): boolean;
    focusGroup(): void;
    unfocusGroup(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormGroupHighlightDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FormGroupHighlightDirective, "[libFormGroupHighlight]", never, { "field": "field"; }, {}, never>;
}

//# sourceMappingURL=form-group-highlight.directive.d.ts.map