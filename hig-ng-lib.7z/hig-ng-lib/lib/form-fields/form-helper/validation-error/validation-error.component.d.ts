import { OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { TealiumDataService } from 'ng-tealium';
import * as ɵngcc0 from '@angular/core';
export declare class ValidationErrorComponent implements OnInit, OnChanges {
    private tealiumdatasvc;
    fieldErrors: Array<string>;
    validations: any[];
    field: string;
    message: any;
    isPII: any;
    formErrors: Object;
    fieldName: string;
    constructor(tealiumdatasvc: TealiumDataService);
    ngOnInit(): void;
    ngOnChanges(validation: SimpleChanges): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ValidationErrorComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<ValidationErrorComponent, "lib-validation-error", never, { "validations": "validations"; "field": "field"; "message": "message"; "isPII": "isPII"; "formErrors": "formErrors"; "fieldName": "fieldName"; }, {}, never, never>;
}

//# sourceMappingURL=validation-error.component.d.ts.map