import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './checkbox.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '../form-helper/form-helper.module';
import * as ɵngcc5 from '../../pipes/pipes.module';
import * as ɵngcc6 from '../../tooltip/tooltip.module';
export declare class CheckboxModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CheckboxModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<CheckboxModule, [typeof ɵngcc1.CheckboxComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule, typeof ɵngcc3.ReactiveFormsModule, typeof ɵngcc4.FormHelperModule, typeof ɵngcc5.PipesModule, typeof ɵngcc6.HigTooltipModule], [typeof ɵngcc1.CheckboxComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<CheckboxModule>;
}

//# sourceMappingURL=checkbox.module.d.ts.map