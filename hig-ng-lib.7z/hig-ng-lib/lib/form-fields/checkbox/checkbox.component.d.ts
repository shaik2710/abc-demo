import { OnInit } from '@angular/core';
import { FieldConfig } from '../model/field';
import { FormGroup, ValidatorFn } from '@angular/forms';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import { TealiumDataService } from 'ng-tealium';
import * as ɵngcc0 from '@angular/core';
export declare class CheckboxComponent extends FieldComponentBase implements OnInit {
    private eventAggregatorService;
    private tealiumdatasvc;
    true: any;
    field: FieldConfig;
    selectedOption: string;
    checkboxStatus: string;
    group: FormGroup;
    formArray: any[];
    constructor(eventAggregatorService: EventAggregatorService, tealiumdatasvc: TealiumDataService);
    /**
     * creating formArray of controls if there are multiple options for checkboxes
     */
    ngOnInit(): void;
    selectHandler(option: any): void;
    /**
     * This gets invoked only if there are multiple options
     * It loops through all the controls of formArray and checks
     * if at least one check box is selected.
     */
    minSelectedCheckboxes(): ValidatorFn;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CheckboxComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<CheckboxComponent, "lib-checkbox", never, { "group": "group"; }, {}, never, never>;
}

//# sourceMappingURL=checkbox.component.d.ts.map