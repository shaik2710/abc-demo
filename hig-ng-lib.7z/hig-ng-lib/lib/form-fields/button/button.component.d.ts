import { OnInit } from '@angular/core';
import { FieldConfig } from '../model/field';
import { FormGroup } from '@angular/forms';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import * as ɵngcc0 from '@angular/core';
export declare class ButtonComponent extends FieldComponentBase implements OnInit {
    private eventAggregatorService;
    field: FieldConfig;
    group: FormGroup;
    constructor(eventAggregatorService: EventAggregatorService);
    ngOnInit(): void;
    /**
     * onClickBtn should broadcast event if field config has eventName
     */
    onClickBtn(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ButtonComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<ButtonComponent, "lib-button", never, {}, {}, never, never>;
}

//# sourceMappingURL=button.component.d.ts.map