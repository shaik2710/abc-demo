import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './button.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
export declare class ButtonModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ButtonModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<ButtonModule, [typeof ɵngcc1.ButtonComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule, typeof ɵngcc3.ReactiveFormsModule], [typeof ɵngcc1.ButtonComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<ButtonModule>;
}

//# sourceMappingURL=button.module.d.ts.map