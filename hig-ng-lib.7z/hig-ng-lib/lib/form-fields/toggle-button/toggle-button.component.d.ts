import { OnInit } from '@angular/core';
import { FieldConfig } from '../model/field';
import { FormGroup } from '@angular/forms';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { TealiumDataService } from 'ng-tealium';
import * as ɵngcc0 from '@angular/core';
export declare class ToggleButtonComponent extends FieldComponentBase implements OnInit {
    private eventAggregatorService;
    private tealiumdatasvc;
    true: any;
    field: FieldConfig;
    group: FormGroup;
    constructor(eventAggregatorService: EventAggregatorService, tealiumdatasvc: TealiumDataService);
    ngOnInit(): void;
    onClickBtn(option: any, event: Event): void;
    getPlainTextLabel(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ToggleButtonComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<ToggleButtonComponent, "lib-toggle-button", never, {}, {}, never, never>;
}

//# sourceMappingURL=toggle-button.component.d.ts.map