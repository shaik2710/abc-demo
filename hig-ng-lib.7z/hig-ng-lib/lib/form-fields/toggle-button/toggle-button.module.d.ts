import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './toggle-button.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '../../tooltip/tooltip.module';
import * as ɵngcc5 from '../form-helper/form-helper.module';
import * as ɵngcc6 from '../../pipes/pipes.module';
export declare class ToggleButtonModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ToggleButtonModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<ToggleButtonModule, [typeof ɵngcc1.ToggleButtonComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule, typeof ɵngcc3.ReactiveFormsModule, typeof ɵngcc4.HigTooltipModule, typeof ɵngcc5.FormHelperModule, typeof ɵngcc6.PipesModule], [typeof ɵngcc1.ToggleButtonComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<ToggleButtonModule>;
}

//# sourceMappingURL=toggle-button.module.d.ts.map