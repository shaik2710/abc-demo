import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './typeahead-select.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '@ng-select/ng-select';
import * as ɵngcc5 from '@ng-select/ng-option-highlight';
import * as ɵngcc6 from '../form-helper/form-helper.module';
import * as ɵngcc7 from '../../tooltip/tooltip.module';
import * as ɵngcc8 from '../../pipes/pipes.module';
export declare class TypeaheadSelectModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<TypeaheadSelectModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<TypeaheadSelectModule, [typeof ɵngcc1.TypeaheadSelectComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule, typeof ɵngcc4.NgSelectModule, typeof ɵngcc5.NgOptionHighlightModule, typeof ɵngcc3.ReactiveFormsModule, typeof ɵngcc6.FormHelperModule, typeof ɵngcc7.HigTooltipModule, typeof ɵngcc8.PipesModule], [typeof ɵngcc1.TypeaheadSelectComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<TypeaheadSelectModule>;
}

//# sourceMappingURL=typeahead-select.module.d.ts.map