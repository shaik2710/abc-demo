import { OnInit } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { TealiumDataService } from 'ng-tealium';
import { FieldComponentBase } from '../../form-engine/base-classes/field-component-base';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import * as ɵngcc0 from '@angular/core';
export declare class TypeaheadSelectComponent extends FieldComponentBase implements OnInit {
    private eventAggregatorService;
    private tealiumdatasvc;
    selectedOption: any;
    currentFieldControl: AbstractControl;
    constructor(eventAggregatorService: EventAggregatorService, tealiumdatasvc: TealiumDataService);
    ngOnInit(): void;
    /**
     * handle select event of ng-selet
     * @param event
     */
    selectHandler(event: any): void;
    /**
     * this method handles the value selection for the field with input list of type object.
     * @param event
     */
    handleObjectList(event: any): void;
    /**
     * on blur mark field as touched
     */
    onBlur(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<TypeaheadSelectComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<TypeaheadSelectComponent, "lib-typeahead-select", never, {}, {}, never, never>;
}

//# sourceMappingURL=typeahead-select.component.d.ts.map