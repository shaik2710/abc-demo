import * as ɵngcc0 from '@angular/core';
export declare class HigNgLibService {
    constructor();
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HigNgLibService, never>;
}

//# sourceMappingURL=hig-ng-lib.service.d.ts.map