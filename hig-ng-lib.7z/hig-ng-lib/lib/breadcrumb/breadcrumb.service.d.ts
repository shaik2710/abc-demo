import { ActivatedRoute, Router } from '@angular/router';
import { BreadCrumb } from './breadcrumb';
import * as ɵngcc0 from '@angular/core';
export declare class BreadcrumbService {
    private router;
    private activatedRoute;
    /**
     * Breadcrumbs with custom attributes; e.g. labels.
     * @note We keep track of custom breadcrumbs because we rebuild the breadcrumbs
     * every single time the route changes; if we did not, then our set breadcrumbs
     * would be overwritten when the screen changes.
     */
    private _customBreadcrumbs;
    /** List of current breadcrumbs */
    private _currentBreadcrumbs;
    /** Our BehaviorSubject of the current breadcrumbs */
    private _breadcrumbs;
    /** Observable list of the current breadcrumbs */
    breadcrumbs$: import("rxjs").Observable<BreadCrumb[]>;
    /** Should we include the root label */
    private _includeRoot;
    /** The root label */
    private _rootLabel;
    constructor(router: Router, activatedRoute: ActivatedRoute);
    /** Listen to Router events and updates the Breadcrumbs accordingly */
    private detectRouterChanges;
    /**
     * Allows the ability to set a custom label on a given alias.
     * Aliases are defined in the RouteConfig and are prefixed with an '@' symbol,
     * For example: { data: { breadcrumb: { label: 'Summary List', alias: '@summaryList' } } }
     */
    set(alias: string, label: string): void;
    /**
     * Build your breadcrumb starting with the root route of your current activated route
     */
    buildBreadcrumb(route: ActivatedRoute, url?: string, breadcrumbs?: BreadCrumb[]): BreadCrumb[];
    set includeRoot(includeRoot: boolean);
    get includeRoot(): boolean;
    set rootLabel(rootLabel: string);
    get rootLabel(): string;
    get currentBreadCrumb(): BreadCrumb[];
    get customBreadCrumb(): BreadCrumb[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<BreadcrumbService, never>;
}

//# sourceMappingURL=breadcrumb.service.d.ts.map