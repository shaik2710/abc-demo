import { OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BreadcrumbService } from './breadcrumb.service';
import { BreadCrumb } from './breadcrumb';
import * as ɵngcc0 from '@angular/core';
export declare class BreadcrumbComponent implements OnInit {
    private activatedRoute;
    private router;
    private breadcrumbService;
    rootLabel: string;
    includeRoot: boolean;
    breadcrumbs: BreadCrumb[];
    constructor(activatedRoute: ActivatedRoute, router: Router, breadcrumbService: BreadcrumbService);
    navigateUrl(val: string): void;
    ngOnInit(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<BreadcrumbComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<BreadcrumbComponent, "lib-breadcrumb", never, { "rootLabel": "rootLabel"; "includeRoot": "includeRoot"; }, {}, never, never>;
}

//# sourceMappingURL=breadcrumb.component.d.ts.map