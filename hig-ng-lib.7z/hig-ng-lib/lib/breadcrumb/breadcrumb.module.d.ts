import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './breadcrumb.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/router';
export declare class BreadcrumbModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<BreadcrumbModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<BreadcrumbModule, [typeof ɵngcc1.BreadcrumbComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.RouterModule], [typeof ɵngcc1.BreadcrumbComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<BreadcrumbModule>;
}

//# sourceMappingURL=breadcrumb.module.d.ts.map