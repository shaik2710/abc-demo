import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './form-engine.component';
import * as ɵngcc2 from './form-engine.directive';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from '@angular/forms';
export declare class FormEngineModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormEngineModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<FormEngineModule, [typeof ɵngcc1.FormEngineComponent, typeof ɵngcc2.FormEngineDirective], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.FormsModule, typeof ɵngcc4.ReactiveFormsModule], [typeof ɵngcc1.FormEngineComponent, typeof ɵngcc2.FormEngineDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<FormEngineModule>;
}

//# sourceMappingURL=form-engine.module.d.ts.map