import { OnInit, DoCheck, OnChanges, KeyValueDiffers, SimpleChanges } from '@angular/core';
import { FormEngineBase } from './base-classes/form-engine-base';
import { FieldConfig } from '../form-fields/model/field';
import { Subscription } from 'rxjs';
import { FormBuilder } from '@angular/forms';
import { EventAggregatorService } from '../event-aggregator/event-aggregator.service';
import * as ɵngcc0 from '@angular/core';
export declare class FormEngineComponent extends FormEngineBase implements OnInit, DoCheck, OnChanges {
    fb: FormBuilder;
    eventAggregatorService: EventAggregatorService;
    private differs;
    fields: FieldConfig;
    /**
     * Mapper object should passed from the component where form engine used
     *
     * Mapper object will have mapping for angular components
     */
    mapper: any;
    differ: any;
    formSubscription: Subscription;
    constructor(fb: FormBuilder, eventAggregatorService: EventAggregatorService, differs: KeyValueDiffers);
    ngOnInit(): void;
    /**
     * if field config or formGroup changes then call syncForm method
     * @param changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Call syncForm method there has been update in the form value
     */
    ngDoCheck(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormEngineComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<FormEngineComponent, "lib-form-engine", never, { "fields": "fields"; "mapper": "mapper"; }, {}, never, never>;
}

//# sourceMappingURL=form-engine.component.d.ts.map