import { ComponentFactoryResolver, ViewContainerRef, ComponentRef } from '@angular/core';
import { FieldConfig } from '../../form-fields/model/field';
import { FormGroup } from '@angular/forms';
import * as ɵngcc0 from '@angular/core';
export declare abstract class FormEngineDirectiveBase {
    resolver: ComponentFactoryResolver;
    container: ViewContainerRef;
    field: FieldConfig;
    group: FormGroup;
    componentMapper: any;
    componentRef: ComponentRef<any>;
    constructor(resolver: ComponentFactoryResolver, container: ViewContainerRef);
    /**
     * This method loads dynamic fields in DOM and create angular components for the fields config
     */
    renderFields(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormEngineDirectiveBase, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FormEngineDirectiveBase, never, never, { "field": "field"; "group": "group"; "componentMapper": "componentMapper"; }, {}, never>;
}

//# sourceMappingURL=form-engine-directive-base.d.ts.map