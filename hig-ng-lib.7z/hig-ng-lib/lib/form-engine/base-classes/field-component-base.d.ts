import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../form-fields/model/field';
import * as ɵngcc0 from '@angular/core';
export declare abstract class FieldComponentBase {
    group: FormGroup;
    field: FieldConfig;
    _hasError: boolean;
    errorMessage: string;
    /**
     *  hasError sets applicable message
     */
    hasError(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FieldComponentBase, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FieldComponentBase, never, never, { "group": "group"; "field": "field"; }, {}, never>;
}

//# sourceMappingURL=field-component-base.d.ts.map