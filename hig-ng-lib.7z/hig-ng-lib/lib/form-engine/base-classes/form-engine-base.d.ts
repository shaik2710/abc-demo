import { EventEmitter, OnDestroy } from '@angular/core';
import { FieldConfig, FormValidator } from '../../form-fields/model/field';
import { Subscription } from 'rxjs';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { EventAggregatorService } from '../../event-aggregator/event-aggregator.service';
import * as ɵngcc0 from '@angular/core';
export declare abstract class FormEngineBase implements OnDestroy {
    protected fb: FormBuilder;
    protected eventAggregatorService: EventAggregatorService;
    fields: any;
    submit: EventEmitter<any>;
    getFields: EventEmitter<any>;
    form: FormGroup;
    subManager: Subscription;
    formsCtrlList: FieldConfig[];
    allFields: FieldConfig[];
    addressFieldKeyList: string[];
    protected constructor(fb: FormBuilder, eventAggregatorService: EventAggregatorService);
    /**
     * subscribeEventAggregator handles form validator events for all fields
     */
    subscribeEventAggregator(): void;
    /**
     * Common onSubmit method
     * @param event
     */
    onSubmit(event: Event): void;
    /**
     * recursive method to retun all the field as an array
     * @param fieldConfig
     * @param fieldList
     */
    getAllFields(fieldConfig: FieldConfig, fieldList: FieldConfig[]): void;
    /**
     * Create/Update form controls for all the fields
     * @param updateCtrl
     */
    createControl(updateCtrl?: boolean): void;
    /**
     * update address form controls
     */
    updateAddressControls(): void;
    /**
     * return control name for the selected field
     * @param fieldName
     */
    getFieldControlName(fieldName: string, addressFieldName: string): string;
    /**
     * returns true if field name contains anyof the address field
     * @param fieldName
     */
    isAddressField(fieldName: string): boolean;
    /**
     *  Returns true if formControl not required for selected field
     * @param fieldType
     */
    isNotAllowedFormCtrlField(fieldType: string): boolean;
    /**
     * Creates formControl
     * @param field
     */
    createFormControl(field: FieldConfig): void;
    /**
     * Common method to returns index of array for the given key value
     * @param arry
     * @param key
     * @param value
     */
    getIndex(arry: any[], key: string, value: string): number;
    /**
     * binds validations with field if applicable
     * @param validations
     */
    bindValidations(validations: FormValidator[], field: FieldConfig): null;
    /**
     * Validates each fields in the form
     * @param formGroup
     */
    validateAllFormFields(formGroup: FormGroup): void;
    /**
     * Validates each fields in the form (dirtycheck)
     * @param formGroup
     */
    markControlsDirty(group: FormGroup | FormArray): void;
    /**
     * Upodated form controls for shown/hidden fields and subscribe events
     * @param update
     */
    syncForm(update: boolean): void;
    /**
     * Updated field behaviour based on the behaviour Object
     * @param field
     */
    behaviourUpdate(field: FieldConfig, form: FormGroup): void;
    /**
     * Recursive method to execute nested behaviour statements
     * @param statements
     * @param stmtResponse
     */
    recurLogic(statements: any[], stmtResponse: any[], form: FormGroup): void;
    /**
     * compare method return boolean after logical operation
     * @param post
     * @param operator
     * @param value
     */
    compare(post: any, operator: any, value: any): boolean;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormEngineBase, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FormEngineBase, never, never, { "fields": "fields"; "form": "form"; }, { "submit": "submit"; "getFields": "getFields"; }, never>;
}

//# sourceMappingURL=form-engine-base.d.ts.map