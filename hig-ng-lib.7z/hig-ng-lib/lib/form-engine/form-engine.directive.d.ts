import { OnChanges, ViewContainerRef, SimpleChanges, ComponentRef, ComponentFactoryResolver } from '@angular/core';
import { FormEngineDirectiveBase } from './base-classes/form-engine-directive-base';
import { FieldConfig } from '../form-fields/model/field';
import { FormGroup } from '@angular/forms';
import * as ɵngcc0 from '@angular/core';
export declare class FormEngineDirective extends FormEngineDirectiveBase implements OnChanges {
    resolver: ComponentFactoryResolver;
    container: ViewContainerRef;
    field: FieldConfig;
    group: FormGroup;
    /**
     * Mapper object should be passed from the injecting component
     *
     * Mapper object will have mapping for angular components
     */
    mapper: any;
    componentRef: ComponentRef<any>;
    constructor(resolver: ComponentFactoryResolver, container: ViewContainerRef);
    /**
     * ngOnChanges method detect changes for all the input fields
     * @param changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormEngineDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FormEngineDirective, "[libFormEngine]", never, { "field": "field"; "group": "group"; "mapper": "mapper"; }, {}, never>;
}

//# sourceMappingURL=form-engine.directive.d.ts.map