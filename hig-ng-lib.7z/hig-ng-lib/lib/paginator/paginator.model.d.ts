export declare class PaginatorModel {
    itemsPerPage: number;
    pageNumber: number;
    startIndex: number;
    endIndex: number;
}
