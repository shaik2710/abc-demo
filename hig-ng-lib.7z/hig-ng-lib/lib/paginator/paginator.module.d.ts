import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './paginator.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
export declare class PaginatorModule {
    static forRoot(): ModuleWithProviders<PaginatorModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<PaginatorModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<PaginatorModule, [typeof ɵngcc1.PaginatorComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.FormsModule], [typeof ɵngcc1.PaginatorComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<PaginatorModule>;
}
export * from './scrolling-helper/scrolling-helper';
export * from './paginator.model';

//# sourceMappingURL=paginator.module.d.ts.map