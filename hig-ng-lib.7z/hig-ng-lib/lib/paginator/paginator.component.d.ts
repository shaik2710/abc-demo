import { OnInit, EventEmitter } from '@angular/core';
import { PaginatorModel } from './paginator.model';
import { ScrollingHelper } from './scrolling-helper/scrolling-helper';
import * as ɵngcc0 from '@angular/core';
export declare class PaginatorComponent implements OnInit {
    scrollingHelper: ScrollingHelper;
    totalNumberOfPages: number;
    atStartPointer: boolean;
    atEndPointer: boolean;
    pages: any[];
    itemStartNumber: number;
    itemEndNumber: number;
    mobileSkipNumber: number;
    paginatorResult: PaginatorModel;
    scrollId: string;
    currentPageNumber: number;
    itemPerPage: number;
    totalRecords: any;
    pageSizeOptions: number[];
    showDisabled: boolean;
    pageChangeEvent: EventEmitter<PaginatorModel>;
    constructor(scrollingHelper: ScrollingHelper);
    ngOnInit(): void;
    onItemPerPageChange(): void;
    onNextPage(): void;
    onPageSelect(pageNumber: any): void;
    onPrevPage(): void;
    pageRestructuring(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<PaginatorComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<PaginatorComponent, "lib-paginator", never, { "currentPageNumber": "currentPageNumber"; "pageSizeOptions": "pageSizeOptions"; "showDisabled": "showDisabled"; "itemPerPage": "itemPerPage"; "scrollId": "scrollId"; "totalRecords": "totalRecords"; }, { "pageChangeEvent": "pageChangeEvent"; }, never, never>;
}

//# sourceMappingURL=paginator.component.d.ts.map