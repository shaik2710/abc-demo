import { Subject } from 'rxjs';
import * as ɵngcc0 from '@angular/core';
export declare class ScrollingHelper {
    static readonly SCROLL_SPEED = 40;
    static readonly DESKTOP_SCROLL_OFFSET = 60;
    static readonly MOBILE_SCROLL_OFFSET = 0;
    static readonly DESKTOP_WIDTH = 1024;
    scrollToPositiveSource: Subject<any>;
    scrollToNegativeSource: Subject<any>;
    constructor();
    scrollToId(id: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ScrollingHelper, never>;
}

//# sourceMappingURL=scrolling-helper.d.ts.map