import { Subscription } from 'rxjs';
import * as ɵngcc0 from '@angular/core';
export interface Message {
    type: string;
    payload: any;
}
export declare type MessageCallback = (payload: any) => void;
export declare class EventAggregatorService {
    private handler;
    constructor();
    broadcast(type: string, payload: any): void;
    subscribe(type: string, callback: MessageCallback): Subscription;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<EventAggregatorService, never>;
}

//# sourceMappingURL=event-aggregator.service.d.ts.map