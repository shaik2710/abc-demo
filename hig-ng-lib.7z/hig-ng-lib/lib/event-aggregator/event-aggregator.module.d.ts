import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/common';
export declare class EventAggregatorModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<EventAggregatorModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<EventAggregatorModule, never, [typeof ɵngcc1.CommonModule], never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<EventAggregatorModule>;
}

//# sourceMappingURL=event-aggregator.module.d.ts.map