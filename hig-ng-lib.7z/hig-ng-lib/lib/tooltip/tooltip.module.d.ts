import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './tooltip.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from 'ngx-bootstrap/popover';
import * as ɵngcc4 from '@angular/forms';
export declare class HigTooltipModule {
    /**
     * added forRoot for backward support,
     * @param config
     */
    static forRoot(config?: any): ModuleWithProviders<HigTooltipModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HigTooltipModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<HigTooltipModule, [typeof ɵngcc1.HigTooltipComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.PopoverModule, typeof ɵngcc4.FormsModule, typeof ɵngcc4.ReactiveFormsModule], [typeof ɵngcc1.HigTooltipComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<HigTooltipModule>;
}

//# sourceMappingURL=tooltip.module.d.ts.map