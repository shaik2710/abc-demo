import { OnInit, ElementRef, OnChanges, EventEmitter } from '@angular/core';
import { TealiumDataService } from 'ng-tealium';
import * as ɵngcc0 from '@angular/core';
export declare class HigTooltipComponent implements OnInit, OnChanges {
    element: ElementRef;
    private tealiumdatasvc;
    offSetMinLimit: number;
    customMobileClass: string;
    pop: any;
    offsetDifference: number;
    maxWidthDifference: number;
    useBodyWidth: boolean;
    useMobileConfig: boolean;
    iconClass: string;
    placement: string;
    shownTooltip?: EventEmitter<any>;
    enableSingleTooltip: boolean;
    tealiumContent: {
        eventValue: string;
        tealiumTracking: string;
    };
    linkText: string;
    closeOnWindowClick: boolean;
    showOnHover: boolean;
    onHover: string;
    constructor(element: ElementRef, tealiumdatasvc: TealiumDataService);
    ngOnInit(): void;
    ngOnChanges(): void;
    /**
     * method invokes on tooltip shown
     */
    tooltipShown(pop: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HigTooltipComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<HigTooltipComponent, "lib-tooltip", never, { "offsetDifference": "offsetDifference"; "maxWidthDifference": "maxWidthDifference"; "useBodyWidth": "useBodyWidth"; "useMobileConfig": "useMobileConfig"; "iconClass": "iconClass"; "tealiumContent": "tealiumContent"; "linkText": "linkText"; "closeOnWindowClick": "closeOnWindowClick"; "showOnHover": "showOnHover"; "placement": "placement"; "enableSingleTooltip": "enableSingleTooltip"; }, { "shownTooltip": "shownTooltip"; }, never, [".tooltip-content-heading-text", ".tooltip-content-body-text"]>;
}

//# sourceMappingURL=tooltip.component.d.ts.map