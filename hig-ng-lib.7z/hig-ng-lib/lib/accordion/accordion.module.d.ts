import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './accordion.component';
import * as ɵngcc2 from './accordion-panel.directive';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from '../pipes/pipes.module';
export declare class AccordionModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AccordionModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AccordionModule, [typeof ɵngcc1.AccordionComponent, typeof ɵngcc2.AccordionPanelDirective], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.PipesModule], [typeof ɵngcc1.AccordionComponent, typeof ɵngcc2.AccordionPanelDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AccordionModule>;
}

//# sourceMappingURL=accordion.module.d.ts.map