import { EventEmitter, QueryList } from '@angular/core';
import { AccordionPanelModel } from './accordion-panel.model';
import * as ɵngcc0 from '@angular/core';
export declare class AccordionComponent {
    /**
     * A list of accordion panels.
     */
    panels: QueryList<AccordionPanelModel>;
    /**
     * Event Emitter which emits the component ID and the state of the panel. If the accordion panel has been expanded,
     * the event emitter will return true. Otherwise, false is returned for the expanded property.
     */
    onToggle: EventEmitter<{
        id: string;
        expanded: boolean;
    }>;
    /**
     * Toggles a panel, and sends notification to the parent component that a given panel has been toggled.
     * @param event The event that triggered the toggle panel.
     * @param panel The panel that was clicked on, or that was selected via keyboard navigation.
     * @param shouldToggle Optional property to toggle the accordion panel. Depending on the user interaction, should
     * this panel be toggled? If both the panel's "expanded" state and shouldToggle are true, then the "expanded"
     * property will be set to false and the panel is closed. The is true for the inverse, when the panel is closed, the
     * panel will be expanded.
     */
    togglePanel(event: Event, panel: AccordionPanelModel, shouldToggle?: boolean): void;
    /**
     * Returns the previous panel. If there is only 1 panel, the first panel is returned. If the currently active panel
     * is the first panel, the last panel is returned. Otherwise, the previous panel is returned.
     * @param currentPanel The currently active panel.
     */
    getPreviousPanel(currentPanel: AccordionPanelModel): AccordionPanelModel;
    /**
     * Returns the next panel. If there is only 1 panel, the first panel is returned. If the currently active panel is
     * the last panel, the first panel is returned. Otherwise, the next panel is returned.
     * @param currentPanel The currently active panel.
     */
    getNextPanel(currentPanel: AccordionPanelModel): AccordionPanelModel;
    /**
     * Handles keyboard navigation. Depending on the key that was pressed, the user can navigate the accordion panels
     * using the keyboard for accessibility. Navigation can be accomplished using the Tab, Home, End, Up Arrow and Down
     * Arrow keys. Panels can be expanded and/or collapsed using Enter, Space, Left Arrow or Right Arrow keys. Once a
     * user has entered into the accordion, using the up/down arrow keys will keep the user inside the accordion. The
     * user may exit the accordion by using Tab or Shift + Tab.
     * @param event The keyboard event which contains the key that was pressed.
     * @param panel The currently active panel.
     */
    onKeydown(event: KeyboardEvent, panel: AccordionPanelModel): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AccordionComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AccordionComponent, "lib-accordion", never, {}, { "onToggle": "onToggle"; }, ["panels"], never>;
}

//# sourceMappingURL=accordion.component.d.ts.map