import { TemplateRef } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class AccordionPanelDirective {
    id: string;
    title: string;
    customTitle: TemplateRef<any>;
    customTitleData: object;
    body: TemplateRef<any>;
    expanded?: boolean;
    customPanelClass: string;
    constructor();
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AccordionPanelDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<AccordionPanelDirective, "[libAccordionPanel]", never, { "expanded": "expanded"; "customPanelClass": "customPanelClass"; "id": "id"; "title": "title"; "customTitle": "customTitle"; "customTitleData": "customTitleData"; "body": "body"; }, {}, never>;
}

//# sourceMappingURL=accordion-panel.directive.d.ts.map