import { TemplateRef } from '@angular/core';
export interface AccordionPanelModel {
    id: string;
    title: string;
    customTitle: TemplateRef<any>;
    customTitleData: object;
    body: TemplateRef<any>;
    expanded: boolean;
    customPanelClass: string;
}
