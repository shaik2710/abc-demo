/**
 * Trigger for the accordion component which defines animation states for both expanding and collapsing the accordion panels.
 */
export declare const SlideInOutAnimation: import("@angular/animations").AnimationTriggerMetadata[];
