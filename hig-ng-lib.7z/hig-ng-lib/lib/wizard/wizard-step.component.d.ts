import { EventEmitter } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class WizardStepComponent {
    title: string;
    hidden: boolean;
    isValid: boolean;
    showNext: boolean;
    showPrev: boolean;
    stepCompleted: boolean;
    showProgress: boolean;
    url: string;
    onNext: EventEmitter<any>;
    onPrev: EventEmitter<any>;
    onComplete: EventEmitter<any>;
    private _isActive;
    isDisabled: boolean;
    constructor();
    set isActive(isActive: boolean);
    get isActive(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<WizardStepComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<WizardStepComponent, "lib-wizard-step", never, { "hidden": "hidden"; "isValid": "isValid"; "showNext": "showNext"; "showPrev": "showPrev"; "stepCompleted": "stepCompleted"; "showProgress": "showProgress"; "isActive": "isActive"; "title": "title"; "url": "url"; }, { "onNext": "onNext"; "onPrev": "onPrev"; "onComplete": "onComplete"; }, never, ["*"]>;
}

//# sourceMappingURL=wizard-step.component.d.ts.map