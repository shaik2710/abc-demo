import { EventEmitter } from '@angular/core';
import { WizardComponent } from './wizard.component';
import * as ɵngcc0 from '@angular/core';
export declare class WizardService {
    displayWizard$: EventEmitter<boolean>;
    displayWizard: boolean;
    stepWizard$: EventEmitter<string>;
    labelWizard$: EventEmitter<object>;
    private _wizard;
    constructor();
    setLabel(id: string, title: string, disabled?: boolean): void;
    setDisplayWizard(display: boolean): void;
    isDisplayWizard(): boolean;
    next(): void;
    previous(): void;
    set wizard(wiz: WizardComponent);
    get wizard(): WizardComponent;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<WizardService, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<WizardService>;
}

//# sourceMappingURL=wizard.service.d.ts.map