import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './wizard.component';
import * as ɵngcc2 from './wizard-step.component';
import * as ɵngcc3 from '@angular/common';
export * from './wizard.component';
export * from './wizard-step.component';
export * from './wizard.service';
export declare class WizardModule {
    static forRoot(): ModuleWithProviders<WizardModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<WizardModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<WizardModule, [typeof ɵngcc1.WizardComponent, typeof ɵngcc2.WizardStepComponent], [typeof ɵngcc3.CommonModule], [typeof ɵngcc1.WizardComponent, typeof ɵngcc2.WizardStepComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<WizardModule>;
}

//# sourceMappingURL=wizard.module.d.ts.map