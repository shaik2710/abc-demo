import { EventEmitter, QueryList, AfterContentInit, OnInit, OnDestroy } from '@angular/core';
import { WizardStepComponent } from './wizard-step.component';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import * as ɵngcc0 from '@angular/core';
export declare class WizardComponent implements AfterContentInit, OnInit, OnDestroy {
    private router;
    true: any;
    wizardSteps: QueryList<WizardStepComponent>;
    private unsubscribe;
    routerSubscription: Subscription;
    stepChangeSubscription: Subscription;
    private _steps;
    private _isCompleted;
    displayNav: boolean;
    noHover: boolean;
    showStepNumber: boolean;
    showProgress: boolean;
    onStepChanged: EventEmitter<WizardStepComponent>;
    constructor(router: Router);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    private markActiveStep;
    get steps(): Array<WizardStepComponent>;
    get progress(): Array<WizardStepComponent>;
    get isCompleted(): boolean;
    get activeStep(): WizardStepComponent;
    set activeStep(step: WizardStepComponent);
    get activeStepIndex(): number;
    get hasNextStep(): boolean;
    get hasPrevStep(): boolean;
    goToStep(step: WizardStepComponent): void;
    goToStepByIndex(index: number): void;
    next(): void;
    previous(): void;
    complete(): void;
    /**
     * Reset wizard steps to initialized state
     */
    resetSteps(): void;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<WizardComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<WizardComponent, "lib-wizard", never, { "displayNav": "displayNav"; "noHover": "noHover"; "showStepNumber": "showStepNumber"; "showProgress": "showProgress"; }, { "onStepChanged": "onStepChanged"; }, ["wizardSteps"], ["*"]>;
}

//# sourceMappingURL=wizard.component.d.ts.map