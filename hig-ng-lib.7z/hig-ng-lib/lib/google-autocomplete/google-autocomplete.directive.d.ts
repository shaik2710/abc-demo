import { EventEmitter, AfterViewInit, ElementRef } from '@angular/core';
import { Address } from '../form-fields/model/address';
import { GoogleAutocompleteService } from './google-autocomplete.service';
import * as ɵngcc0 from '@angular/core';
export declare class GoogleAutocompleteDirective implements AfterViewInit {
    private elem;
    private googleAutocompleteService;
    address: Address;
    addressChange: EventEmitter<Address>;
    constructor(elem: ElementRef, googleAutocompleteService: GoogleAutocompleteService);
    ngAfterViewInit(): void;
    /**
     * Handles google auto complete and address change event
     */
    getPlaceAutocomplete(): void;
    /**
     * addressChangeHandle emmit formatted address
     * @param addressComponents
     */
    addressChangeHandle(addressComponents: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GoogleAutocompleteDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GoogleAutocompleteDirective, "[libGoogleAutocomplete]", never, {}, { "addressChange": "addressChange"; }, never>;
}

//# sourceMappingURL=google-autocomplete.directive.d.ts.map