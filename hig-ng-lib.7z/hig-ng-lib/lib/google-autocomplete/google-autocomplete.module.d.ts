import { ModuleWithProviders } from '@angular/core';
import { GoogleConfig } from './api-key-config.service';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './google-autocomplete.directive';
import * as ɵngcc2 from '@angular/common';
export declare class GoogleAutocompleteModule {
    static forRoot(config: GoogleConfig): ModuleWithProviders<GoogleAutocompleteModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GoogleAutocompleteModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<GoogleAutocompleteModule, [typeof ɵngcc1.GoogleAutocompleteDirective], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.GoogleAutocompleteDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<GoogleAutocompleteModule>;
}

//# sourceMappingURL=google-autocomplete.module.d.ts.map