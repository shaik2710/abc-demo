import * as ɵngcc0 from '@angular/core';
export declare class GoogleAutocompleteService {
    private config;
    private scripts;
    constructor(config: any);
    loadScript(name?: string): Promise<unknown>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GoogleAutocompleteService, never>;
}

//# sourceMappingURL=google-autocomplete.service.d.ts.map