import { OnInit } from '@angular/core';
import { HeaderConfig } from './header-config';
import { Router } from '@angular/router';
import * as ɵngcc0 from '@angular/core';
export declare class HeaderComponent implements OnInit {
    headerConfig: HeaderConfig;
    showMobileMenuOptions: boolean;
    mobileDropDown: string;
    protected router: Router;
    constructor(router: Router);
    ngOnInit(): void;
    isActive(instruction: string): boolean;
    navigateUrl(val: string): void;
    toggleMobileMenu(): void;
    toggleMobileDropDown(val: string): void;
    isMobileDropDownOpen(val: string): boolean;
    logout(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HeaderComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<HeaderComponent, "lib-header", never, { "headerConfig": "headerConfig"; }, {}, never, never>;
}

//# sourceMappingURL=header.component.d.ts.map