import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './header.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/router';
export declare class HeaderModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HeaderModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<HeaderModule, [typeof ɵngcc1.HeaderComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.RouterModule], [typeof ɵngcc1.HeaderComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<HeaderModule>;
}

//# sourceMappingURL=header.module.d.ts.map