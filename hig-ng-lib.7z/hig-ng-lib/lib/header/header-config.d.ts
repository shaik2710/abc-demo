export interface HeaderDetails {
    icon?: string;
    label?: string;
    link?: string;
    badge?: number;
    role?: string;
    id?: string;
    isNonNgUrl?: boolean;
    subHeaderDetails?: HeaderDetails[];
}
export interface HeaderConfig {
    primaryNavLeft?: HeaderDetails[];
    primaryNavRight?: HeaderDetails[];
    secondryNav?: HeaderDetails[];
    flatHeaderConfig?: FlatHeaderConfig;
}
export interface FlatHeaderConfig {
    isFlatHeader?: boolean;
    appTitle?: string;
    aisPhoneNumber?: string;
    aisServiceHours?: string;
}
