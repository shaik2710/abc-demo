import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './advanced-grid.component';
import * as ɵngcc2 from './advanced-grid-cell-action/advanced-grid-cell-action.component';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from '../paginator/paginator.module';
import * as ɵngcc5 from '../pipes/pipes.module';
export declare class AdvancedGridModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AdvancedGridModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<AdvancedGridModule, [typeof ɵngcc1.AdvancedGridComponent, typeof ɵngcc2.AdvancedGridCellActionComponent], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.PaginatorModule, typeof ɵngcc5.PipesModule], [typeof ɵngcc1.AdvancedGridComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<AdvancedGridModule>;
}

//# sourceMappingURL=advanced-grid.module.d.ts.map