export interface AdvancedTableHeader {
    fieldName: string;
    fieldLabel?: string;
    columnDataType?: 'string' | 'currency';
    sortable?: boolean;
    filtered?: boolean;
    /**
     * Please make sure to set ViewEncapsulation as None in the consumer component to use a custom class
     */
    customClass?: string;
}
export interface PagingInfo {
    totalRecords: number;
    currentPageNumber: number;
    pageSize: number;
    rowCountOptions: Array<number>;
}
export interface ActionsInfo {
    /**
     * Actions such as Accept; Select; Edit
     */
    columnActionOptions?: Array<string>;
    columnActionIdField?: string;
    columnActionSelectField?: string;
    showActionColumnHeader?: boolean;
    columnActionOccurred?: Function;
    enablePaginationBarSubmit?: boolean;
    disableSelectAll?: boolean;
    paginationBarSubmitLabel?: string;
    paginationBarSubmitTriggered?: Function;
}
export interface AdvancedGridCellActionInfo {
    record?: any;
    header?: string;
    showActionHeader?: boolean;
    actionHeaderDisabled?: boolean;
    actionSelectIndicator?: string;
    actionIdField?: string;
    actionRecord?: Function;
    selectAllChecked?: boolean;
}
