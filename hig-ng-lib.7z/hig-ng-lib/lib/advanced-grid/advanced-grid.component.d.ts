import { ChangeDetectorRef, EventEmitter, OnChanges, OnDestroy, OnInit, Renderer2, SimpleChanges, TemplateRef } from '@angular/core';
import { ActionsInfo, AdvancedGridCellActionInfo, AdvancedTableHeader, PagingInfo } from './advanced-grid.model';
import { PaginatorComponent } from '../paginator/paginator.component';
import * as ɵngcc0 from '@angular/core';
export interface Viewport {
    type: 'HTMLElement' | 'Window';
    scrollContainer: HTMLElement | Window;
    target: HTMLElement | HTMLBodyElement;
}
/** @dynamic */
export declare class AdvancedGridComponent implements OnInit, OnChanges, OnDestroy {
    private renderer;
    private cdr;
    private document;
    static RENDER_DELAY: number;
    datasource: Array<any | {
        [key: string]: string;
    }>;
    primaryKey: string;
    tableHeaders: Array<AdvancedTableHeader>;
    pagingInfo: PagingInfo;
    sortHeader?: string;
    sortDir?: string;
    actionsInfo: ActionsInfo;
    getDisplayTextForHeaderField: Function;
    getDisplayTextForRecordField: Function;
    numberOfFixedColumns: number;
    viewPortContainer: string;
    customColumns: {
        [key: string]: TemplateRef<any>;
    };
    pageOrSortChanged: EventEmitter<{
        pagingInfo: PagingInfo;
        sortHeader?: string;
        sortDir?: string;
    }>;
    table: any;
    tableClone: any;
    tableHeaderFixed: any;
    paginatorTop: any;
    paginatorComponent: PaginatorComponent;
    set setPaginatorComponent(comp: PaginatorComponent);
    scrollTop: any;
    scrollBottom: any;
    fixedTableHeaders: Array<any>;
    paginatorTopOffset: number;
    nativeWindow: any;
    selectAllCheckbox: any;
    private viewport;
    private resizeSubject;
    private resizeObservable;
    private unsubscribe;
    constructor(renderer: Renderer2, cdr: ChangeDetectorRef, document: Document);
    ngOnInit(): void;
    trackByFn(index: number, item: any): any;
    getViewport(): Viewport;
    onResize(width: number): void;
    getYPosition(): number;
    /**
     *  makes the table header and pagination container "sticky"
     */
    onViewPortScroll(viewport: HTMLElement | Window): void;
    fitHeaderToWindowTop(pageYOffset: number): void;
    /**
     * syncs the top and bottom scrollbar for table horizontal scrolling and moves the sticky header horizontally
     * @param from
     * @param to
     */
    onDivScroll(from: string, to: string): void;
    ngOnChanges(changes: SimpleChanges): void;
    defaultDisplayText(text: string): string;
    isFixedColumn(index: any): boolean;
    selectAllActionEventHandler: (event: any) => void;
    actionRecord(action: string, record?: any, selected?: any): void;
    /**
     * Determines if all records are currently selected.
     *
     * @remarks
     * Will return `false` if `datasource` is "falsy".
     * @returns `true` if all records are selected; `false` otherwise.
     */
    areAllRecordsSelected(): boolean;
    loadAdvGridCellActionInfo(actionHeader: string, isHeaderCell: boolean, record?: any): AdvancedGridCellActionInfo;
    /**
     * Computer the fixed headers to render the clone table
     */
    updateFixedHeaders(): void;
    /**
     * Computer the string value for a TD ngclass object
     *
     * @column (number) - id of the column
     * @row (number) - id of the row, -1 if header in thead
     * @header (String) - value of header text
     */
    computeClassesForTd(column: number, row: number, header: AdvancedTableHeader): string;
    sortEventHandler: (event: any) => void;
    /**
     * Sorting handler. Sets the sorting params for even emitter which in turn triggers the functionality that fetches sorted data
     * @param headerFieldId
     */
    sortBy(headerFieldId: any): void;
    /**
     * Checked if the given column header is sortable
     * @param fieldId
     */
    isSortableHeader(fieldId: string): boolean;
    /**
     * Returns the scss classes required to show sort icons based on the asc/desc behavior
     * @param header
     */
    getSortableClasses(header: AdvancedTableHeader): string;
    /**
     * Clones the existing array and chooses a sub section of the record to display
     */
    updateFixedContent(changes?: SimpleChanges): void;
    /**
     * Handle pagination changes
     */
    onPaginationChange(page: any): void;
    /**
     *
     * This builds a clone of all the objects marked as "fixed-column" and over lays it on top of the existing table,
     * then makes a clone of the table headers to be sticky
     */
    computedFixedColumns(changes?: SimpleChanges): void;
    /**
     * Removes width and max-width from the table and table clone if `this.table` exists.
     */
    removeTableWidthStyles(): void;
    /**
     * This prepares the fixed column's widths, meant to be a helper for
     * `computedFixedColumns()`.
     * @see computedFixedColumns
     */
    prepareFixedColumns(): void;
    /**
     * This clones the table headers for sticky placement
     */
    computeFixedHeader(): void;
    setStickyOffsetPosition(): any;
    triggerHeaderAction(): void;
    /**
     * Helper method to clone a given table headers
     * @param sourceTable
     */
    cloneTableHead(sourceTable: any): void;
    /**
     * Assign style properties to the cloned object and the fixed object
     */
    copySizeToClone(fixedEl: any, cloneEl: any): void;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AdvancedGridComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AdvancedGridComponent, "lib-advanced-grid", never, { "primaryKey": "primaryKey"; "pagingInfo": "pagingInfo"; "actionsInfo": "actionsInfo"; "getDisplayTextForHeaderField": "getDisplayTextForHeaderField"; "getDisplayTextForRecordField": "getDisplayTextForRecordField"; "sortDir": "sortDir"; "sortHeader": "sortHeader"; "datasource": "datasource"; "tableHeaders": "tableHeaders"; "numberOfFixedColumns": "numberOfFixedColumns"; "viewPortContainer": "viewPortContainer"; "customColumns": "customColumns"; }, { "pageOrSortChanged": "pageOrSortChanged"; }, never, never>;
}

//# sourceMappingURL=advanced-grid.component.d.ts.map