import { AdvancedGridCellActionInfo } from '../advanced-grid.model';
import * as ɵngcc0 from '@angular/core';
export declare class AdvancedGridCellActionComponent {
    cellActionInfo: AdvancedGridCellActionInfo;
    editRecord(): void;
    toggleRecordSelect(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<AdvancedGridCellActionComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<AdvancedGridCellActionComponent, "lib-advanced-grid-cell-action", never, { "cellActionInfo": "cellActionInfo"; }, {}, never, never>;
}

//# sourceMappingURL=advanced-grid-cell-action.component.d.ts.map