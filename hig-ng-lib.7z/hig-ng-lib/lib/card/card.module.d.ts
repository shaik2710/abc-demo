import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './card.component';
import * as ɵngcc2 from '@angular/common';
export declare class CardModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CardModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<CardModule, [typeof ɵngcc1.CardComponent], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.CardComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<CardModule>;
}

//# sourceMappingURL=card.module.d.ts.map