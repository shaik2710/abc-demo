import * as ɵngcc0 from '@angular/core';
export declare class CardComponent {
    cardClass: string;
    borderClass: string;
    innerPadding: boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CardComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<CardComponent, "lib-card", never, { "cardClass": "cardClass"; "borderClass": "borderClass"; "innerPadding": "innerPadding"; }, {}, never, ["[left-title]", "[right-title]", "[card-content-container]"]>;
}

//# sourceMappingURL=card.component.d.ts.map