import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './grid.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '../tooltip/tooltip.module';
export declare class GridModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<GridModule, [typeof ɵngcc1.GridComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.HigTooltipModule], [typeof ɵngcc1.GridComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<GridModule>;
}

//# sourceMappingURL=grid.module.d.ts.map