/**
 * Options for the grid.
 */
export interface GridOptions {
    /**
     * The text to show to expand the accordion.
     *
     * @since 4.0.33
     */
    expandText?: string;
    /**
     * The text to show to collapse the accordion.
     *
     * @since 4.0.33
     */
    collapseText?: string;
    /**
     * The alignment for the expand/collapse toggle link.
     *
     * @since 4.0.33
     */
    toggleTextAlign?: "left" | "right" | "center";
    /**
     * Determines if the table is expanded.
     *
     * @remarks
     * You can set this to `true` initially to have the table expanded
     * by default. By default, it is collapsed.
     * @since 4.0.33
     */
    expanded?: boolean;
    /**
     * Determines whether or not to show the caret icons after
     * the Show More/Show Less text.
     *
     * @since 4.0.33
     */
    showCaretIcons?: boolean;
}
