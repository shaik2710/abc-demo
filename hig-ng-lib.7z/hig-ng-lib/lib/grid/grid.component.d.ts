import { TemplateRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { GridOptions } from './grid.model';
import * as ɵngcc0 from '@angular/core';
export declare class GridComponent implements OnChanges {
    columnTemplates: TemplateRef<any>[];
    rowTemplate: TemplateRef<any>;
    hasCustomField: boolean;
    showHeader: boolean;
    showFooter: boolean;
    showMinRecords: boolean;
    tableCustomClass: string;
    tableCaption: string;
    selectOptionsID: string;
    orderBy: {
        sortBy: string;
        sortDirection: string;
    };
    /**
     * Determines if the table can only be expanded. Once expanded, will
     * not be able to collapse the grid.
     *
     * @remarks
     * Once expanded, you will not be able to collapse the grid when this is
     * set to `true`.
     */
    showPagination: boolean;
    /**
     * The number of rows to show when collapsed [default].
     *
     * @remarks
     * This does not include the footer or header rows. If this number
     * is less than or equal to the total number of rows, then the
     * accordion toggle will not appear on the screen.
     */
    itemPerPage: number;
    dataSource: any;
    columnHeaders: any;
    showTogglePagination: boolean;
    /**
     * Display options for the Grid.
     *
     * @since 4.0.33
     */
    gridOptions: GridOptions;
    /**
     * should we use a custom trackBy function?
     */
    useTrackBy: boolean;
    /**
     * unique-key used for trackBy performance optimization for *ngFor loops
     */
    primaryKey: string;
    onSort: EventEmitter<any>;
    /**
     * Event for when a table gets expanded or collapsed.
     *
     * @since 4.0.33
     */
    onToggle: EventEmitter<any>;
    showSortOptionForMobile: boolean;
    itemCounter: number;
    displayOnlyShowMore: boolean;
    displayTogglePagination: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Update paginations options on page load
     */
    updatePaginations(): void;
    /**
     *  getSortableClasses
     * @param column
     */
    getSortableClasses(column: any): string;
    /**
     * sortList
     * @param column
     * @param toggleDirection
     */
    sortList(event: any, column: any, toggleDirection: boolean): void;
    /**
     * sortListMobile
     * @param field
     */
    sortListMobile(field: string): void;
    /**
     * showMore method for pagination
     */
    showMore(): void;
    /**
     * Expands or collapses the table.
     *
     * @since 4.0.33
     */
    accordionToggle(): void;
    /**
     * performance optimization for *ngFor used throughout template
     * @param index
     * @param item
     */
    trackByFn(index: number, item: any): any;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<GridComponent, "lib-grid", never, { "showHeader": "showHeader"; "showFooter": "showFooter"; "showMinRecords": "showMinRecords"; "tableCustomClass": "tableCustomClass"; "tableCaption": "tableCaption"; "selectOptionsID": "selectOptionsID"; "orderBy": "orderBy"; "showPagination": "showPagination"; "showTogglePagination": "showTogglePagination"; "gridOptions": "gridOptions"; "primaryKey": "primaryKey"; "itemPerPage": "itemPerPage"; "columnTemplates": "columnTemplates"; "rowTemplate": "rowTemplate"; "hasCustomField": "hasCustomField"; "dataSource": "dataSource"; "columnHeaders": "columnHeaders"; "useTrackBy": "useTrackBy"; }, { "onSort": "onSort"; "onToggle": "onToggle"; }, never, never>;
}

//# sourceMappingURL=grid.component.d.ts.map