import * as ɵngcc0 from '@angular/core';
export declare class LoggerConfig {
    env?: string;
}
export declare class HigLoggerService {
    env: string;
    constructor(config?: LoggerConfig);
    log(...args: any[]): void;
    debug(...args: any[]): any;
    error(...args: any[]): void;
    table(...args: any[]): void;
    isTestingEnv(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HigLoggerService, [{ optional: true; }]>;
}

//# sourceMappingURL=logger.service.d.ts.map