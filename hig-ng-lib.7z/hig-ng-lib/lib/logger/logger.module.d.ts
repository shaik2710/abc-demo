import { ModuleWithProviders } from '@angular/core';
import { LoggerConfig } from './logger.service';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/common';
export declare class HigLoggerModule {
    static forRoot(config?: LoggerConfig): ModuleWithProviders<HigLoggerModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HigLoggerModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<HigLoggerModule, never, [typeof ɵngcc1.CommonModule], never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<HigLoggerModule>;
}

//# sourceMappingURL=logger.module.d.ts.map