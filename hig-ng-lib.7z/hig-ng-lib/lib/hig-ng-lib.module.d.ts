import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/common';
import * as ɵngcc2 from '@angular/platform-browser';
export declare class HigNgLibModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HigNgLibModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<HigNgLibModule, never, [typeof ɵngcc1.CommonModule, typeof ɵngcc2.BrowserModule], never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<HigNgLibModule>;
}

//# sourceMappingURL=hig-ng-lib.module.d.ts.map