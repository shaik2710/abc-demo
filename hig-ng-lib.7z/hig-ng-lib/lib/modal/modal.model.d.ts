export declare class Element {
    type: 'button' | 'link';
    html: string;
    elementClass?: string;
    elementCallback?: Function;
}
