import { Subject } from 'rxjs';
import * as ɵngcc0 from '@angular/core';
export declare class ModalScrollService {
    isScrollableSubject: Subject<boolean>;
    private scrollStatus;
    /**
     * Set the status is scrollable by modal name
     */
    setModalScroll(modalKey: string, allowScrolling: boolean): void;
    /**
     * Returns scrollable status, if any no scrolls are in place prevent it from scrolling
     */
    isScrollable(): boolean;
    /**
     * Returns the observable for subscriptions
     */
    getScrollableObservable(): Subject<boolean>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ModalScrollService, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<ModalScrollService>;
}

//# sourceMappingURL=modal-scroll.service.d.ts.map