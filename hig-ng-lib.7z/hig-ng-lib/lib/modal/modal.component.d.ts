import { OnInit, OnChanges, SimpleChange } from '@angular/core';
import { Element } from './modal.model';
import { ModalScrollService } from './modal-scroll.service';
import * as ɵngcc0 from '@angular/core';
export declare class ModalComponent implements OnInit, OnChanges {
    private modalScrollService;
    header: string;
    headerSubtext: string;
    body: string;
    dismissibleCallback: Function;
    elements?: Array<Element>;
    showModal: boolean;
    modalName?: string;
    modalSize?: string;
    modalType?: 'danger' | 'warning';
    layoutClasses: string;
    showDismissButton: Boolean;
    constructor(modalScrollService: ModalScrollService);
    ngOnInit(): void;
    ngOnChanges(changes: {
        [propKey: string]: SimpleChange;
    }): void;
    elementClicked(element: Element): void;
    setElementClass(): void;
    getModalType(): "" | "modal-dialog-content-alert-danger" | "modal-dialog-content-alert";
    closeModal(): void;
    getModalSize(): string;
    getModalDialogClasses(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ModalComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<ModalComponent, "lib-modal", never, { "modalName": "modalName"; "showModal": "showModal"; "header": "header"; "headerSubtext": "headerSubtext"; "body": "body"; "dismissibleCallback": "dismissibleCallback"; "elements": "elements"; "modalSize": "modalSize"; "modalType": "modalType"; }, {}, never, never>;
}

//# sourceMappingURL=modal.component.d.ts.map