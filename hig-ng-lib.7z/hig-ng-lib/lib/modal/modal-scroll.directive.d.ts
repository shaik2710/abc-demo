import { ElementRef, Renderer2 } from '@angular/core';
import { ModalScrollService } from './modal-scroll.service';
import * as ɵngcc0 from '@angular/core';
export declare class ModalScrollDirective {
    private el;
    private render;
    private scrollService;
    bodyScroll: true;
    constructor(el: ElementRef, render: Renderer2, scrollService: ModalScrollService);
    /**
     * Determine if a scroll should be allowed and append approriate style
     */
    allowScroll(scrollable: boolean): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ModalScrollDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<ModalScrollDirective, "[libAppModalScroll]", never, { "bodyScroll": "bodyScroll"; }, {}, never>;
}

//# sourceMappingURL=modal-scroll.directive.d.ts.map