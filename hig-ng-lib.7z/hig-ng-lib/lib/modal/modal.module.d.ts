import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './modal.component';
import * as ɵngcc2 from './modal-scroll.directive';
import * as ɵngcc3 from '@angular/common';
export declare class HiguxModalModule {
    static forRoot(): ModuleWithProviders<HiguxModalModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<HiguxModalModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<HiguxModalModule, [typeof ɵngcc1.ModalComponent, typeof ɵngcc2.ModalScrollDirective], [typeof ɵngcc3.CommonModule], [typeof ɵngcc1.ModalComponent, typeof ɵngcc2.ModalScrollDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<HiguxModalModule>;
}

//# sourceMappingURL=modal.module.d.ts.map