import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './safe.pipe';
export declare class PipesModule {
    static forRoot(): ({
        ngModule: typeof PipesModule;
        providers: any[];
    })&{ngModule:PipesModule};
    static ɵfac: ɵngcc0.ɵɵFactoryDef<PipesModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<PipesModule, [typeof ɵngcc1.SafePipe], never, [typeof ɵngcc1.SafePipe]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<PipesModule>;
}

//# sourceMappingURL=pipes.module.d.ts.map