import { PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml, SafeStyle, SafeScript, SafeUrl, SafeResourceUrl } from '@angular/platform-browser';
import * as ɵngcc0 from '@angular/core';
export declare class SafePipe implements PipeTransform {
    protected _sanitizer: DomSanitizer;
    constructor(_sanitizer: DomSanitizer);
    transform(value: string, type: string): SafeHtml | SafeStyle | SafeScript | SafeUrl | SafeResourceUrl;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<SafePipe, never>;
    static ɵpipe: ɵngcc0.ɵɵPipeDefWithMeta<SafePipe, "safe">;
}

//# sourceMappingURL=safe.pipe.d.ts.map