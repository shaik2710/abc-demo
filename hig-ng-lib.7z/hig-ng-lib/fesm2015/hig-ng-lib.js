import { __decorate, __metadata, __param } from 'tslib';
import { ɵɵdefineInjectable, Injectable, NgModule, Input, Component, EventEmitter, TemplateRef, Output, ElementRef, ViewEncapsulation, Renderer2, ChangeDetectorRef, Inject, ViewChild, HostListener, ChangeDetectionStrategy, SecurityContext, Pipe, InjectionToken, ɵɵinject, Directive, Optional, CUSTOM_ELEMENTS_SCHEMA, HostBinding, forwardRef, KeyValueDiffers, ComponentFactoryResolver, ViewContainerRef, Injector, ContentChildren, QueryList } from '@angular/core';
import { CommonModule, DOCUMENT, DecimalPipe, TitleCasePipe } from '@angular/common';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { Router, RouterModule, NavigationEnd, NavigationCancel, ActivatedRoute } from '@angular/router';
import { TealiumDataService, TealiumModule } from 'ng-tealium';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { FormsModule, ReactiveFormsModule, Validators, FormControl, FormGroup, FormArray, FormBuilder, NG_VALUE_ACCESSOR, NgControl } from '@angular/forms';
import { Subject, interval, fromEvent, combineLatest, Subscription, throwError, of as of$1, BehaviorSubject } from 'rxjs';
import { switchMap, scan, tap, takeWhile, debounceTime, takeUntil, filter, map, shareReplay, catchError, distinctUntilChanged } from 'rxjs/operators';
import { of } from 'rxjs/internal/observable/of';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgOptionHighlightModule } from '@ng-select/ng-option-highlight';
import { HttpHeaders, HttpParams, HttpClient } from '@angular/common/http';
import { trigger, state, style, transition, group, animate } from '@angular/animations';

let HigNgLibService = class HigNgLibService {
    constructor() { }
};
HigNgLibService.ɵprov = ɵɵdefineInjectable({ factory: function HigNgLibService_Factory() { return new HigNgLibService(); }, token: HigNgLibService, providedIn: "root" });
HigNgLibService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [])
], HigNgLibService);

let HigNgLibModule = class HigNgLibModule {
};
HigNgLibModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            BrowserModule
        ],
        declarations: []
    })
], HigNgLibModule);

let FooterComponent = class FooterComponent {
    constructor() {
        this.contactUsLink = 'https://www.thehartford.com/contact-the-hartford';
        this.contactUsLinkLabel = 'Contact Us';
        this.legalNoticeLink = 'https://www.thehartford.com/legal-notice';
        this.legalNoticeLinkLabel = 'Legal Notice';
        this.privacyPolicyLink = 'https://www.thehartford.com/online-privacy-policy';
        this.privacyPolicyLinkLabel = 'Privacy Policy';
        this.accessibilityStatementLink = 'https://www.thehartford.com/accessibility-statement';
        this.accessibilityStatementLinkLabel = 'Accessibility Statement';
        this.poweredBy = true;
    }
    ngOnInit() {
        this.currentDate = new Date().getFullYear();
    }
};
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "contactUsLink", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "contactUsLinkLabel", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "legalNoticeLink", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "legalNoticeLinkLabel", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "privacyPolicyLink", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "privacyPolicyLinkLabel", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "accessibilityStatementLink", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "accessibilityStatementLinkLabel", void 0);
__decorate([
    Input(),
    __metadata("design:type", Number)
], FooterComponent.prototype, "currentDate", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FooterComponent.prototype, "poweredBy", void 0);
FooterComponent = __decorate([
    Component({
        selector: 'lib-footer',
        template: "<footer class=\"footer footer-thin\" id=\"Footer_Container_Footer\">\n  <div class=\"container\">\n    <div class=\"row content-row\">\n      <div class=\"col-md-8 col-md-offset-2\">\n        <ul class=\"links list-inline\">\n          <li *ngIf=\"contactUsLink\"><a href=\"{{contactUsLink}}\" target=\"_blank\">{{contactUsLinkLabel}}</a></li>\n          <li *ngIf=\"privacyPolicyLink\"><a href=\"{{privacyPolicyLink}}\" target=\"_blank\">{{privacyPolicyLinkLabel}}</a></li>\n          <li *ngIf=\"legalNoticeLink\"><a href=\"{{legalNoticeLink}}\" target=\"_blank\">{{legalNoticeLinkLabel}}</a></li>\n          <li *ngIf=\"accessibilityStatementLink\"><a href=\"{{accessibilityStatementLink}}\" target=\"_blank\">{{accessibilityStatementLinkLabel}}</a></li>\n        </ul>\n        <p class=\"copyright\">\u00A9 {{currentDate}} The Hartford. All Rights Reserved.</p>\n      </div>\n      <div *ngIf=\"poweredBy\" class=\"col-md-2\">\n        <img src=\"https://s0.hfdstatic.com/sites/higux/dist/images/norton.svg\" alt=\"Norton Secured - Powered by VeriSign\" class=\"norton\">\n      </div>\n    </div>\n  </div>\n</footer>\n"
    }),
    __metadata("design:paramtypes", [])
], FooterComponent);

let FooterModule = class FooterModule {
};
FooterModule = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        declarations: [FooterComponent],
        exports: [FooterComponent]
    })
], FooterModule);

let HeaderComponent = class HeaderComponent {
    constructor(router) {
        this.showMobileMenuOptions = false;
        this.router = router;
    }
    ngOnInit() {
    }
    isActive(instruction) {
        return this.router.isActive(instruction, false);
    }
    navigateUrl(val) {
        this.router.navigate([val]);
    }
    toggleMobileMenu() {
        this.showMobileMenuOptions = !this.showMobileMenuOptions;
    }
    toggleMobileDropDown(val) {
        if (this.mobileDropDown === val) {
            this.mobileDropDown = '';
        }
        else {
            this.mobileDropDown = val;
        }
    }
    isMobileDropDownOpen(val) {
        return this.showMobileMenuOptions && this.mobileDropDown === val;
    }
    // stub method to be overridden by application class method
    logout() {
        this.navigateUrl('/');
    }
};
HeaderComponent.ctorParameters = () => [
    { type: Router }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], HeaderComponent.prototype, "headerConfig", void 0);
HeaderComponent = __decorate([
    Component({
        selector: 'lib-header',
        template: "  <ng-container *ngIf=\"headerConfig?.flatHeaderConfig?.isFlatHeader\">\n  <div class=\"navbar-primary\" id=\"Header_Container_Header\">\n     <div id=\"Header_Container_Header\" class=\"container\" > \n      <div class=\"row\">\n        <div class=\"navbar-header horizontal\">\n          <div class=\"navbar-brand\">\n            <img alt=\"The Hartford\" src=\"https://s0.hfdstatic.com/sites/higux/v3.3.43/images/logo_sm_hig.svg\">\n          </div>\n        </div>\n      </div>\n    </div>\n    <header class=\"navbar navbar-default collapse navbar-collapse horizontal\" id=\"Header_Header_NavBar\">\n      <div class=\"navbar-primary\" id=\"Header_Container_PrimaryNav\">\n        <div class=\"container\">\n          <div class=\"row\">\n            <div class=\"nav navbar-nav navbar-left navbar-title\">\n              <span>{{headerConfig.flatHeaderConfig.appTitle}}</span>\n            </div>\n            <div class=\"pull-right navbar-support\">\n              <div class=\"tech-support\">Technical Support {{headerConfig.flatHeaderConfig.aisPhoneNumber}}</div>\n              <div>{{headerConfig.flatHeaderConfig.aisServiceHours}}</div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </header>\n </div>\n</ng-container> \n<ng-container *ngIf=\"!headerConfig?.flatHeaderConfig?.isFlatHeader\">\n <div id=\"Header_Container_Header\" class=\"container\">\n  <div class=\"row\">\n    <div class=\"navbar-header\">\n      <button type=\"button\" (click)=\"toggleMobileMenu()\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navBar\" aria-expanded=\"false\">\n        <span class=\"sr-only\">Toggle navigation</span>\n        <i class=\"icon icon-menu\" aria-hidden=\"true\"></i>\n      </button>\n      <a class=\"navbar-brand\" (click)=\"navigateUrl('/')\" role=\"button\">\n        <img alt=\"The Hartford\" src=\"https://s0.hfdstatic.com/sites/higux/dist/images/logo.svg\">\n      </a>\n    </div>\n  </div>\n </div>\n  <header class=\"navbar navbar-default collapse navbar-collapse\" id=\"Header_Header_NavBar\" [ngClass]=\"{'in':showMobileMenuOptions}\">\n    <div class=\"navbar-primary\" id=\"Header_Container_PrimaryNav\" *ngIf=\"headerConfig\">\n      <div class=\"container\">\n        <div class=\"row\">\n          <ul class=\"nav navbar-nav navbar-left\" *ngIf=\"headerConfig.primaryNavLeft\">\n            <button id=\"Header_Button_ToggleNavigation\" type=\"button\" (click)=\"toggleMobileMenu()\" class=\"navbar-toggle-close collapsed\" data-toggle=\"collapse\" data-target=\"#navBar\" aria-expanded=\"false\">\n              <span class=\"sr-only\">Toggle navigation</span>\n              <i class=\"icon icon-close\"></i>\n            </button>\n            <li class=\"dropdown\" *ngFor=\"let menu of headerConfig.primaryNavLeft\">\n              <a [ngClass]=\"{'hide-dropdown-toggle': !menu.subHeaderDetails}\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n                <span [innerHTML]=\"menu.label\"></span>\n                <i class=\"icon icon-double-caret\" aria-hidden=\"true\"></i>\n              </a>\n              <ul class=\"dropdown-menu\" *ngIf=\"menu.subHeaderDetails\">\n                <ng-container *ngFor=\"let subMenu of menu.subHeaderDetails\">\n                  <ng-container *ngIf=\"subMenu.role ==='separator'; else submenu\">\n                      <li role=\"separator\" class=\"divider\"></li>\n                  </ng-container>\n                  <ng-template #submenu>\n                    <li>\n                      <a [id]=\"subMenu.id ? subMenu.id : null\" (click)=\"navigateUrl(subMenu.link)\">{{subMenu.label}}</a>\n                    </li>\n                  </ng-template>\n                </ng-container>\n              </ul>\n            </li>\n          </ul>\n          <ul class=\"nav navbar-nav navbar-icons navbar-right\" *ngIf=\"headerConfig.primaryNavRight\">\n            <ng-container *ngFor=\"let menu of headerConfig.primaryNavRight\">\n              <ng-container *ngIf=\"menu.subHeaderDetails; else rightMenuLink\">\n                  <li class=\"dropdown hidden-sm hidden-xs\">\n                      <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n                        <i [ngClass]=\"{'hidden':!menu.icon}\" class=\"icon {{menu.icon}}\">\n                          <span class=\"sr-only\">{{menu.label}}</span>\n                        </i>\n                      </a>\n                      <ul class=\"dropdown-menu\" *ngIf=\"menu.subHeaderDetails\">\n                        <li *ngFor=\"let subMenu of menu.subHeaderDetails\">\n                          <a *ngIf=\"!subMenu.isNonNgUrl\" [id]=\"subMenu.id ? subMenu.id : null\" (click)=\"navigateUrl(subMenu.link)\">{{subMenu.label}}</a>\n                          <a *ngIf=\"subMenu.isNonNgUrl\" [id]=\"subMenu.id ? subMenu.id : null\" href=\"{{subMenu.link}}\" >{{subMenu.label}}</a>\n                        </li>\n                      </ul>\n                    </li>\n              </ng-container>\n              <ng-template #rightMenuLink>\n                  <li>\n                      <a [id]=\"menu.id ? menu.id : null\" (click)=\"navigateUrl(menu.link)\">\n                        <i [ngClass]=\"{'hidden':!menu.icon}\" class=\"icon {{menu.icon}}\">\n                          <span class=\"badge\" *ngIf=\"menu.badge\">{{menu.badge}}</span>\n                        </i>\n                        <span>{{menu.label}}</span>\n                      </a>\n                    </li>\n              </ng-template>\n            </ng-container>\n          </ul>\n        </div>\n      </div>\n    </div>\n    <div class=\"navbar-secondary\" id=\"Header_Container_SecondaryNav\">\n      <div class=\"container\">\n        <div class=\"row\">\n          <ul class=\"nav navbar-nav\" *ngIf=\"headerConfig.secondryNav  || headerConfig.primaryNavRight\">\n            <ng-container *ngFor=\"let menu of headerConfig.secondryNav\">\n                <li class=\"dropdown\" [ngClass]=\"{'dropdown-active': isActive(menu.link), 'open': isMobileDropDownOpen(menu.link)}\" (click)=\"toggleMobileDropDown(menu.link)\">\n                  <a [id]=\"menu.id ? menu.id : null\" [ngClass]=\"{'dropdown-hasmenu': menu.subHeaderDetails, 'no-icon': !menu.subHeaderDetails}\" (click)=\"navigateUrl(menu.link)\" class=\"dropdown-toggle disabled\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n                    <i [ngClass]=\"{'hidden':!menu.icon}\" class=\"icon {{menu.icon}}\" aria-hidden=\"true\"></i>\n                    <span>{{menu.label}}</span>\n                  </a>\n                  <div class=\"dropdown-menu\" *ngIf=\"menu.subHeaderDetails\">\n                    <div class=\"mega-menu\">\n                      <div class=\"col-md-6 mega-menu-left\">\n                        <ul>\n                          <li *ngFor=\"let submenu of menu.subHeaderDetails\">\n                            <a [id]=\"submenu.id ? submenu.id : null\" (click)=\"navigateUrl(submenu.link)\">{{submenu.label}}</a>\n                          </li>\n                        </ul>\n                      </div>\n                    </div>\n                  </div>\n                </li>\n            </ng-container>\n            <ng-container *ngFor=\"let menu of headerConfig.primaryNavRight\">\n              <li class=\"visible-xs visible-sm\">\n                <a [id]=\"menu.id ? menu.id : null\" (click)=\"navigateUrl(menu.link)\">\n                  <i [ngClass]=\"{'hidden':!menu.icon}\" class=\"icon {{menu.icon}}\"></i>\n                  <span>{{menu.label}}</span>\n                </a>\n              </li>\n              <li class=\"visible-xs visible-sm\" *ngFor=\"let subMenu of menu.subHeaderDetails\">\n                  <a [id]=\"subMenu.id ? subMenu.id : null\" (click)=\"navigateUrl(subMenu.link)\">\n                    <i [ngClass]=\"{'hidden':!subMenu.icon}\" class=\"icon {{subMenu.icon}}\"></i>\n                    <span>{{subMenu.label}}</span>\n                  </a>\n                </li>\n            </ng-container>\n          </ul>\n          <div class=\"mobile-logout\">\n            <a id=\"Header_HyperLink_Logout\" (click)=\"logout()\">\n              <button class=\"btn btn-secondary-paired btn-block\">Logout</button>\n            </a>\n          </div>\n        </div>\n      </div>\n    </div>\n  </header>\n</ng-container>\n ",
        styles: [".navbar-default .hide-dropdown-toggle{cursor:default}.navbar-default .hide-dropdown-toggle .icon-double-caret{display:none}.navbar-default .navbar-secondary .dropdown:focus .dropdown-menu,.navbar-default .navbar-secondary .dropdown:hover .dropdown-menu{margin-top:-4px}.navbar-default .navbar-secondary .dropdown a{cursor:pointer}.navbar-default .navbar-secondary .dropdown-active:focus .dropdown-menu,.navbar-default .navbar-secondary .dropdown-active:hover .dropdown-menu{margin-top:0}.navbar-default .navbar-secondary .dropdown-active .mega-menu-left{border-top:0}@media (min-width:992px){.navbar-default .navbar-secondary .dropdown{height:61px}.navbar-header.horizontal .navbar-brand{padding-left:0}}.navbar-header.horizontal .navbar-brand{border:none;margin-top:0}.navbar-header.horizontal .navbar-brand img{width:207px;height:36px}.navbar-default.horizontal{border-bottom:.5em solid #b6d3e9}.navbar-default.horizontal .navbar-primary{background-color:#fff}.navbar-default.horizontal .navbar-primary .navbar-left{padding-left:15.62em}.navbar-default.horizontal .navbar-primary .navbar-left span{font-size:1.25em;font-weight:500;line-height:2.25em}.navbar-default.horizontal .navbar-primary .navbar-title{padding-top:1em}.navbar-default.horizontal .navbar-primary .navbar-support{padding-top:.9375em;font-size:.875em}.navbar-default.horizontal .navbar-primary .navbar-support .tech-support{font-weight:500}.ais-contact{position:relative;color:#3a5a78;font-size:.875em;z-index:11}.ais-contact-info{position:absolute;top:-5em;right:0;font-weight:400}.ais-contact-info>:first-child{font-weight:500}"]
    }),
    __metadata("design:paramtypes", [Router])
], HeaderComponent);

let HeaderModule = class HeaderModule {
};
HeaderModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            RouterModule
        ],
        declarations: [HeaderComponent],
        exports: [HeaderComponent]
    })
], HeaderModule);

let GridComponent = class GridComponent {
    constructor() {
        this.showHeader = true;
        this.showFooter = false;
        this.showMinRecords = true;
        this.tableCustomClass = 'table-striped';
        this.tableCaption = '';
        this.selectOptionsID = 'selectOptionsID'; // for backwards compatibility sake, so we don't break it in other areas
        this.orderBy = { sortBy: '', sortDirection: 'desc' };
        /**
         * Determines if the table can only be expanded. Once expanded, will
         * not be able to collapse the grid.
         *
         * @remarks
         * Once expanded, you will not be able to collapse the grid when this is
         * set to `true`.
         */
        this.showPagination = false;
        this.showTogglePagination = false;
        /**
         * Display options for the Grid.
         *
         * @since 4.0.33
         */
        this.gridOptions = {
            expanded: false,
            expandText: 'Show More',
            collapseText: 'Show Less',
            toggleTextAlign: 'center',
            showCaretIcons: true,
        };
        /**
         * unique-key used for trackBy performance optimization for *ngFor loops
         */
        this.primaryKey = 'id';
        this.onSort = new EventEmitter();
        /**
         * Event for when a table gets expanded or collapsed.
         *
         * @since 4.0.33
         */
        this.onToggle = new EventEmitter();
        this.showSortOptionForMobile = false;
        this.displayOnlyShowMore = false;
        this.displayTogglePagination = false;
    }
    ngOnChanges(changes) {
        if (changes.dataSource || this.itemPerPage) {
            this.updatePaginations();
        }
        if (changes.columnHeaders && this.columnHeaders) {
            // Find and set the default sorted first and then assign it to _columnHeaders to render html.
            const defaultSortingColumn = this.columnHeaders.find(col => {
                return col['isDefaultSorting'] === true;
            });
            if (defaultSortingColumn) {
                this.orderBy.sortBy = defaultSortingColumn['field'];
            }
            // Disabled Mobile sorting for now, once designed finalized, it should be enabled
            const firstSortableColumn = this.columnHeaders.find(col => {
                return col['sortable'];
            });
            if (firstSortableColumn) {
                this.tableCustomClass = `${this.tableCustomClass} sortable-table`;
            }
        }
    }
    /**
     * Update paginations options on page load
     */
    updatePaginations() {
        if (!this.itemPerPage) {
            this.itemPerPage = this.dataSource.length;
        }
        this.itemCounter = this.itemPerPage;
        if (this.showPagination) {
            this.displayTogglePagination = false;
            if (this.dataSource.length > this.itemPerPage) {
                this.displayOnlyShowMore = true;
            }
            else {
                this.displayOnlyShowMore = false;
            }
        }
        if (this.showTogglePagination) {
            this.displayOnlyShowMore = false;
            if (this.gridOptions && this.dataSource.length > this.itemPerPage) {
                this.displayTogglePagination = true;
            }
            else {
                this.displayTogglePagination = false;
            }
        }
    }
    /**
     *  getSortableClasses
     * @param column
     */
    getSortableClasses(column) {
        if (column.sortable) {
            let sortClass = 'both';
            if (this.orderBy.sortBy === column.field) {
                sortClass = this.orderBy.sortDirection;
            }
            return `sortable ${sortClass}`;
        }
    }
    /**
     * sortList
     * @param column
     * @param toggleDirection
     */
    sortList(event, column, toggleDirection) {
        event.preventDefault();
        if (column.sortable) {
            // update active sort column key
            this.orderBy.sortBy = column.field;
            // column sorts toggle the sort direction, filter sorts don't
            if (toggleDirection) {
                if (this.orderBy.sortDirection === 'asc') {
                    this.orderBy.sortDirection = 'desc';
                }
                else {
                    this.orderBy.sortDirection = 'asc';
                }
            }
            // emit sort event in parent component to implement custom sorting logics.
            this.onSort.emit({ sortBy: column.field, sortDirection: this.orderBy.sortDirection });
        }
    }
    /**
     * sortListMobile
     * @param field
     */
    sortListMobile(field) {
        if (field) {
            const option = field.split('-');
            if (this.columnHeaders && option && option.length > 1) {
                const selectedCol = this.columnHeaders.find(col => {
                    return col['field'] === option[0];
                });
                if (option[1] === 'asc') {
                    this.orderBy.sortDirection = 'desc';
                }
                else {
                    this.orderBy.sortDirection = 'asc';
                }
                this.sortList(event, selectedCol, true);
            }
        }
    }
    /**
     * showMore method for pagination
     */
    showMore() {
        if (this.dataSource && this.itemCounter < this.dataSource.length) {
            this.itemCounter = this.itemCounter + this.itemPerPage;
            if (this.itemCounter < this.dataSource.length) {
                this.displayOnlyShowMore = true;
            }
            else {
                this.displayOnlyShowMore = false;
            }
        }
        else {
            this.itemCounter = this.dataSource.length;
            this.displayOnlyShowMore = false;
        }
    }
    /**
     * Expands or collapses the table.
     *
     * @since 4.0.33
     */
    accordionToggle() {
        this.gridOptions.expanded = !this.gridOptions.expanded;
        if (this.gridOptions.expanded) {
            this.itemCounter = this.dataSource.length;
        }
        else {
            this.itemCounter = this.itemPerPage;
        }
        this.onToggle.emit();
    }
    /**
     * performance optimization for *ngFor used throughout template
     * @param index
     * @param item
     */
    trackByFn(index, item) {
        // prefer unique-key over array index if one was provided and exists
        return (item[this.primaryKey]) ? item[this.primaryKey] : index;
    }
};
__decorate([
    Input(),
    __metadata("design:type", Array)
], GridComponent.prototype, "columnTemplates", void 0);
__decorate([
    Input(),
    __metadata("design:type", TemplateRef)
], GridComponent.prototype, "rowTemplate", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], GridComponent.prototype, "hasCustomField", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "showHeader", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "showFooter", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "showMinRecords", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "tableCustomClass", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "tableCaption", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "selectOptionsID", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "orderBy", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "showPagination", void 0);
__decorate([
    Input(),
    __metadata("design:type", Number)
], GridComponent.prototype, "itemPerPage", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "dataSource", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "columnHeaders", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "showTogglePagination", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "gridOptions", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], GridComponent.prototype, "useTrackBy", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], GridComponent.prototype, "primaryKey", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], GridComponent.prototype, "onSort", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], GridComponent.prototype, "onToggle", void 0);
GridComponent = __decorate([
    Component({
        selector: 'lib-grid',
        template: "<!-- Dropdown sorting options enables only in mobile screen -->\n<div class=\"form-group sorting-sm\" *ngIf=\"showSortOptionForMobile\">\n  <label for=\"{{selectOptionsID}}\">Sort By </label>\n  <div class=\"select-container\">\n    <select name=\"sorting-option\" class=\"form-control\" id={{selectOptionsID}}\n            (change)=\"sortListMobile(sortingOption.value)\" #sortingOption\n            data-show-icon=\"true\">\n      <ng-container *ngFor=\"let col of columnHeaders let i = index\">\n        <!-- TODO: UX Team will be providing alternate option for mobile sorting -->\n        <!-- Currently all fields sorted on ASC order -->\n        <option class=\"asc\" value=\"{{col.field}}-asc\" *ngIf=\"col.sortable\" selected=\"{{col.isDefaultSorting}}\"\n        id=\"ngKit-grid-option-select-{{i}}\"> {{col.title}} </option>\n      </ng-container>\n    </select>\n  </div>\n</div>\n<!-- Table start here -->\n<table class=\"table {{tableCustomClass}}\">\n  <caption *ngIf=\"tableCaption\" class=\"sr-only\">{{tableCaption}}</caption>\n  <thead *ngIf =\"showHeader\">\n  <tr>\n    <th *ngFor=\"let col of columnHeaders; let i = index\"\n      class=\"col-xs-{{col.colWidth}} {{col.customClass}} table-header-title\" scope=\"col\">\n      <a href=\"#\" (click)=\"sortList($event, col, true)\"\n        [ngClass]=\"getSortableClasses(col)\" id=\"ngKit-grid-table-header-{{i}}\"\n        attr.data-dl='{\"event\":\"mousedown\",\"da_track\":\"true\",\"event_id\":\"{{col.title}}\",\"event_type\":\"Sortable Option Click\"}'>\n        <span>{{col.title}}</span>\n      </a>\n      <!--custom header action --> \n      <ng-container  *ngTemplateOutlet=\"col.headerTemplate;context:{columnHeader:col}\">\n      </ng-container>\n      \n      <lib-tooltip placement=\"top\" *ngIf=\"col?.helpText\"\n        [enableSingleTooltip]=\"true\"\n        [tealiumContent]=\"{'eventValue': col.helpText, 'tealiumTracking': col.isTealiumAllowed}\">\n        <p class=\"tooltip-content-body-text\">{{col.helpText}}</p>\n      </lib-tooltip>\n    </th>\n  </tr>\n  </thead>\n  <tbody>\n  <ng-container *ngIf=\"useTrackBy; else noTrackBy\">\n    <ng-container *ngFor=\"let data of dataSource; let rowCounter = index; trackBy: trackByFn\">\n      <tr *ngIf=\"rowCounter < itemCounter\" [ngClass]=\"{ 'accordion-row': rowCounter >= itemPerPage }\">\n        <!-- Custom fields will render here -->\n        <ng-container *ngIf=\"hasCustomField\">\n          <td *ngFor=\"let col of columnHeaders; let i = index\" class=\"{{col.customClass}}\" id=\"ngKit-grid-column-{{i}}-{{rowCounter}}\">\n            <span *ngIf=\"col.title && !col.hideMobileHeader\" class=\"data-prefix-xs\"\n              [ngClass]=\"{'xs-prefix-vertical': col.xsPrefixVertical}\" id=\"ngKit-grid-column-span-{{i}}-{{rowCounter}}\"> {{col.title}}:</span>\n            <ng-container *ngTemplateOutlet=\"columnTemplates[i];context:data\"></ng-container>\n          </td>\n        </ng-container>\n        <!-- Non custom fields will render here -->\n        <ng-container *ngIf=\"!hasCustomField\">\n          <td *ngFor=\"let col of columnHeaders; let i = index\">\n            <span class=\"data-prefix-xs\" [ngClass]=\"{'xs-prefix-vertical': col.xsPrefixVertical}\" id=\"ngKit-grid-column-Head-{{i}}\"> {{col.title}}:</span>\n            {{data[col.field]}}\n          </td>\n        </ng-container>\n      </tr>\n      <!-- support for row template insertion for a particular row data -->\n      <ng-container *ngTemplateOutlet=\"rowTemplate;context:data\"></ng-container>\n    </ng-container>\n  </ng-container>\n  <ng-template #noTrackBy>\n    <ng-container *ngFor=\"let data of dataSource; let rowCounter = index\">\n      <tr *ngIf=\"rowCounter < itemCounter\" [ngClass]=\"{ 'accordion-row': rowCounter >= itemPerPage }\">\n        <!-- Custom fields will render here -->\n        <ng-container *ngIf=\"hasCustomField\">\n          <td *ngFor=\"let col of columnHeaders; let i = index\" class=\"{{col.customClass}}\" id=\"ngKit-grid-column-{{i}}-{{rowCounter}}\">\n            <span *ngIf=\"col.title && !col.hideMobileHeader\" class=\"data-prefix-xs\"\n              [ngClass]=\"{'xs-prefix-vertical': col.xsPrefixVertical}\" id=\"ngKit-grid-column-span-{{i}}-{{rowCounter}}\"> {{col.title}}:</span>\n            <ng-container *ngTemplateOutlet=\"columnTemplates[i];context:data\"></ng-container>\n          </td>\n        </ng-container>\n        <!-- Non custom fields will render here -->\n        <ng-container *ngIf=\"!hasCustomField\">\n          <td *ngFor=\"let col of columnHeaders; let i = index\">\n            <span class=\"data-prefix-xs\" [ngClass]=\"{'xs-prefix-vertical': col.xsPrefixVertical}\" id=\"ngKit-grid-column-Head-{{i}}\"> {{col.title}}:</span>\n            {{data[col.field]}}\n          </td>\n        </ng-container>\n      </tr>\n      <!-- support for row template insertion for a particular row data -->\n      <ng-container *ngTemplateOutlet=\"rowTemplate;context:data\"></ng-container>\n    </ng-container>\n  </ng-template>\n  </tbody>\n  <tfoot *ngIf=\"showFooter\">\n    <tr>\n      <td *ngFor=\"let col of columnHeaders; let i = index\" class=\"{{col.customClass}}\">\n        <span *ngIf=\"col.title && !col.hideMobileHeader\" class=\"data-prefix-xs\" id=\"ngKit-grid-column-header-date-{{i}}\"> {{col.title}}:</span>\n        <ng-container *ngTemplateOutlet=\"columnTemplates[i];context:dataSource['footerData']\">\n        </ng-container>\n      </td>\n    </tr>\n  </tfoot>\n</table>\n<!-- New Accordion Expand/Collapse Capability -->\n<a *ngIf=\"displayTogglePagination\" class=\"accordion-toggle\" (click)=\"accordionToggle()\">\n  <div class=\"content-align\" [ngStyle]=\"{ 'text-align': gridOptions.toggleTextAlign || 'center' }\">\n    <span  class=\"content-accordion-table-span\">\n      <ng-container *ngIf=\"gridOptions.expanded; else showMoreTempRef\">\n        {{ gridOptions.collapseText || 'Show Less' }}\n        <em *ngIf=\"gridOptions.showCaretIcons !== false\" class=\"icon icon-caret-up\"></em>\n      </ng-container>\n      <ng-template #showMoreTempRef>\n        {{ gridOptions.expandText || 'Show More' }}\n        <em *ngIf=\"gridOptions.showCaretIcons !== false\" class=\"icon icon-caret-down\"></em>\n      </ng-template>\n    </span>\n  </div>\n</a>\n<a *ngIf=\"displayOnlyShowMore\" class=\"accordion-toggle\">\n  <h5 class=\"content-align\">\n    <span class=\"content-table-span\" (click)=\"showMore()\" id=\"ngKit-grid-show-More-Pagination\"></span>\n  </h5>\n</a>\n",
        styles: [".sortable-table thead th .sortable{cursor:pointer;background-position:right;background-repeat:no-repeat;padding-right:1em;position:relative}.sortable-table thead th .sortable span{padding-left:1em}.sortable-table thead th .both span:after{content:\"\\e051\";font-family:higux;margin-left:.2em;position:absolute;font-size:1.4em}.sortable-table thead th .asc span:after{content:\"\\e068\";font-family:higux;margin-left:.2em;position:absolute;font-size:1.7em}.sortable-table thead th .desc span:after{content:\"\\e064\";font-family:higux;margin-left:.2em;position:absolute;font-size:1.7em}.fixed-table-loading{display:none}.sortable-table-container{position:relative;display:inline-block;width:auto;z-index:1}.sortable-table-container:after{content:\"\\e044\";font-family:higux;text-align:center;line-height:29px;position:absolute;width:25px;height:29px;background:#f7f7f7;color:#3a5a78;right:-1px;top:-12%;pointer-events:none}.table-category-sm{display:block;height:100%;border:0;background:0 0;width:25px}.table.sortable-table thead:first-child>tr:first-child>th{border-top:1px solid #dadada}.table.sortable-table thead tr{display:block}.table.sortable-table thead tr th{bottom:30px;display:none;left:0;position:relative;width:163px;border:1px solid #dadada;padding-top:3px;padding-bottom:3px}.table.sortable-table thead tr th:first-child{display:block}.table.sortable-table thead tr th.displayNone{display:none}.table.sortable-table thead tr th.displayBlock{display:block}@media (min-width:768px){.sortable-table thead th .sortable span{padding-left:0}.sortable-table-container,.table-category-sm{display:none}.table.sortable-table span{padding-left:0}.table.sortable-table thead:first-child>tr:first-child>th{border-top:0}.table.sortable-table thead tr{display:table-row}.table.sortable-table thead tr th{display:table-cell;position:static;border:0;border-bottom:3px solid #3a5a78}.table.sortable-table thead tr th.displayBlock,.table.sortable-table thead tr th.displayNone,.table.sortable-table thead tr th:first-child{display:table-cell}.table.sortable-table>tbody>tr:hover>td{background-color:#f9f9f9}.table.sortable-table .column-selected{background-color:#e3f3ff}}.sorting-sm{display:none}.table-header-title a{color:#3a5a78;text-decoration:none}@media (max-width:768px){.table.sortable-table thead tr{display:none}.sorting-sm{display:block;margin-bottom:0}.sorting-sm label{text-align:left}}.table{margin-bottom:10px}.table th{line-height:em(22);cursor:auto}.table th lib-tooltip{padding-left:.5em}.table th.align-right{text-align:right}.table td{font-family:\"HCo Gotham SSm\",arial,sans-serif;cursor:auto}.table td.align-right{text-align:right}.table tfoot{border-bottom:1px solid #ededed}.table tfoot td{font-weight:700;padding-top:1em;padding-bottom:1em}@media (max-width:768px){.table tbody{border-bottom:none}.table tbody td{font-weight:700}.table tbody tr{border-bottom:1px solid #ededed;margin-bottom:1em}.table tbody tr>td:last-child{border-bottom:none}}a.accordion-toggle:hover{cursor:pointer}a.accordion-toggle div.content-align{width:100%}a.accordion-toggle div.content-align .content-accordion-table-span{color:#1570be}.accordion-toggle h5.content-align{text-align:center;padding-bottom:0}.accordion-toggle h5.content-align .content-table-span::before{font-family:higux,arial,sans-serif!important;content:\"\\e044 \";padding-right:10px;color:#1570be}.accordion-toggle h5.content-align .content-table-span::after{content:\" Show More \";color:#1570be;font-family:\"HCo Gotham\",arial,sans-serif;vertical-align:top}"]
    })
], GridComponent);

let HigTooltipComponent = class HigTooltipComponent {
    constructor(element, tealiumdatasvc) {
        this.element = element;
        this.tealiumdatasvc = tealiumdatasvc;
        this.offSetMinLimit = 25;
        this.offsetDifference = -10;
        this.maxWidthDifference = -50;
        this.useBodyWidth = false;
        this.useMobileConfig = false;
        this.iconClass = 'icon-info-alt';
        this.shownTooltip = new EventEmitter();
        this.tealiumContent = {
            'eventValue': 'field.helpText',
            'tealiumTracking': 'isTealiumAllowed'
        };
        this.linkText = '';
        this.closeOnWindowClick = true;
        this.showOnHover = true;
        this.onHover = this.showOnHover ? 'mouseenter:mouseleave' : '';
    }
    ngOnInit() {
    }
    ngOnChanges() {
    }
    /**
     * method invokes on tooltip shown
     */
    tooltipShown(pop) {
        this.pop = pop;
        this.shownTooltip.emit({});
        if (this.tealiumContent.tealiumTracking) {
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Tooltip Click',
                'event_id': this.tealiumContent.eventValue.replace(/<[^>]*>/g, ''),
                'event_value': window.location.href,
                'da_track': true
            });
        }
    }
};
HigTooltipComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: TealiumDataService }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "offsetDifference", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "maxWidthDifference", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "useBodyWidth", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "useMobileConfig", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "iconClass", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], HigTooltipComponent.prototype, "placement", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], HigTooltipComponent.prototype, "shownTooltip", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], HigTooltipComponent.prototype, "enableSingleTooltip", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "tealiumContent", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "linkText", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "closeOnWindowClick", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], HigTooltipComponent.prototype, "showOnHover", void 0);
HigTooltipComponent = __decorate([
    Component({
        selector: 'lib-tooltip',
        template: "<ng-template #popTemplate>\n  <div class=\"tooltip-content\">\n    <div class=\"tooltip-content-heading\">\n      <ng-content select=\".tooltip-content-heading-text\"></ng-content>\n      <h3 class=\"tooltip-content-heading-close\" *ngIf=\"!linkText\">\n        <i (click)=\"pop.hide()\" class=\"popover-close icon icon-close\" id=\"ngKit-tooltip-hide\"></i>\n      </h3>\n    </div>\n    <div class=\"tooltip-content-body\">\n      <ng-content select=\".tooltip-content-body-text\"></ng-content>\n    </div>\n  </div>\n</ng-template>\n\n<i [placement]=\"placement\" [popover]=\"popTemplate\" #pop=\"bs-popover\" continer=\"body\"\n  containerClass=\"tooltip-custom-class {{customMobileClass}}\" class=\"icon help-text-icon\"\n  [ngClass]=\"iconClass\" *ngIf=\"!linkText\" [outsideClick]=\"closeOnWindowClick\" (onShown)=\"tooltipShown(pop)\">\n</i>\n\n<ng-container *ngIf=\"linkText\">\n  <ng-template [ngIf]=\"showOnHover\" [ngIfElse]=\"persistentLink\">\n    <a class=\"tooltip-link\" data-toggle=\"tooltip\" target=\"_blank\" [placement]=\"placement\" [popover]=\"popTemplate\" #pop=\"bs-popover\"\n        triggers=\"mouseenter:mouseleave\" containerClass=\"tooltip-custom-class {{customMobileClass}}\"\n        (onShown)=\"tooltipShown(pop)\">\n      {{linkText}}\n    </a>\n  </ng-template>\n\n  <ng-template #persistentLink>\n    <a class=\"tooltip-link\" data-toggle=\"tooltip\" target=\"_blank\" [placement]=\"placement\" [popover]=\"popTemplate\" #pop=\"bs-popover\"\n      containerClass=\"tooltip-custom-class {{customMobileClass}}\" \n      (onShown)=\"tooltipShown(pop)\">\n      {{linkText}}\n    </a>\n  </ng-template>\n</ng-container>\n",
        encapsulation: ViewEncapsulation.None,
        styles: ["a[data-toggle=tooltip]{text-decoration:none;border-bottom:2px dotted;color:#1570be;line-height:1em;display:inline-block}.tooltip div,.tooltip h2{text-align:left}.tooltip .tooltip-inner{background-color:#fff;border-top:6px solid #b6d3e9;box-shadow:0 0 10px rgba(0,0,0,.75);color:#000;padding:1em;min-width:300px}.tooltip.in{opacity:1}.tooltip.top{margin-top:-.6em}.tooltip.top .tooltip-arrow{border-right-color:transparent}.tooltip.top .tooltip-arrow:after{content:\"\";position:absolute;width:0;height:0;bottom:-1.5em;left:-1em;top:-.5em;box-sizing:border-box;border:1em solid #000;border-color:transparent transparent #fff #fff;transform-origin:0 0;transform:rotate(-45deg);box-shadow:-3px 3px 3px 0 rgba(0,0,0,.4)}.tooltip.right{margin-left:.6em}.tooltip.right .tooltip-arrow{border-right-color:transparent}.tooltip.right .tooltip-arrow:after{content:\"\";position:absolute;width:0;height:0;bottom:-.7em;left:.5em;top:-1em;box-sizing:border-box;border:1em solid #000;border-color:transparent transparent #fff #fff;transform-origin:0 0;transform:rotate(45deg);box-shadow:-3px 3px 3px 0 rgba(0,0,0,.4)}.tooltip.bottom{margin-top:.6em}.tooltip.bottom .tooltip-arrow{border-right-color:transparent}.tooltip.bottom .tooltip-arrow:after{content:\"\";position:absolute;width:0;height:0;bottom:-.7em;left:1em;top:1em;box-sizing:border-box;border:1em solid #000;border-color:transparent transparent #fff #fff;transform-origin:0 0;transform:rotate(135deg);box-shadow:-3px 3px 3px 0 rgba(0,0,0,.4)}.tooltip.left{margin-left:-.6em}.tooltip.left .tooltip-arrow{border-right-color:transparent}.tooltip.left .tooltip-arrow:after{content:\"\";position:absolute;width:0;height:0;bottom:-.7em;left:-.5em;top:1em;box-sizing:border-box;border:1em solid #000;border-color:transparent transparent #fff #fff;transform-origin:0 0;transform:rotate(225deg);box-shadow:-3px 3px 3px 0 rgba(0,0,0,.4)}[data-toggle=tooltip]{display:block;margin-bottom:.5em}@media (min-width:768px){[data-toggle=tooltip]{display:inline-block;margin-bottom:0}}.tooltip-soft{position:relative;display:inline}.tooltip-soft-text{font-weight:500;color:#3a5a78}.tooltip-soft-icon{display:inline;color:#5396bf;font-size:1.2em;vertical-align:middle}.tooltip-soft-amount{font-weight:400;color:#484848;display:block}.tooltip-custom-class{pointer-events:auto!important}.tooltip-custom-class .tooltip-content-heading{display:flex;justify-content:space-between}.tooltip-custom-class .tooltip-content-heading-text{width:90%;font-size:1.25em;color:#3a5a78;font-weight:500;margin-bottom:1.25em}.tooltip-custom-class .tooltip-content-heading-close{margin-left:auto;padding-bottom:5px;display:flex;align-items:flex-start;cursor:pointer}.tooltip-custom-class .tooltip-content-body-text{font-size:.875em}.bs-popover-bottom{top:-10px!important}.bs-popover-bottom .arrow{margin-left:0!important}.help-text-icon{color:#3a5a78;cursor:pointer;margin-left:5px;position:relative;top:2px}"]
    }),
    __metadata("design:paramtypes", [ElementRef, TealiumDataService])
], HigTooltipComponent);

var HigTooltipModule_1;
let HigTooltipModule = HigTooltipModule_1 = class HigTooltipModule {
    /**
     * added forRoot for backward support,
     * @param config
     */
    static forRoot(config) {
        return {
            ngModule: HigTooltipModule_1,
            providers: []
        };
    }
};
HigTooltipModule = HigTooltipModule_1 = __decorate([
    NgModule({
        imports: [
            CommonModule,
            PopoverModule.forRoot(),
            FormsModule,
            ReactiveFormsModule
        ],
        declarations: [HigTooltipComponent],
        exports: [HigTooltipComponent]
    })
], HigTooltipModule);

let GridModule = class GridModule {
};
GridModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            HigTooltipModule
        ],
        declarations: [GridComponent],
        exports: [GridComponent]
    })
], GridModule);

class PaginatorModel {
}

var ScrollingHelper_1;
let ScrollingHelper = ScrollingHelper_1 = class ScrollingHelper {
    constructor() {
        this.scrollToPositiveSource = new Subject();
        this.scrollToNegativeSource = new Subject();
        this.scrollToPositiveSource.pipe(switchMap(targetYPos => {
            return interval(1).pipe(scan((acc, curr) => {
                if (acc + ScrollingHelper_1.SCROLL_SPEED > targetYPos) {
                    return targetYPos;
                }
                return acc + ScrollingHelper_1.SCROLL_SPEED;
            }, window.pageYOffset), tap(position => window.scrollTo(0, position)), takeWhile(val => val < targetYPos));
        })).subscribe();
        this.scrollToNegativeSource.pipe(switchMap(targetYPos => {
            return interval(1).pipe(scan((acc, curr) => {
                const scrollSpeed = (targetYPos <= 0) ? ScrollingHelper_1.SCROLL_SPEED * 3.5 :
                    ScrollingHelper_1.SCROLL_SPEED;
                if (acc - scrollSpeed < targetYPos) {
                    return targetYPos;
                }
                return acc - scrollSpeed;
            }, window.pageYOffset), tap(position => window.scrollTo(0, position)), takeWhile(val => val > targetYPos));
        })).subscribe();
    }
    scrollToId(id) {
        setTimeout(() => {
            const element = document.getElementById(id);
            const scrollOffset = (window.innerWidth >= ScrollingHelper_1.DESKTOP_WIDTH) ?
                ScrollingHelper_1.DESKTOP_SCROLL_OFFSET : ScrollingHelper_1.MOBILE_SCROLL_OFFSET;
            const topOffset = element.offsetTop - scrollOffset;
            const ctrl = topOffset - (document.documentElement.scrollTop || document.body.scrollTop);
            if (ctrl > 0) {
                this.scrollToPositiveSource.next(topOffset);
            }
            else {
                this.scrollToNegativeSource.next(topOffset);
            }
        }, 0);
    }
};
ScrollingHelper.SCROLL_SPEED = 40;
ScrollingHelper.DESKTOP_SCROLL_OFFSET = 60;
ScrollingHelper.MOBILE_SCROLL_OFFSET = 0;
ScrollingHelper.DESKTOP_WIDTH = 1024;
ScrollingHelper.ɵprov = ɵɵdefineInjectable({ factory: function ScrollingHelper_Factory() { return new ScrollingHelper(); }, token: ScrollingHelper, providedIn: "root" });
ScrollingHelper = ScrollingHelper_1 = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [])
], ScrollingHelper);

let PaginatorComponent = class PaginatorComponent {
    constructor(scrollingHelper) {
        this.scrollingHelper = scrollingHelper;
        this.atStartPointer = false;
        this.atEndPointer = true;
        this.pages = [];
        this.mobileSkipNumber = 0;
        this.paginatorResult = new PaginatorModel();
        this.currentPageNumber = 1;
        this.pageSizeOptions = [12, 25, 50, 100, 500];
        this.showDisabled = true;
        this.pageChangeEvent = new EventEmitter();
    }
    ngOnInit() {
        if (!this.itemPerPage && this.pageSizeOptions.length) {
            this.itemPerPage = this.pageSizeOptions[0];
        }
        this.totalNumberOfPages = Math.ceil(this.totalRecords / this.itemPerPage);
        this.pageRestructuring();
    }
    onItemPerPageChange() {
        this.itemPerPage = Number(this.itemPerPage); // ensure this is a number
        this.totalNumberOfPages = Math.ceil(this.totalRecords / this.itemPerPage);
        this.currentPageNumber = 1;
        this.pageRestructuring();
        this.pageChangeEvent.emit(this.paginatorResult);
    }
    onNextPage() {
        if (this.currentPageNumber < this.totalNumberOfPages) {
            this.currentPageNumber = this.currentPageNumber + 1;
            this.pageRestructuring();
            this.pageChangeEvent.emit(this.paginatorResult);
        }
    }
    onPageSelect(pageNumber) {
        if (pageNumber !== this.currentPageNumber) {
            this.currentPageNumber = pageNumber;
            this.pageRestructuring();
            this.pageChangeEvent.emit(this.paginatorResult);
        }
    }
    onPrevPage() {
        if (this.currentPageNumber > 1) {
            this.currentPageNumber = this.currentPageNumber - 1;
            this.pageRestructuring();
            this.pageChangeEvent.emit(this.paginatorResult);
        }
    }
    pageRestructuring() {
        this.mobileSkipNumber = 0;
        // showing the in-depth view only if more than 5 pges otherwise dislaying pages directly.
        if (this.totalNumberOfPages > 5) {
            // this just make sure last 3 pages remaining
            this.atEndPointer = (this.totalNumberOfPages - 2) > this.currentPageNumber;
            // this just make sure current page withing frst 3 pages limit
            this.atStartPointer = this.currentPageNumber > 3 || !this.atEndPointer;
            if (!this.atStartPointer && this.currentPageNumber === 3) {
                // When on page 3, user will get direct ability to click on page # <1, 2, 3, 4 …  >
                // when select Page 4, options display on pagination will be < 1 .. 3 4 5 ..
                this.pages = [1, 2, 3, 4];
                this.mobileSkipNumber = 4;
            }
            else if (!this.atStartPointer) {
                // [1,2,3] t show initial page buttons
                this.pages = [1, 2, 3];
            }
            if (!this.atEndPointer && (this.currentPageNumber === this.totalNumberOfPages - 2)) {
                this.pages = [this.totalNumberOfPages - 3, this.totalNumberOfPages - 2,
                    this.totalNumberOfPages - 1, this.totalNumberOfPages];
                this.mobileSkipNumber = this.totalNumberOfPages - 3;
            }
            else if (!this.atEndPointer) {
                this.pages = [this.totalNumberOfPages - 2, this.totalNumberOfPages - 1, this.totalNumberOfPages];
            }
            if (this.atStartPointer && this.atEndPointer) {
                this.pages = [this.currentPageNumber - 1, this.currentPageNumber, this.currentPageNumber + 1];
            }
        }
        else {
            this.pages = [];
            for (let i = 1; i <= this.totalNumberOfPages; i++) {
                this.pages.push(i);
            }
            this.atEndPointer = false;
            this.atStartPointer = false;
        }
        const pageEndCount = this.currentPageNumber * this.itemPerPage;
        this.itemStartNumber = ((this.currentPageNumber - 1) * this.itemPerPage) + 1;
        this.itemEndNumber = this.totalRecords < pageEndCount ? this.totalRecords : pageEndCount;
        this.paginatorResult.pageNumber = this.currentPageNumber;
        this.paginatorResult.itemsPerPage = this.itemPerPage;
        this.paginatorResult.startIndex = this.itemStartNumber;
        this.paginatorResult.endIndex = this.itemEndNumber;
        if (this.scrollId) {
            this.scrollingHelper.scrollToId(this.scrollId);
        }
    }
};
PaginatorComponent.ctorParameters = () => [
    { type: ScrollingHelper }
];
__decorate([
    Input(),
    __metadata("design:type", String)
], PaginatorComponent.prototype, "scrollId", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], PaginatorComponent.prototype, "currentPageNumber", void 0);
__decorate([
    Input(),
    __metadata("design:type", Number)
], PaginatorComponent.prototype, "itemPerPage", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], PaginatorComponent.prototype, "totalRecords", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], PaginatorComponent.prototype, "pageSizeOptions", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], PaginatorComponent.prototype, "showDisabled", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], PaginatorComponent.prototype, "pageChangeEvent", void 0);
PaginatorComponent = __decorate([
    Component({
        selector: 'lib-paginator',
        template: "<div class=\"pagination-container\" [ngClass]=\"{'hide-disabled': !showDisabled}\">\n  <div class=\"pagination-left\">\n    Showing {{itemStartNumber}}-{{itemEndNumber}} of {{totalRecords}}\n  </div>\n  <div class=\"pagination-middle\">\n    <ul class=\"pagination\">\n      <li class=\"prev-btn\" [ngClass]=\"{'disabled': currentPageNumber <= 1}\" (click)=\"onPrevPage()\">\n        <a aria-label=\"Previous Page\" id=\"ngKit-paginator-previous-Page-Link\"></a></li>\n      <li *ngIf=\"atStartPointer\" (click)=\"onPageSelect(1)\"><a id=\"ngKit-paginator-onPage-Select\">1</a></li>\n      <li class=\"disabled\" *ngIf=\"atStartPointer\"><a aria-hidden=\"true\">...</a></li>\n\n      <li *ngFor=\"let pageNumber of pages; let i = index\"\n        [ngClass]=\"{'active': currentPageNumber === pageNumber, 'pagination-hidden-xs hidden-sm': (currentPageNumber !== pageNumber && atStartPointer && atEndPointer) || (pageNumber === mobileSkipNumber) }\"\n        (click)=\"onPageSelect(pageNumber)\"><a id=\"ngKit-paginator-page-number-Link-{{i}}\">{{pageNumber}}</a></li>\n      <li class=\"disabled\" *ngIf=\"atEndPointer\"><a href=\"#\" aria-hidden=\"true\">...</a></li>\n      <li><a *ngIf=\"atEndPointer\" (click)=\"onPageSelect(totalNumberOfPages)\" id=\"ngKit-paginator-select-PageNumber-{{totalNumberOfPages}}\">{{totalNumberOfPages}}</a></li>\n      <li class=\"next-btn\" [ngClass]=\"{'disabled': currentPageNumber === totalNumberOfPages}\" (click)=\"onNextPage()\"\n      ><a aria-label=\"Next Page\" id=\"ngKit-paginator-next-PageLink\"></a></li>\n    </ul>\n  </div>\n  <div class=\"pagination-right\">\n    <span>Items per page</span>\n    <div class=\"select-container\">\n      <select name=\"select-page-size\" class=\"form-control\" [(ngModel)]=\"itemPerPage\" (change)=\"onItemPerPageChange()\"\n        id=\"ngKit-paginator-drop-down-select\"\n        data-dl='{\"da_track\": \"true\", \"event\": \"change\", \"event_id\":\"Pagination Items per page dropdown\"}'>\n        <option *ngFor=\"let pageSize of pageSizeOptions\" value=\"{{pageSize}}\" id=\"ngKit-paginator-page-Size-{{pageSize}}\">{{pageSize}}</option>\n      </select>\n      <span class=\"form-control-feedback\" aria-hidden=\"true\">\n        <i class=\"fa fa-angle-down\"></i>\n      </span>\n    </div>\n  </div>\n</div>\n",
        styles: [".pagination-container{padding:0 .5em;margin-bottom:1em}.pagination-container .select-container{width:6em;position:relative}.pagination-container a:hover,.pagination-container li:hover{cursor:pointer}.pagination-container.hide-disabled .next-btn.disabled,.pagination-container.hide-disabled .prev-btn.disabled{display:none}.pagination-container .pagination{margin-bottom:.5em;margin-top:1em}.pagination-container .pagination li:first-child.disabled a,.pagination-container .pagination li:last-child.disabled a{border:1px solid #dadada}.pagination-container .pagination li:first-child.disabled a:before,.pagination-container .pagination li:last-child.disabled a:before{color:#dadada}.pagination-container .select-container .form-control-feedback{display:none;background-color:#3a5a78;height:36px}.pagination-container .select-container .fa-angle-down{color:#fff}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.pagination-container .form-control-feedback{top:0;position:absolute}}@media screen and (max-width:767px){.pagination-container{padding:.5em}.disabled>a{padding:6px}li:first-child.disabled a,li:last-child.disabled a{padding:6px 12px}}"]
    }),
    __metadata("design:paramtypes", [ScrollingHelper])
], PaginatorComponent);

var AdvancedGridComponent_1;
/** @dynamic */
let AdvancedGridComponent = AdvancedGridComponent_1 = class AdvancedGridComponent {
    constructor(renderer, cdr, document) {
        this.renderer = renderer;
        this.cdr = cdr;
        this.document = document;
        this.primaryKey = 'id'; // unique-key used for trackBy performance optimization for *ngFor loops
        this.pagingInfo = {
            totalRecords: null,
            currentPageNumber: 1,
            pageSize: 10,
            rowCountOptions: [10, 20, 30, 40, 50]
        };
        this.actionsInfo = {};
        this.getDisplayTextForHeaderField = this.defaultDisplayText;
        this.getDisplayTextForRecordField = this.defaultDisplayText;
        this.pageOrSortChanged = new EventEmitter();
        this.fixedTableHeaders = [];
        // original position of our sticky header
        this.paginatorTopOffset = 0;
        // Reference to the actual selectAllCheckbox on the page
        this.selectAllCheckbox = {};
        // throttle scroll and resize events
        this.resizeSubject = new Subject();
        this.resizeObservable = this.resizeSubject.asObservable().pipe(debounceTime(200));
        this.unsubscribe = new Subject();
        this.selectAllActionEventHandler = (event) => {
            // Check/uncheck the "select-all" checkbox
            this.selectAllCheckbox.checked = event.srcElement.checked;
            if (this.datasource) {
                // Check/uncheck every record in current source when the "select-all" checkbox was selected
                this.datasource.forEach(record => {
                    record[this.actionsInfo.columnActionSelectField] = this.selectAllCheckbox.checked;
                });
            }
            // Perform user-given `actionsInfo.columnActionOccurred`, too.
            this.actionRecord('selectAll', undefined, this.selectAllCheckbox.checked);
        };
        this.sortEventHandler = (event) => {
            const target = event.currentTarget || event.target || event.srcElement;
            this.sortBy(target.id);
        };
        // get a reference to the native window object
        this.nativeWindow = window;
    }
    // PaginatorComponent is dynamically based on *ngIf so we need to set a reference when the DOM element exists
    set setPaginatorComponent(comp) {
        if (!!comp) {
            this.paginatorComponent = comp;
        }
    }
    ngOnInit() {
        // set the viewport before performing any positioning calculations and setting scroll event listeners
        this.viewport = this.getViewport();
        // listen on ViewPort.scroll
        this.onViewPortScroll(this.viewport.scrollContainer);
        // rebuild data table at end of browser resize event
        this.resizeObservable
            .pipe(takeUntil(this.unsubscribe)) // prevent memory leak, remove the subscriber when the subject is completed on ngOnDestroy
            .subscribe(() => this.updateFixedContent());
    }
    // performance optimization for *ngFor used throughout template
    trackByFn(index, item) {
        // prefer unique-key over array index if one was provided and exists
        return (item[this.primaryKey]) ? item[this.primaryKey] : index;
    }
    // sets the viewport to base scroll position events from
    // if a HTMLElement id was specified we will use that as the viewport, otherwise default to the document.body
    getViewport() {
        let el = null;
        // if a viewPortContainer was specified, try to find it in the DOM
        if (this.viewPortContainer) {
            el = this.document.getElementById(this.viewPortContainer);
        }
        if (el !== null) {
            return {
                type: 'HTMLElement',
                scrollContainer: el,
                target: el
            };
        }
        else {
            // either the viewPortContainer element was not found or not specified, so default to the document.body and Window
            return {
                type: 'Window',
                scrollContainer: this.nativeWindow,
                target: this.document.body
            };
        }
    }
    onResize(width) {
        this.resizeSubject.next(width);
    }
    // returns the vertical position of the viewport
    getYPosition() {
        var _a;
        if (((_a = this.viewport) === null || _a === void 0 ? void 0 : _a.type) === 'HTMLElement') {
            return this.viewport.scrollContainer.scrollTop;
        }
        else {
            return this.nativeWindow.pageYOffset;
        }
    }
    /**
     *  makes the table header and pagination container "sticky"
     */
    onViewPortScroll(viewport) {
        // set a listener on the viewport for scroll events in order to update the top position of the sticky header
        fromEvent(viewport, 'scroll')
            .pipe(takeUntil(this.unsubscribe))
            .subscribe((event) => {
            // Since scroll events can fire at a high rate, the event handler shouldn't execute
            // computationally expensive operations such as DOM modifications. Instead we throttle the event using requestAnimationFrame
            this.nativeWindow.requestAnimationFrame(() => {
                // repaint the table clone
                this.fitHeaderToWindowTop(this.getYPosition());
            });
        });
    }
    fitHeaderToWindowTop(pageYOffset) {
        var _a, _b, _c, _d;
        let offset = 0;
        // if the user scrolls the browser past the top of our sticky container, dynamically position it to the top of the viewport
        if (pageYOffset > this.paginatorTopOffset) {
            // get the position of the browser scrollbar
            const pos = pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
            // how much to move the sticky items based on sticky container position relative to the body viewport
            offset = pos - this.paginatorTopOffset;
        }
        // get height of top pagination container so we can position sticky header directly under it
        const elemRect = (_a = this.paginatorTop) === null || _a === void 0 ? void 0 : _a.nativeElement.getBoundingClientRect();
        this.renderer.setStyle((_b = this.paginatorTop) === null || _b === void 0 ? void 0 : _b.nativeElement, 'top', offset + 'px');
        this.renderer.setStyle((_c = this.tableHeaderFixed) === null || _c === void 0 ? void 0 : _c.nativeElement, 'top', offset + elemRect.height + 'px');
        this.renderer.setStyle((_d = this.tableClone) === null || _d === void 0 ? void 0 : _d.nativeElement, 'top', elemRect.height + 'px');
    }
    /**
     * syncs the top and bottom scrollbar for table horizontal scrolling and moves the sticky header horizontally
     * @param from
     * @param to
     */
    onDivScroll(from, to) {
        var _a, _b, _c;
        // make the clone/fixed table "sticky"
        const table = (_a = this.tableHeaderFixed) === null || _a === void 0 ? void 0 : _a.nativeElement.firstChild;
        this.renderer.setStyle(table, 'left', -((_b = this[from]) === null || _b === void 0 ? void 0 : _b.nativeElement.scrollLeft) + 'px');
        // set the other div's scroll position equal to ours
        this[to].nativeElement.scrollLeft = (_c = this[from]) === null || _c === void 0 ? void 0 : _c.nativeElement.scrollLeft;
    }
    ngOnChanges(changes) {
        // update the table DOM before the next repaint
        this.nativeWindow.requestAnimationFrame(() => {
            this.updateFixedContent(changes);
        });
    }
    defaultDisplayText(text) {
        return text;
    }
    isFixedColumn(index) {
        const actionOptionsLength = this.actionsInfo.columnActionOptions ? this.actionsInfo.columnActionOptions.length : 0;
        return index <= this.numberOfFixedColumns - 1 - actionOptionsLength;
    }
    actionRecord(action, record, selected) {
        this.actionsInfo.columnActionOccurred({ record, action, selected });
        // Take care of "select-all" toggle within the ng-kit.
        if (action !== 'selectAll' && this.selectAllCheckbox) {
            this.selectAllCheckbox.checked = this.areAllRecordsSelected();
        }
        // Find [any] changes that were caused by this action
        this.cdr.detectChanges();
    }
    /**
     * Determines if all records are currently selected.
     *
     * @remarks
     * Will return `false` if `datasource` is "falsy".
     * @returns `true` if all records are selected; `false` otherwise.
     */
    areAllRecordsSelected() {
        var _a;
        return !!((_a = this.datasource) === null || _a === void 0 ? void 0 : _a.every(record => !!record[this.actionsInfo.columnActionSelectField]));
    }
    loadAdvGridCellActionInfo(actionHeader, isHeaderCell, record) {
        const cellActionInfo = {
            header: actionHeader,
            record: record,
            actionSelectIndicator: this.actionsInfo.columnActionSelectField || 'selectedField',
            actionIdField: this.actionsInfo.columnActionIdField,
            actionRecord: this.actionRecord.bind(this),
            selectAllChecked: this.areAllRecordsSelected()
        };
        if (isHeaderCell) {
            cellActionInfo.showActionHeader = this.actionsInfo.showActionColumnHeader;
            cellActionInfo.actionHeaderDisabled = (this.actionsInfo.showActionColumnHeader && !this.actionsInfo.enablePaginationBarSubmit) || !!this.actionsInfo.disableSelectAll;
        }
        return cellActionInfo;
    }
    /**
     * Computer the fixed headers to render the clone table
     */
    updateFixedHeaders() {
        this.fixedTableHeaders = [];
        for (let index = 0; index < this.tableHeaders.length; index += 1) {
            if (this.isFixedColumn(index)) {
                this.fixedTableHeaders.push(this.tableHeaders[index]);
            }
        }
    }
    /**
     * Computer the string value for a TD ngclass object
     *
     * @column (number) - id of the column
     * @row (number) - id of the row, -1 if header in thead
     * @header (String) - value of header text
     */
    computeClassesForTd(column, row, header) {
        let classStr = `column-${column} row-${row} header-${header.fieldName}`;
        // align currency fields right
        if (header.columnDataType === 'currency') {
            classStr += ` text-right`;
        }
        if (this.isFixedColumn(column)) {
            classStr += ` fixed-column`;
        }
        if (header.customClass) {
            classStr += ` ${header.customClass}`;
        }
        return classStr;
    }
    /**
     * Sorting handler. Sets the sorting params for even emitter which in turn triggers the functionality that fetches sorted data
     * @param headerFieldId
     */
    sortBy(headerFieldId) {
        if (this.isSortableHeader(headerFieldId)) {
            if (this.sortHeader === headerFieldId) {
                if (this.sortDir === 'asc') {
                    this.sortDir = 'desc';
                }
                else {
                    this.sortDir = 'asc';
                }
            }
            else {
                this.sortHeader = headerFieldId;
                this.sortDir = 'asc';
            }
            if (this.pageOrSortChanged) {
                this.pageOrSortChanged.emit({
                    pagingInfo: this.pagingInfo,
                    sortHeader: this.sortHeader,
                    sortDir: this.sortDir
                });
            }
        }
    }
    /**
     * Checked if the given column header is sortable
     * @param fieldId
     */
    isSortableHeader(fieldId) {
        return this.tableHeaders.some(header => header.fieldName === fieldId)
            && this.tableHeaders.find(header => header.fieldName === fieldId).sortable;
    }
    /**
     * Returns the scss classes required to show sort icons based on the asc/desc behavior
     * @param header
     */
    getSortableClasses(header) {
        let sortClass;
        // display sort icon if sortable column
        if (header.sortable) {
            sortClass = 'both';
            // overwrite as 'asc' or 'desc' icon if currently sorted header
            if (this.sortHeader === header.fieldName) {
                sortClass = this.sortDir;
            }
            sortClass = `sortable ${sortClass}`;
        }
        // right align currency headers
        if (header.columnDataType === 'currency') {
            sortClass += ` text-right`;
        }
        return sortClass;
    }
    /**
     * Clones the existing array and chooses a sub section of the record to display
     */
    updateFixedContent(changes) {
        if (this.datasource) {
            // Used for fixed column computation
            this.updateFixedHeaders();
            this.computedFixedColumns(changes);
            setTimeout(() => {
                this.setStickyOffsetPosition();
                this.fitHeaderToWindowTop(this.getYPosition());
            }, AdvancedGridComponent_1.RENDER_DELAY);
            this.cdr.detectChanges();
        }
    }
    /**
     * Handle pagination changes
     */
    onPaginationChange(page) {
        this.pagingInfo.currentPageNumber = page.pageNumber;
        this.pagingInfo.pageSize = page.itemsPerPage;
        this.pageOrSortChanged.emit({ pagingInfo: this.pagingInfo });
    }
    /**
     *
     * This builds a clone of all the objects marked as "fixed-column" and over lays it on top of the existing table,
     * then makes a clone of the table headers to be sticky
     */
    computedFixedColumns(changes) {
        var _a;
        // For the select all checkbox, we only want to re-render the headers, not the whole table
        // we also don't want to do this on the page load, as we are ignoring the table render
        if (((_a = changes === null || changes === void 0 ? void 0 : changes.actionsInfo) === null || _a === void 0 ? void 0 : _a.previousValue) !== undefined) {
            setTimeout(() => {
                // having this inside the timeout allows the table to not re-render
                this.removeTableWidthStyles();
                this.prepareFixedColumns();
                if (this.paginatorTop) {
                    this.onDivScroll('scrollBottom', 'scrollTop'); // The table gets re-rendered, will need to adjust the left scroll
                }
            }, AdvancedGridComponent_1.RENDER_DELAY);
            // Don't render anything else on the table
            return;
        }
        // This will re-render the table when it is outside of the timeout
        // Reset widths in between resizing table calculations (allows table to be down-sized correctly)
        this.removeTableWidthStyles();
        setTimeout(() => {
            this.prepareFixedColumns();
            if (this.paginatorTop) {
                this.onDivScroll('scrollBottom', 'scrollTop'); // The table gets re-rendered, will need to adjust the left scroll
            }
        }, AdvancedGridComponent_1.RENDER_DELAY); // Give this a moment to render the table, then take the values
    }
    /**
     * Removes width and max-width from the table and table clone if `this.table` exists.
     */
    removeTableWidthStyles() {
        if (this.table) {
            this.renderer.removeStyle(this.table.nativeElement, 'width');
            this.renderer.removeStyle(this.table.nativeElement, 'max-width');
            this.renderer.removeStyle(this.tableClone.nativeElement, 'width');
            this.renderer.removeStyle(this.tableClone.nativeElement, 'max-width');
        }
    }
    /**
     * This prepares the fixed column's widths, meant to be a helper for
     * `computedFixedColumns()`.
     * @see computedFixedColumns
     */
    prepareFixedColumns() {
        const originalTR = this.table.nativeElement.querySelectorAll('tr');
        const clonedTR = this.tableClone.nativeElement.querySelectorAll('tr');
        for (let index = 0; index < originalTR.length; index += 1) {
            this.copySizeToClone(originalTR[index], clonedTR[index]);
        }
        let totalTableWidth = 5; // This is the border plus a small buffer
        // Add the total TD width to compute the total width
        this.table.nativeElement.querySelectorAll('tbody tr:first-child .fixed-column').forEach((td) => {
            totalTableWidth += td.offsetWidth;
        });
        // Assign width to cloned table
        this.renderer.setStyle(this.tableClone.nativeElement, 'width', totalTableWidth + 'px');
        // add the fixed header
        this.computeFixedHeader();
    }
    /**
     * This clones the table headers for sticky placement
     */
    computeFixedHeader() {
        // remove any previously added clones from the fixed header
        const elm = this.tableHeaderFixed.nativeElement;
        if (elm.children && elm.children.length > 0) {
            elm.innerHTML = '';
        }
        // clone the table heads for fixed placement
        this.cloneTableHead(this.table.nativeElement);
        this.cloneTableHead(this.tableClone.nativeElement);
        // set the container div width to the same width as the source table
        const totalWidth = this.table.nativeElement.style.width;
        this.renderer.setStyle(elm, 'width', totalWidth);
        // override max-width 100% set in table class
        this.renderer.setStyle(elm, 'max-width', totalWidth);
        // explicitly set table widths of sticky tables based on source table widths
        const sourceTableWidth = this.table.nativeElement.style.width;
        this.renderer.setStyle(elm.childNodes[0], 'width', sourceTableWidth);
        // align the fixed table right border
        const cloneTableWidth = this.tableClone.nativeElement.style.width;
        this.renderer.setStyle(elm.childNodes[1], 'width', cloneTableWidth);
        // set the top scrollbar container to the same width as our table
        this.renderer.setStyle(this.paginatorTop.nativeElement.childNodes[1].firstChild, 'width', totalWidth);
        const elemRect = this.paginatorTop.nativeElement.getBoundingClientRect();
        // position clone table directly below top pagination component
        this.renderer.setStyle(this.tableClone.nativeElement, 'top', elemRect.height + 'px');
    }
    setStickyOffsetPosition() {
        var _a, _b, _c;
        // store the position of our sticky element
        const bodyRect = (_b = (_a = this.viewport) === null || _a === void 0 ? void 0 : _a.target) === null || _b === void 0 ? void 0 : _b.getBoundingClientRect(), elemRect = (_c = this.paginatorTop) === null || _c === void 0 ? void 0 : _c.nativeElement.getBoundingClientRect();
        // set the position on initialization and don't overwrite in case the viewport position has changed
        if (!this.paginatorTopOffset) {
            // set position of paginator top relative to the parent viewport
            this.paginatorTopOffset = Math.max(0, (elemRect === null || elemRect === void 0 ? void 0 : elemRect.top) - Math.max(0, bodyRect === null || bodyRect === void 0 ? void 0 : bodyRect.top));
        }
        return elemRect;
    }
    triggerHeaderAction() {
        if (this.actionsInfo.enablePaginationBarSubmit) {
            this.actionsInfo.paginationBarSubmitTriggered.call(null);
            setTimeout(() => this.setStickyOffsetPosition(), AdvancedGridComponent_1.RENDER_DELAY);
        }
    }
    /**
     * Helper method to clone a given table headers
     * @param sourceTable
     */
    cloneTableHead(sourceTable) {
        var _a;
        const thead = sourceTable.querySelector('thead'); // find thead to copy
        const clone = thead.cloneNode(true); // copy children too
        const ths = [].slice.call(thead.querySelectorAll('th'));
        // set references to instance variables for use within this method's scoped functions
        const docRef = this.document;
        const renderer = this.renderer;
        /**
         * Store width and height of each th
         * getBoundingClientRect()'s dimensions include padding and borders
         */
        const thStyles = ths.map(function (th) {
            const rect = th.getBoundingClientRect();
            const style = docRef.defaultView.getComputedStyle(th, '');
            return {
                boundingWidth: rect.width,
                boundingHeight: rect.height,
                width: parseInt(style.width, 10),
                paddingLeft: parseInt(style.paddingLeft, 10)
            };
        });
        // Set widths of thead and tbody
        const totalWidth = thStyles.reduce(function (sum, cur) {
            return sum + cur.boundingWidth;
        }, 0);
        renderer.setStyle(sourceTable, 'width', totalWidth + 'px');
        renderer.setStyle(sourceTable, 'max-width', totalWidth + 'px');
        // set width of our cloned thead
        renderer.setStyle(clone, 'width', totalWidth - thStyles[0].boundingWidth + 'px');
        // Position thead
        const clones = [].slice.call(clone.querySelectorAll('th'));
        // Sets the actionlistener and widths of the th elements in thead
        const fun = function (th, i) {
            if (th.getElementsByClassName('select-all') && th.getElementsByClassName('select-all').length !== 0) {
                const acceptallChkBox = th.getElementsByClassName('select-all')[0];
                acceptallChkBox.addEventListener('click', this.selectAllActionEventHandler);
                this.selectAllCheckbox = acceptallChkBox;
            }
            else {
                th.addEventListener('click', this.sortEventHandler);
            }
            renderer.setStyle(th, 'width', thStyles[i].boundingWidth + 'px');
        };
        clones.forEach(fun.bind(this));
        const table = renderer.createElement('table');
        table.appendChild(clone); // add new thead row to new table
        // add new cloned table to sticky/fixed container
        renderer.appendChild((_a = this.tableHeaderFixed) === null || _a === void 0 ? void 0 : _a.nativeElement, table);
    }
    /**
     * Assign style properties to the cloned object and the fixed object
     */
    copySizeToClone(fixedEl, cloneEl) {
        const boundRect = fixedEl.getBoundingClientRect();
        this.renderer.setStyle(cloneEl, 'height', boundRect.height + 'px');
    }
    ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
};
AdvancedGridComponent.RENDER_DELAY = 400; // delay time for DOM rendering
AdvancedGridComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ChangeDetectorRef },
    { type: Document, decorators: [{ type: Inject, args: [DOCUMENT,] }] }
];
__decorate([
    Input(),
    __metadata("design:type", Array)
], AdvancedGridComponent.prototype, "datasource", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "primaryKey", void 0);
__decorate([
    Input(),
    __metadata("design:type", Array)
], AdvancedGridComponent.prototype, "tableHeaders", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "pagingInfo", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], AdvancedGridComponent.prototype, "sortHeader", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], AdvancedGridComponent.prototype, "sortDir", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "actionsInfo", void 0);
__decorate([
    Input(),
    __metadata("design:type", Function)
], AdvancedGridComponent.prototype, "getDisplayTextForHeaderField", void 0);
__decorate([
    Input(),
    __metadata("design:type", Function)
], AdvancedGridComponent.prototype, "getDisplayTextForRecordField", void 0);
__decorate([
    Input(),
    __metadata("design:type", Number)
], AdvancedGridComponent.prototype, "numberOfFixedColumns", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], AdvancedGridComponent.prototype, "viewPortContainer", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "customColumns", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "pageOrSortChanged", void 0);
__decorate([
    ViewChild('table'),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "table", void 0);
__decorate([
    ViewChild('tableClone'),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "tableClone", void 0);
__decorate([
    ViewChild('tableHeaderFixed'),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "tableHeaderFixed", void 0);
__decorate([
    ViewChild('paginatorTop'),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "paginatorTop", void 0);
__decorate([
    ViewChild('paginatorComponentSet'),
    __metadata("design:type", PaginatorComponent),
    __metadata("design:paramtypes", [PaginatorComponent])
], AdvancedGridComponent.prototype, "setPaginatorComponent", null);
__decorate([
    ViewChild('scrollTop'),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "scrollTop", void 0);
__decorate([
    ViewChild('scrollBottom'),
    __metadata("design:type", Object)
], AdvancedGridComponent.prototype, "scrollBottom", void 0);
__decorate([
    HostListener('window:resize', ['$event.target.innerWidth']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], AdvancedGridComponent.prototype, "onResize", null);
AdvancedGridComponent = AdvancedGridComponent_1 = __decorate([
    Component({
        selector: 'lib-advanced-grid',
        template: "<div *ngIf=\"datasource\" class=\"data-table-container\">\n  <div class=\"table-parent\">\n    <div class=\"paginator-container\" [ngClass]=\"pagingInfo.pageSize ? 'paginator-container-height' : ''\" #paginatorTop>\n      <div class=\"row\">\n        <div *ngIf=\"actionsInfo.paginationBarSubmitLabel\" class=\"col-md-2 button-container\">\n          <button id=\"headerSubmit\" class=\"btn btn-primary btn-sm btn-block btn-load\"\n            (click)=\"this.actionsInfo.paginationBarSubmitTriggered.call($event)\"\n            [ngClass]=\"{'disabled': !actionsInfo.enablePaginationBarSubmit}\">\n            {{actionsInfo.paginationBarSubmitLabel}}\n          </button>\n        </div>\n        <div *ngIf=\"pagingInfo.totalRecords\" [ngClass]=\"actionsInfo && actionsInfo.paginationBarSubmitLabel ? 'col-md-10' : 'col-md-12'\">\n          <lib-paginator #paginatorComponentSet [totalRecords]=\"pagingInfo.totalRecords\"\n            [itemPerPage]=\"pagingInfo.pageSize\" [pageSizeOptions]=\"pagingInfo.rowCountOptions\"\n            (pageChangeEvent)=\"onPaginationChange($event)\" [currentPageNumber]=\"pagingInfo.currentPageNumber\"></lib-paginator>\n        </div>\n      </div>\n      <div class=\"scroll-top\" #scrollTop (scroll)=\"onDivScroll('scrollTop', 'scrollBottom')\">\n        <div class=\"scroll-div\"></div>\n      </div>\n    </div>\n    <div class=\"sortable-table table-wrapper fixed-table-container\"  #scrollBottom (scroll)=\"onDivScroll('scrollBottom', 'scrollTop')\" appExternalLinks>\n      <div class=\"table table-striped table-header-fixed\" #tableHeaderFixed></div>\n      <table class=\"table table-striped\" #table>\n        <thead>\n        <tr>\n          <th *ngFor=\"let actionHeader of actionsInfo.columnActionOptions; trackBy: trackByFn; let col = index\"\n            [ngClass]=\"{'fixed-column': isFixedColumn(col)}\">\n            <div class=\"th-inner\">\n              <span>{{getDisplayTextForHeaderField(actionHeader)}}</span>\n              <lib-advanced-grid-cell-action *ngIf=\"actionsInfo.showActionColumnHeader\"\n                [cellActionInfo]=\"loadAdvGridCellActionInfo(actionHeader, true)\"\n              ></lib-advanced-grid-cell-action>\n            </div>\n          </th>\n          <th *ngFor=\"let header of tableHeaders; trackBy: trackByFn; let col = index\"\n              [id]=\"'ngKit-table-' + header.fieldName + col\"\n            [ngClass]=\"{'fixed-column': isFixedColumn(col)}\">\n            <div class=\"th-inner\" [ngClass]=\"getSortableClasses(header)\">\n              <span>{{getDisplayTextForHeaderField(header)}} <i *ngIf=\"header.filtered\" class=\"icon icon-filter-alt\"></i></span>\n            </div>\n          </th>\n        </tr>\n        </thead>\n        <tbody class=\"table-body-with-fixed\">\n        <tr *ngFor=\"let record of datasource; trackBy: trackByFn; let row = index\">\n          <td *ngFor=\"let actionHeader of actionsInfo.columnActionOptions; trackBy: trackByFn; let col = index\"\n            [ngClass]=\"{'fixed-column': isFixedColumn(col)}\">\n            <lib-advanced-grid-cell-action\n              [cellActionInfo]=\"loadAdvGridCellActionInfo(actionHeader, false, record)\"\n            ></lib-advanced-grid-cell-action>\n          </td>\n          <td *ngFor=\"let header of tableHeaders; trackBy: trackByFn; let col = index\" [ngClass]=\"computeClassesForTd(col, row, header)\">\n            <ng-container *ngIf=\"customColumns && customColumns[header.fieldName]; else defaultRecordDisplayText\">\n              <ng-container *ngTemplateOutlet=\"customColumns[header.fieldName]; context: { record: record }\"></ng-container>\n            </ng-container>\n            <ng-template #defaultRecordDisplayText>\n              <div [innerHtml]=\"getDisplayTextForRecordField(header.fieldName, record) | safe:'html'\"></div>\n            </ng-template>\n          </td>\n        </tr>\n        </tbody>\n      </table>\n      <table class=\"table-clone table table-striped\" #tableClone>\n        <thead>\n        <tr>\n          <th *ngFor=\"let actionHeader of actionsInfo.columnActionOptions; trackBy: trackByFn; let col = index\"\n            [ngClass]=\"{'fixed-column': isFixedColumn(col)}\">\n            <div class=\"th-inner\">\n              <span>{{getDisplayTextForHeaderField(actionHeader)}}</span>\n              <lib-advanced-grid-cell-action *ngIf=\"actionsInfo.showActionColumnHeader\"\n                [cellActionInfo]=\"loadAdvGridCellActionInfo(actionHeader, true)\"\n              ></lib-advanced-grid-cell-action>\n            </div>\n          </th>\n          <th *ngFor=\"let header of fixedTableHeaders; trackBy: trackByFn; let col = index\" (click)=\"sortBy(header)\"\n              [id]=\"'ngKit-advanced-grid-' + header.fieldName + col\">\n            <div class=\"th-inner\" [ngClass]=\"getSortableClasses(header)\">\n              <span>{{getDisplayTextForHeaderField(header)}} <i *ngIf=\"header.filtered\" class=\"icon icon-filter-alt\"></i></span>\n            </div>\n          </th>\n        </tr>\n        </thead>\n        <tbody>\n        <tr *ngFor=\"let record of datasource; trackBy: trackByFn; let row = index\">\n          <td *ngFor=\"let actionHeader of actionsInfo.columnActionOptions; trackBy: trackByFn; let col = index\"\n            [ngClass]=\"{'fixed-column': isFixedColumn(col)}\">\n            <lib-advanced-grid-cell-action\n              [cellActionInfo]=\"loadAdvGridCellActionInfo(actionHeader, false, record)\"\n            ></lib-advanced-grid-cell-action>\n          </td>\n          <td *ngFor=\"let header of fixedTableHeaders; trackBy: trackByFn; let col = index\" [ngClass]=\"computeClassesForTd(col, row, header)\">\n            <ng-container *ngIf=\"customColumns && customColumns[header.fieldName]; else defaultRecordDisplayText\">\n              <ng-container *ngTemplateOutlet=\"customColumns[header.fieldName]; context: { record: record }\"></ng-container>\n            </ng-container>\n            <ng-template #defaultRecordDisplayText>\n              <div [innerHtml]=\"getDisplayTextForRecordField(header.fieldName, record) | safe:'html'\"></div>\n            </ng-template>\n          </td>\n        </tr>\n        </tbody>\n      </table>\n    </div>\n  </div>\n</div>\n",
        encapsulation: ViewEncapsulation.None,
        changeDetection: ChangeDetectionStrategy.OnPush,
        styles: [".sortable-table thead th .sortable{cursor:pointer;background-position:right;background-repeat:no-repeat;padding-right:1em;position:relative}.sortable-table thead th .sortable span{padding-left:1em}.sortable-table thead th .both span:after{content:\"\\e051\";font-family:higux;margin-left:.2em;position:absolute;font-size:1.4em}.sortable-table thead th .asc span:after{content:\"\\e068\";font-family:higux;margin-left:.2em;position:absolute;font-size:1.7em}.sortable-table thead th .desc span:after{content:\"\\e064\";font-family:higux;margin-left:.2em;position:absolute;font-size:1.7em}.fixed-table-loading{display:none}.sortable-table-container{position:relative;display:inline-block;width:auto;z-index:1}.sortable-table-container:after{content:\"\\e044\";font-family:higux;text-align:center;line-height:29px;position:absolute;width:25px;height:29px;background:#f7f7f7;color:#3a5a78;right:-1px;top:-12%;pointer-events:none}.table-category-sm{display:block;height:100%;border:0;background:0 0;width:25px}.table.sortable-table thead:first-child>tr:first-child>th{border-top:1px solid #dadada}.table.sortable-table thead tr{display:block}.table.sortable-table thead tr th{bottom:30px;display:none;left:0;position:relative;width:163px;border:1px solid #dadada;padding-top:3px;padding-bottom:3px}.table.sortable-table thead tr th:first-child{display:block}.table.sortable-table thead tr th.displayNone{display:none}.table.sortable-table thead tr th.displayBlock{display:block}@media (min-width:768px){.sortable-table thead th .sortable span{padding-left:0}.sortable-table-container,.table-category-sm{display:none}.table.sortable-table span{padding-left:0}.table.sortable-table thead:first-child>tr:first-child>th{border-top:0}.table.sortable-table thead tr{display:table-row}.table.sortable-table thead tr th{display:table-cell;position:static;border:0;border-bottom:3px solid #3a5a78}.table.sortable-table thead tr th.displayBlock,.table.sortable-table thead tr th.displayNone,.table.sortable-table thead tr th:first-child{display:table-cell}.table.sortable-table>tbody>tr:hover>td{background-color:#f9f9f9}.table.sortable-table .column-selected{background-color:#e3f3ff}}.table a{text-decoration:none}.table a:hover{text-decoration:underline}.table>tbody>tr>td,.table>tbody>tr>th,.table>tfoot>tr>td,.table>tfoot>tr>th,.table>thead>tr>td,.table>thead>tr>th{padding:7px 10px!important}.table>tbody>tr>td b,.table>tfoot>tr>td b,.table>thead>tr>td b{white-space:nowrap}.table>tbody>tr>td.align-right-no-header,.table>tfoot>tr>td.align-right-no-header,.table>thead>tr>td.align-right-no-header{text-align:right}.table>tbody>tr:hover>td,.table>tfoot>tr:hover>td,.table>thead>tr:hover>td{background-color:transparent;cursor:default}.table th.align-right-no-header{color:#fff}span.disabled{font-weight:500;color:#7f7f7f}i.icon-xs{font-size:1em!important}.table-wrapper{width:100%;height:100%;overflow:hidden}.table-wrapper .table{margin-bottom:0}.table-wrapper .table thead tr th{padding:12px 12px 2px!important;vertical-align:bottom}.table-wrapper .table thead tr th .checkbox{margin:2px 0}.table-wrapper .table>tbody>tr>td,.table-wrapper .table>tfoot>tr>td{padding:12px!important}.filter-icon{padding-left:1.25em}.paginator-container{width:100%;position:relative;background-color:#fff;z-index:7}.paginator-container .scroll-top{overflow-x:auto;overflow-y:hidden}.paginator-container .scroll-div{height:1px;width:1000px}.paginator-container .paginator-container-height{height:85px}.table-parent{position:relative;overflow:hidden;height:100%}.table-parent .table-striped tbody tr:nth-of-type(even){background-color:#fff}.table-parent .table-header-fixed{position:absolute;z-index:7;left:0}.table-parent .table-header-fixed table{margin-bottom:0;position:absolute;left:0;background-color:#fff}.table-parent .table-header-fixed table:nth-child(2){border-right:3px solid #3a5a78}.table-parent .table-clone{background-color:#fff;border-right:3px solid #3a5a78;position:absolute;top:0;left:0}.button-container{padding-top:1rem}.header-copeDiscrepancyLink{min-width:21em}.header-submNumOfStry{min-width:8.5em}"]
    }),
    __param(2, Inject(DOCUMENT)),
    __metadata("design:paramtypes", [Renderer2,
        ChangeDetectorRef,
        Document])
], AdvancedGridComponent);

let AdvancedGridCellActionComponent = class AdvancedGridCellActionComponent {
    editRecord() {
        this.cellActionInfo.actionRecord('edit', this.cellActionInfo.record);
    }
    toggleRecordSelect() {
        if (this.cellActionInfo.record) {
            this.cellActionInfo.record[this.cellActionInfo.actionSelectIndicator] = !this.cellActionInfo.record[this.cellActionInfo.actionSelectIndicator];
        }
        this.cellActionInfo.actionRecord(this.cellActionInfo.header, this.cellActionInfo.record, this.cellActionInfo.record[this.cellActionInfo.actionSelectIndicator]);
    }
};
__decorate([
    Input(),
    __metadata("design:type", Object)
], AdvancedGridCellActionComponent.prototype, "cellActionInfo", void 0);
AdvancedGridCellActionComponent = __decorate([
    Component({
        selector: 'lib-advanced-grid-cell-action',
        template: "<div *ngIf=\"cellActionInfo && cellActionInfo.record\">\n  <div *ngIf=\"cellActionInfo.header !== 'edit'\" class=\"form-group\">\n    <div class=\"checkbox checkbox-center\">\n      <label class=\"checkbox-inline checkbox-inline-alt\"\n        [attr.disabled]=\"cellActionInfo.record['disabledField'] ? true : null\">\n        <input type=\"checkbox\"\n          [value]=\"cellActionInfo.record[cellActionInfo.actionIdField]\"\n          [checked]=\"cellActionInfo.record[cellActionInfo.actionSelectIndicator]\"\n          (click)=\"toggleRecordSelect()\"\n          [disabled]=\"cellActionInfo.record['disabledField']\"\n        ><span></span>\n      </label>\n    </div>\n  </div>\n  <div class=\"center-cell-text\" *ngIf=\"cellActionInfo.header === 'edit'\">\n    <i class=\"icon-edit icon-2x\" (click)=\"editRecord()\"></i>\n  </div>\n  <div *ngIf=\"cellActionInfo.header === 'editStatus'\" class=\"center-cell-text\">\n    <i *ngIf=\"cellActionInfo.record.editStatus === 'not complete'\" class=\"icon-bullet-not-valid icon-2x\" (click)=\"editRecord()\"></i>\n    <i *ngIf=\"cellActionInfo.record.editStatus === 'complete'\" class=\"icon-bullet-check-mark icon-2x\" (click)=\"editRecord()\"></i>\n  </div>\n</div>\n<div *ngIf=\"cellActionInfo && !cellActionInfo.record\">\n  <div *ngIf=\"cellActionInfo.showActionHeader\" class=\"form-group\">\n    <div class=\"checkbox checkbox-center\">\n      <label class=\"checkbox-inline checkbox-inline-alt\" [attr.disabled]=\"cellActionInfo.actionHeaderDisabled? true: null\">\n        <!-- As the src table header is cloned, onclick event for this input is provided in the data-table.component -->\n        <input type=\"checkbox\" class=\"select-all\" [checked]=\"cellActionInfo.selectAllChecked\" [disabled]=\"cellActionInfo.actionHeaderDisabled\"><span></span>\n      </label>\n    </div>\n  </div>\n</div>\n\n",
        styles: [".center-cell-text,.checkbox-center{text-align:center}.checkbox-center .checkbox-inline{padding-left:0}.checkbox-center .checkbox-inline input[type=checkbox]~::before{margin-left:0;margin-right:0}"]
    })
], AdvancedGridCellActionComponent);

var PaginatorModule_1;
let PaginatorModule = PaginatorModule_1 = class PaginatorModule {
    static forRoot() {
        return {
            ngModule: PaginatorModule_1,
            providers: [ScrollingHelper]
        };
    }
};
PaginatorModule = PaginatorModule_1 = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule
        ],
        declarations: [PaginatorComponent],
        exports: [PaginatorComponent]
    })
], PaginatorModule);

let SafePipe = class SafePipe {
    constructor(_sanitizer) {
        this._sanitizer = _sanitizer;
    }
    transform(value, type) {
        if (!value) {
            return value;
        }
        switch (type) {
            case 'html':
                return this._sanitizer.bypassSecurityTrustHtml(value);
            case 'style':
                return this._sanitizer.bypassSecurityTrustStyle(value);
            case 'script':
                return this._sanitizer.bypassSecurityTrustScript(value);
            case 'url':
                return this._sanitizer.bypassSecurityTrustUrl(value);
            case 'resourceUrl':
                return this._sanitizer.bypassSecurityTrustResourceUrl(value);
            default:
                // unrecognized type passed - don't bypass - sanitize content
                return this._sanitizer.sanitize(SecurityContext.HTML, value);
        }
    }
};
SafePipe.ctorParameters = () => [
    { type: DomSanitizer }
];
SafePipe = __decorate([
    Pipe({ name: 'safe' }),
    __metadata("design:paramtypes", [DomSanitizer])
], SafePipe);

var PipesModule_1;
let PipesModule = PipesModule_1 = class PipesModule {
    static forRoot() {
        return {
            ngModule: PipesModule_1,
            providers: [],
        };
    }
};
PipesModule = PipesModule_1 = __decorate([
    NgModule({
        imports: [],
        declarations: [SafePipe],
        exports: [SafePipe]
    })
], PipesModule);

let AdvancedGridModule = class AdvancedGridModule {
};
AdvancedGridModule = __decorate([
    NgModule({
        declarations: [AdvancedGridComponent, AdvancedGridCellActionComponent],
        imports: [
            CommonModule,
            PaginatorModule,
            PipesModule
        ],
        exports: [AdvancedGridComponent]
    })
], AdvancedGridModule);

let CardComponent = class CardComponent {
    constructor() {
        this.cardClass = '';
        this.borderClass = '';
        this.innerPadding = true;
    }
};
__decorate([
    Input(),
    __metadata("design:type", String)
], CardComponent.prototype, "cardClass", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], CardComponent.prototype, "borderClass", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], CardComponent.prototype, "innerPadding", void 0);
CardComponent = __decorate([
    Component({
        selector: 'lib-card',
        template: "<div class=\"card-heading clearfix {{cardClass}}\">\n    <div class=\"card-left-title card-title\">\n            <ng-content select=\"[left-title]\"></ng-content>\n    </div>\n    <div class=\"card-right-title card-title\">\n        <ng-content select=\"[right-title]\"></ng-content>\n    </div>\n</div>\n<div class=\"card card-soft {{borderClass}}\" [ngClass]=\"{'remove-padding': !innerPadding}\" >\n        <ng-content select=\"[card-content-container]\"></ng-content>\n</div> \n    \n",
        styles: [".remove-padding{padding:0}.card-left-title{font-weight:500;float:left}.card-right-title{font-weight:500;float:right}.card-heading{padding:9px 20px}.card-soft{border-radius:0;border-width:0 .25em .25em;color:#484848}"]
    })
], CardComponent);

let CardModule = class CardModule {
};
CardModule = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        declarations: [CardComponent],
        exports: [CardComponent]
    })
], CardModule);

let EventAggregatorService = class EventAggregatorService {
    constructor() {
        this.handler = new Subject();
    }
    // Broadcast method
    broadcast(type, payload) {
        this.handler.next({ type, payload });
    }
    // subscribe method
    subscribe(type, callback) {
        return this.handler
            .pipe(filter(message => message.type === type), map(message => message.payload))
            .subscribe(callback);
    }
};
EventAggregatorService.ɵprov = ɵɵdefineInjectable({ factory: function EventAggregatorService_Factory() { return new EventAggregatorService(); }, token: EventAggregatorService, providedIn: "root" });
EventAggregatorService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [])
], EventAggregatorService);

let EventAggregatorModule = class EventAggregatorModule {
};
EventAggregatorModule = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        providers: [EventAggregatorService]
    })
], EventAggregatorModule);

class Address {
    constructor(options) {
        if (options) {
            this.addressLine1 = options.addressLine1 && options.addressLine1.trim();
            this.addressLine2 = options.addressLine2 && options.addressLine2.trim();
            this.city = options.city && options.city.trim();
            this.county = options.county && options.county.trim();
            this.state = options.state && options.state.trim();
            // normalize zip codes to be 5 characters long - address validation service may return full zip
            this.zipCode = options.zipCode && options.zipCode.trim().substr(0, 5);
            this.addressStandardized = options.addressStandardized;
        }
    }
    static formatAddressString(data, fieldName) {
        let addressString;
        if (fieldName) {
            addressString = `${data[fieldName + 'AddressLine1']}`;
            if (data.apt) {
                addressString += `, ${data[fieldName + 'Apt']}`;
            }
            if (data.addressLine2) {
                addressString += `<br/>${data[fieldName + 'AddressLine2']}`;
            }
            addressString += `<br/>${data[fieldName + 'City']}, ${data[fieldName + 'State']} ${data[fieldName + 'ZipCode']}`;
        }
        else {
            addressString = `${data.addressLine1}`;
            if (data.apt) {
                addressString = `, ${data.apt}`;
            }
            if (data.addressLine2) {
                addressString = `<br/>${data.addressLine2}`;
            }
            addressString += `<br/>${data.city}, ${data.state} ${data.zipCode}`;
        }
        return addressString;
    }
    static formatAddress(data, fieldName) {
        const address = [];
        let addressString;
        if (fieldName) {
            addressString = `${data[fieldName + 'AddressLine1']}`;
            if (data.apt) {
                addressString += `, ${data[fieldName + 'Apt']}`;
            }
            if (data.addressLine2) {
                addressString += `, ${data[fieldName + 'AddressLine2']}`;
            }
            if (data.apt || data.addressLine2) {
                address.push(addressString, `, ${data[fieldName + 'City']}, ${data[fieldName + 'State']} ${data[fieldName + 'ZipCode']}`);
            }
            else {
                address.push(`${data[fieldName + 'AddressLine1']}, ${data[fieldName + 'City']}, ${data[fieldName + 'State']}
         ${data[fieldName + 'ZipCode']}`);
            }
        }
        else {
            addressString = `${data[fieldName + 'AddressLine1']}`;
            if (data.apt) {
                addressString += `, ${data.apt}`;
            }
            if (data.addressLine2) {
                addressString += `, ${data.addressLine2}`;
            }
            if (data.apt || data.addressLine2) {
                address.push(addressString, `${data.city}, ${data.state} ${data.zipCode}`);
            }
            else {
                address.push(`${data.addressLine1}, ${data.city}, ${data.state} ${data.zipCode}`);
            }
        }
        return address;
    }
}
class AddressForm {
    constructor(fb) {
        this.fb = fb;
    }
    createNewFormGroup(data) {
        if (!data) {
            data = {
                addressLine1: '',
                city: '',
                state: '',
                zipCode: ''
            };
        }
        const formGroup = this.fb.group({
            addressLine1: [data.addressLine1, Validators.required],
            city: [data.city, [Validators.required, Validators.maxLength(250)]],
            county: [data.county],
            state: [data.state, Validators.required],
            zipCode: [data.zipCode, [
                    Validators.required,
                    Validators.maxLength(5),
                    Validators.minLength(5),
                    Validators.pattern('[0-9]*') // Only allow numbers
                ]]
        });
        if (data.addressLine2) {
            formGroup.addControl('addressLine2', new FormControl([data.addressLine2]));
        }
        if (data.apt) {
            formGroup.addControl('apt', new FormControl([data.apt]));
        }
        return formGroup;
    }
}

/**
 * This is not a real service, but it looks like it from the outside.
 * It's just an InjectionTToken used to import the config object, provided from the outside
 */
const ApiKeyConfigService = new InjectionToken('GoogleConfig');

const getScriptSrc = (apiKey) => {
    return `//maps.googleapis.com/maps/api/js?libraries=places&key=${apiKey}`;
};
const ɵ0 = getScriptSrc;
let GoogleAutocompleteService = class GoogleAutocompleteService {
    constructor(config) {
        this.config = config;
        this.scripts = {};
        this.scripts = {
            loaded: false,
            src: getScriptSrc(this.config.apiKey)
        };
    }
    loadScript(name = 'Google apikey load') {
        return new Promise((resolve, reject) => {
            if (!document.getElementById('google-api')) { // Load once
                // load script
                const script = document.createElement('script');
                script.type = 'text/javascript';
                script.async = true;
                script.defer = true;
                script.id = 'google-api';
                script.src = this.scripts.src;
                if (script.readyState) { // IE
                    script.onreadystatechange = () => {
                        if (script.readyState === 'loaded' || script.readyState === 'complete') {
                            script.onreadystatechange = null;
                            this.scripts.loaded = true;
                            resolve({ script: name, loaded: true, status: 'Loaded' });
                        }
                    };
                }
                else { // Others
                    script.onload = () => {
                        this.scripts.loaded = true;
                        resolve({ script: name, loaded: true, status: 'Loaded' });
                    };
                }
                script.onerror = (error) => resolve({ script: name, loaded: false, status: 'Loaded' });
                document.getElementsByTagName('body')[0].appendChild(script);
            }
            else {
                resolve({ script: name, loaded: true, status: 'Already Loaded' });
            }
        });
    }
};
GoogleAutocompleteService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [ApiKeyConfigService,] }] }
];
GoogleAutocompleteService.ɵprov = ɵɵdefineInjectable({ factory: function GoogleAutocompleteService_Factory() { return new GoogleAutocompleteService(ɵɵinject(ApiKeyConfigService)); }, token: GoogleAutocompleteService, providedIn: "root" });
GoogleAutocompleteService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __param(0, Inject(ApiKeyConfigService)),
    __metadata("design:paramtypes", [Object])
], GoogleAutocompleteService);

let GoogleAutocompleteDirective = class GoogleAutocompleteDirective {
    constructor(elem, googleAutocompleteService) {
        this.elem = elem;
        this.googleAutocompleteService = googleAutocompleteService;
        this.address = new Address();
        this.addressChange = new EventEmitter();
    }
    ngAfterViewInit() {
        this.googleAutocompleteService.loadScript().then(data => {
            this.getPlaceAutocomplete();
        }).catch(error => { });
    }
    /**
     * Handles google auto complete and address change event
     */
    getPlaceAutocomplete() {
        const autoComplete = new google.maps.places.Autocomplete(this.elem.nativeElement, {
            types: ['geocode'] // 'establishment' / 'address' / 'geocode'
        });
        if (autoComplete) {
            google.maps.event.addListener(autoComplete, 'place_changed', () => {
                const result = autoComplete.getPlace();
                if (result.address_components) {
                    this.addressChangeHandle(result.address_components);
                }
            });
        }
    }
    /**
     * addressChangeHandle emmit formatted address
     * @param addressComponents
     */
    addressChangeHandle(addressComponents) {
        if (addressComponents) {
            // Reset all the address field after every autocomplete selection
            this.address.addressLine1 = this.address.city = this.address.state = this.address.zipCode = '';
            for (const addr of addressComponents) {
                if (addr.types && addr.types.length > 0) {
                    switch (addr.types[0]) {
                        case 'street_number':
                            this.address.addressLine1 = addr.long_name;
                            break;
                        case 'route':
                            // Street name
                            this.address.addressLine1 += ' ' + addr.long_name;
                            this.address.addressLine1 = this.address.addressLine1.trim();
                            break;
                        case 'neighborhood':
                            // occasionally operates at a landmark location (EX: Duke University)
                            // when other information is unavailable. for that reason use it if addressLine1 is empty
                            if (!this.address.addressLine1) {
                                this.address.addressLine1 = addr.long_name;
                            }
                            break;
                        case 'locality':
                            // Ex: New Haven
                            this.address.city = addr.long_name;
                            break;
                        case 'administrative_area_level_1':
                            // Typically state, level 2 would be a county
                            this.address.state = addr.short_name;
                            break;
                        case 'postal_code':
                            this.address.zipCode = addr.short_name;
                            break;
                    }
                }
            }
            this.addressChange.emit(this.address);
        }
    }
};
GoogleAutocompleteDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: GoogleAutocompleteService }
];
__decorate([
    Output(),
    __metadata("design:type", Object)
], GoogleAutocompleteDirective.prototype, "addressChange", void 0);
GoogleAutocompleteDirective = __decorate([
    Directive({
        selector: '[libGoogleAutocomplete]'
    }),
    __metadata("design:paramtypes", [ElementRef, GoogleAutocompleteService])
], GoogleAutocompleteDirective);

var GoogleAutocompleteModule_1;
let GoogleAutocompleteModule = GoogleAutocompleteModule_1 = class GoogleAutocompleteModule {
    static forRoot(config) {
        return {
            ngModule: GoogleAutocompleteModule_1,
            providers: [
                GoogleAutocompleteService,
                {
                    provide: ApiKeyConfigService,
                    useValue: config
                }
            ]
        };
    }
};
GoogleAutocompleteModule = GoogleAutocompleteModule_1 = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        declarations: [GoogleAutocompleteDirective],
        exports: [GoogleAutocompleteDirective]
    })
], GoogleAutocompleteModule);

class LoggerConfig {
}
let HigLoggerService = class HigLoggerService {
    constructor(config) {
        // if config object is exists with env value update the env
        if (config && config.env) {
            this.env = config.env;
        }
    }
    log(...args) {
        // Don't log in production and QA environment's
        if (this.env === 'prod' || this.env === 'qa' || this.isTestingEnv()) {
            return;
        }
        if (console) {
            try {
                console.log.apply(this, args);
            }
            catch (e) {
                const message = Array.prototype.slice.apply(args).join(' ');
                console.log(message);
            }
        }
    }
    debug(...args) {
        return this.log.apply(this, args);
    }
    error(...args) {
        if (console) {
            try {
                if (console.error) {
                    console.error.apply(this, args);
                }
                else {
                    this.log(args);
                }
            }
            catch (e) {
                const message = Array.prototype.slice.apply(args).join(' ');
                console.log(message);
            }
        }
    }
    table(...args) {
        // Don't log in production and QA environment's
        if (this.env === 'prod' || this.env === 'qa' || this.isTestingEnv()) {
            return;
        }
        if (console) {
            try {
                if (console.table) {
                    console.table.apply(this, args);
                }
                else {
                    this.log(args);
                }
            }
            catch (e) {
                const message = Array.prototype.slice.apply(args).join(' ');
                console.log(message);
            }
        }
    }
    isTestingEnv() {
        // Karma detection
        return window.hasOwnProperty('__karma__');
    }
};
HigLoggerService.ctorParameters = () => [
    { type: LoggerConfig, decorators: [{ type: Optional }] }
];
HigLoggerService.ɵprov = ɵɵdefineInjectable({ factory: function HigLoggerService_Factory() { return new HigLoggerService(ɵɵinject(LoggerConfig, 8)); }, token: HigLoggerService, providedIn: "root" });
HigLoggerService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __param(0, Optional()),
    __metadata("design:paramtypes", [LoggerConfig])
], HigLoggerService);

var HigLoggerModule_1;
let HigLoggerModule = HigLoggerModule_1 = class HigLoggerModule {
    static forRoot(config) {
        return {
            ngModule: HigLoggerModule_1,
            providers: [
                HigLoggerService,
                {
                    provide: LoggerConfig,
                    useValue: config
                }
            ]
        };
    }
};
HigLoggerModule = HigLoggerModule_1 = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        providers: [HigLoggerService]
    })
], HigLoggerModule);

class FieldComponentBase {
    constructor() {
        this._hasError = false;
    }
    /**
     *  hasError sets applicable message
     */
    hasError() {
        if (this.field && this.field.validations && this.field.validations.length > 0
            && this.group && this.group.controls[this.field.name] && this.group.controls[this.field.name].touched) {
            for (const validation of this.field.validations) {
                if (this.group && this.group.get(this.field.name).hasError(validation.name)) {
                    this._hasError = true;
                    this.errorMessage = validation.message;
                    break;
                }
                else {
                    this._hasError = false;
                    this.errorMessage = null;
                }
            }
        }
        else {
            this._hasError = false;
            this.errorMessage = null;
        }
        return this._hasError;
    }
}
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], FieldComponentBase.prototype, "group", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FieldComponentBase.prototype, "field", void 0);

let FormUtilitiesService = class FormUtilitiesService {
    constructor(fb) {
        this.fb = fb;
        this.emailRegEx = new RegExp(/@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,20})$/i);
    }
    static getPlainTextLabel(field) {
        if (field.label.indexOf('<') > -1) {
            return field.label.replace(/<[^>]+>/g, '');
        }
        return field.label;
    }
    /**
     * Walks a form chain and marks all controls dirty and emits event
     * @param group
     */
    markControlsDirty(group) {
        Object.keys(group.controls).forEach((key) => {
            const abstractControl = group.controls[key];
            if (abstractControl instanceof FormGroup || abstractControl instanceof FormArray) {
                this.markControlsDirty(abstractControl);
            }
            else {
                abstractControl.markAsDirty();
                abstractControl.updateValueAndValidity({ onlySelf: false, emitEvent: true });
            }
        });
    }
    /**
     * Converts a given form groups errors to an abject with user friend errors
     * @param form
     * @param validationMessages
     * @param force
     */
    validateForm(form, validationMessages, force) {
        if (force) {
            this.markControlsDirty(form);
        }
        const fields = form.controls;
        const controlErrors = {};
        for (const field in fields) {
            if (fields[field]) {
                // Check field is touched and invalid
                // might need a way to know if focus was lost
                if (((fields[field].dirty || force) && !fields[field].valid) || fields[field].touched) {
                    controlErrors[field] = []; // define array to put error messages in
                    for (const error in fields[field].errors) {
                        if (fields[field].errors[error] && validationMessages[field] && validationMessages[field].hasOwnProperty(error)) {
                            // add error to array
                            controlErrors[field].push(validationMessages[field][error]);
                        }
                    }
                }
                else {
                    // mark field as false for errors
                    controlErrors[field] = [];
                }
            }
        }
        return controlErrors;
    }
    /**
     * Flattens potentially nested FormGroups and FormArrays to single array of controls
     * @param group
     */
    flattenForm(group) {
        const flattend = [];
        Object.keys(group.controls).forEach((key) => {
            const abstractControl = group.controls[key];
            // test if we have a control or a group that needs to be flattened further
            if (abstractControl instanceof FormGroup || abstractControl instanceof FormArray) {
                flattend.push(...this.flattenForm(abstractControl));
            }
            else {
                flattend.push(abstractControl);
            }
        });
        return flattend;
    }
    /**
     * Angular doesn't wait for async validators to complete. So the form may be invalid if the validators have not resolved.
     * Invokes every controls synchronous and asynchronous validators and returns a boolean indicating whether or not all validation passed
     * @param formGroup
     */
    validateFormAsynchronously(formGroup) {
        // flatten potentially nested FormGroups and FormArrays to single array of controls
        const controls = this.flattenForm(formGroup);
        const syncValidationErrors = Object.keys(controls).map(c => {
            const control = controls[c];
            return !control.validator ? null : control.validator(control);
        }).filter(errors => !!errors);
        return combineLatest(Object.keys(controls).map(c => {
            const control = controls[c];
            return !control.asyncValidator ? of(null) : control.asyncValidator(control);
        })).pipe(map(asyncValidationErrors => {
            const hasErrors = [...syncValidationErrors, ...asyncValidationErrors.filter(errors => !!errors)].length;
            if (hasErrors) { // ensure errors display in UI...
                Object.keys(controls).forEach(key => {
                    controls[key].markAsTouched();
                    controls[key].updateValueAndValidity();
                });
            }
            return !hasErrors;
        })).toPromise();
    }
    /**
     * Custom email validator
     */
    validateEmail() {
        return (c) => {
            const isValid = this.emailRegEx.test(c.value);
            if (isValid) {
                return null;
            }
            else {
                return { required: true };
            }
        };
    }
    /**
     * Find any input elements on the page that are in a invalid state and focus on the first
     */
    focusInvalid(selector) {
        // checking if element is visible
        function isVisible(elem) {
            // checkboxes and radio inputs are hidden and replaced by icons
            if (elem.type === 'checkbox' || elem.type === 'radio') {
                // this class keeps the element hidden yet allows us to calculate it's offset properties
                elem.classList.add('focus-hidden');
            }
            // determine if element is visible on the page
            return elem.offsetWidth > 0 || elem.offsetHeight > 0 || elem.getClientRects().length > 0;
        }
        // find any invalid fields - checkboxes only have a invalid state added to the parent so we need to look for the parent and child
        const items = selector || 'input.ng-invalid, select.ng-invalid, textarea.ng-invalid, .has-error input[type="checkbox"], ' +
            '.btn-group.ng-invalid, .has-error input[type="radio"], .has-error select, .message-warning, .message-danger';
        // creates a plain array with the results of your selector filtered by isVisible
        const elements = Array.prototype.slice.call(document.querySelectorAll(items)).filter(isVisible);
        // did we find any invalid elements visible on the screen (these may be scrolled outside the viewport)
        if (elements.length) {
            if (!('scrollBehavior' in document.documentElement.style)) {
                elements[0].scrollIntoView(false);
            }
            else {
                elements[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
        // cleanup any added classes
        const hidden = document.querySelectorAll('.focus-hidden');
        [].forEach.call(hidden, function (el) {
            el.classList.remove('focus-hidden');
        });
    }
    /**
     * Enables/Disables button and sets loading text while disabled
     * @param selector
     * @param loadingMessage
     */
    toggleButton(selector, loadingMessage) {
        const loadingText = loadingMessage || '<i class=\'icon icon-spinner icon-pulse icon-btn\' aria-label="Loading"></i> Saving';
        const button = document.querySelector(selector);
        const isDisabled = button.classList.contains('disabled');
        if (isDisabled) {
            button.classList.remove('disabled');
            button.innerHTML = button.getAttribute('data-text-original');
            button.disabled = false;
        }
        else {
            button.classList.add('disabled');
            button.setAttribute('data-text-original', button.innerHTML);
            button.innerHTML = loadingText;
            button.disabled = true;
        }
    }
    /**
     * binds validations with field if applicable
     * @param validations
     */
    bindValidations(validations, field) {
        if (validations.length > 0) {
            const validList = [];
            for (const validation of validations) {
                if (validation && validation.name && field) {
                    switch (validation.name) {
                        case 'min':
                            validList.push(Validators.min(validation.min));
                            break;
                        case 'max':
                            validList.push(Validators.max(validation.max));
                            break;
                        case 'minLength':
                            validList.push(Validators.minLength(validation.minLength));
                            break;
                        case 'maxLength':
                            validList.push(Validators.maxLength(validation.maxLength));
                            break;
                        case 'required':
                            validList.push(Validators.required);
                            break;
                        case 'pattern':
                            let regExp;
                            if (validation.globalModifiers) {
                                regExp = new RegExp(validation.pattern, validation.globalModifiers);
                            }
                            else {
                                regExp = RegExp(validation.pattern);
                            }
                            validList.push(Validators.pattern(regExp));
                            break;
                    }
                }
            }
            return Validators.compose(validList);
        }
        return null;
    }
    /**
     * Validates each fields in the form
     * @param formGroup
     */
    validateAllFormFields(formGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control) {
                control.markAsTouched({ onlySelf: true });
            }
        });
        this.markControlsDirty(formGroup);
    }
    /**
     * Create form control for the given options
     * @param option
     */
    createFormControl(option) {
        if (option && option.formGroup && option.fieldName) {
            const control = this.fb.control(option.fieldValue, this.bindValidations(option.validations || [], option.field));
            option.formGroup.addControl(option.fieldName, control);
        }
    }
};
FormUtilitiesService.ctorParameters = () => [
    { type: FormBuilder }
];
FormUtilitiesService.ɵprov = ɵɵdefineInjectable({ factory: function FormUtilitiesService_Factory() { return new FormUtilitiesService(ɵɵinject(FormBuilder)); }, token: FormUtilitiesService, providedIn: "root" });
FormUtilitiesService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [FormBuilder])
], FormUtilitiesService);

let DatepickerComponent = class DatepickerComponent extends FieldComponentBase {
    constructor(fb, eventAggregatorService) {
        super();
        this.fb = fb;
        this.eventAggregatorService = eventAggregatorService;
        this.field = {
            type: 'datePicker',
            showField: true,
            readOnly: true,
            label: 'Date',
            name: 'effectiveDate',
            className: 'datepicker-row'
        };
        this.dateChange = new EventEmitter();
        this.colorTheme = 'theme-dark-blue';
        /**
         * Subscription property
         */
        this.subManager = new Subscription();
    }
    ngOnInit() {
        // If hideDefaultDate is true don't set any default value in datepicker field
        if (this.group && !this.group.get(this.field.name)) {
            this.updateControl();
        }
        else {
            this.group = this.fb.group({});
            this.updateControl();
        }
        // If setMinDate has a value, this will disable selecting of dates beyond a min date
        if (this.field.setMinDate >= 0) {
            this.minDate = new Date();
            this.minDate.setDate(this.minDate.getDate() - this.field.setMinDate);
        }
        // If setMaxDate has a value, this will disable selecting of dates beyond a max date
        if (this.field.setMaxDate >= 0) {
            this.maxDate = new Date();
            this.maxDate.setDate(this.maxDate.getDate() + this.field.setMaxDate);
        }
        this.bsConfig = Object.assign({}, {
            minDate: this.minDate,
            maxDate: this.maxDate,
            containerClass: this.colorTheme,
            customTodayClass: 'custom-today-class',
            showWeekNumbers: false
        });
        this.subscribeEventAggregator();
    }
    /**
     * subscribeEventAggregator subscribe broadcasted event for datepicker validations.
     */
    subscribeEventAggregator() {
        // subscribe to validation events from form engine parent component
        const sub = this.eventAggregatorService.subscribe('validateDatepickerForFormEngine', (payload) => {
            this.updateControl(true);
        });
        // add subscription to subscription manager
        this.subManager.add(sub);
    }
    /**
     * common method to update form control
     */
    updateControl(updated) {
        if (updated && !this.field.showField) {
            this.group.removeControl(this.field.name);
        }
        else {
            if (this.field.hideDefaultDate && !this.group.get(this.field.name)) {
                if (this.field.validations && this.field.validations.length > 0) {
                    this.group.addControl(this.field.name, new FormControl(null, Validators.required));
                }
                else {
                    this.group.addControl(this.field.name, new FormControl(null));
                }
            }
            else {
                // If a value is provided set it as default date
                if (this.field.value) {
                    this.dateFieldValue = (this.field.value);
                    // else set today's date as default date
                }
                else {
                    this.dateFieldValue = new Date();
                    // if field.value is not set, set current date to it
                    this.field.value = this.dateFieldValue;
                }
                const fieldValue = (this.dateFieldValue.getMonth() + 1) + '/'
                    + this.dateFieldValue.getDate() + '/'
                    + this.dateFieldValue.getFullYear();
                this.group.addControl(this.field.name, new FormControl(fieldValue));
            }
        }
    }
    bsValueChangeHandler(date) {
        /**
         * Update group for the form engine
         */
        if (date && date instanceof Date && !String(date).includes('Invalid')) {
            if (this.group && this.field && this.group.get(this.field.name)) {
                this.group.get(this.field.name).patchValue(date);
            }
            this.dateChange.emit({ date });
        }
        if (this.field && this.field.eventName) {
            this.eventAggregatorService.broadcast(this.field.eventName, { date: date, field: this.field });
        }
    }
    /**
   * This method gets triggered when date UI gets hidden
   * we will manually set the control to touched
   */
    setTouched() {
        if (this.group && this.group.get(this.field.name)) {
            this.group.get(this.field.name).markAsTouched();
        }
    }
    getPlainTextLabel() {
        return FormUtilitiesService.getPlainTextLabel(this.field);
    }
    ngOnDestroy() {
        this.subManager.unsubscribe();
    }
};
DatepickerComponent.ctorParameters = () => [
    { type: FormBuilder },
    { type: EventAggregatorService }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], DatepickerComponent.prototype, "field", void 0);
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], DatepickerComponent.prototype, "group", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], DatepickerComponent.prototype, "dateChange", void 0);
DatepickerComponent = __decorate([
    Component({
        selector: 'lib-datepicker',
        template: "<ng-container *ngIf=\"group\">\n    <div class=\"form-group\"  *ngIf=\"field && field.showField\" libFormGroupHighlight [field]=\"field\"\n        [ngClass]=\"{'ng-invalid has-error': hasError()}\" [formGroup]=\"group\">\n        <div class=\"row label-container {{field.className}}\" *ngIf=\"field.label\">\n            <div class=\"{{field.labelClass}}\">\n                <ng-container *ngIf=\"field.hasHtml; else nonHtmlLabelTemRef\">\n                    <div class=\"control-label\" aria-hidden=\"true\" [innerHTML]=\"field.label | safe: 'html'\"></div>\n                    <label [for]=\"field.name\" class=\"sr-only\" [id]=\"field.name + 'Label'\">{{getPlainTextLabel()}}</label>\n                </ng-container>\n                <ng-template #nonHtmlLabelTemRef>\n                    <label [for]=\"field.name\" class=\"control-label\" [id]=\"field.name + 'Label'\" aria-hidden=\"true\">\n                        {{field.label}}</label>\n                </ng-template>\n                <lib-tooltip placement=\"top\" *ngIf=\"field.helpText\" [enableSingleTooltip]=\"true\" [id]=\"field.name + 'ToolTip'\" [tealiumContent]=\"{'eventValue': field.helpText, 'tealiumTracking': field.isTealiumAllowed}\">\n                    <p class=\"tooltip-content-body-text\">{{field.helpText}}</p>\n                </lib-tooltip>\n                <small class=\"help-block\" *ngIf=\"field.extraLabel\">{{field.extraLabel}}</small>\n            </div>\n        </div>\n        <div class=\"row {{field.className}}\">\n            <div class=\"{{field.inputClass}}\">\n                <div class=\"input-group date date-time-picker\" [ngClass]=\"{'input-disabled': field.disabled}\">\n                    <ng-container *ngIf=\"field.disabled; else enabled;\">\n                        <input type='text' class=\"form-control\" [formControlName]=\"field.name\" disabled [id]=\"field.name\" >\n                        <span class=\"input-group-addon date-picker-addon\" >\n                            <i class=\"icon icon-date-picker\" aria-hidden=\"true\"></i>\n                        </span>\n                    </ng-container>\n                    <ng-template #enabled>\n                        <input type=\"text\" placeholder=\"{{field.placeHolder}}\" class=\"form-control\" bsDatepicker #dp1=\"bsDatepicker\" [bsConfig]=\"bsConfig\"\n                            [formControlName]=\"field.name\" [readonly]=\"field.readOnly\" [id]=\"field.name\"\n                            (bsValueChange)=\"bsValueChangeHandler($event)\" (onHidden)=\"setTouched()\">\n                        <span class=\"input-group-addon date-picker-addon\" (click)=\"dp1.toggle()\" id=\"ngKit-datePicker-{{field.name}}\">\n                            <i class=\"icon icon-date-picker\" aria-hidden=\"true\"></i>\n                        </span>\n                    </ng-template>\n                </div>\n                <small class=\"help-block\" *ngIf=\"field.extraText\" [innerHTML]=\"field.extraText\"></small>\n            </div>\n        </div>\n        <div class=\"row {{field.className}}\">\n            <div class=\"{{field.inputClass}}\">\n                <lib-validation-error *ngIf=\"_hasError\" [message]=\"errorMessage\" [field]=\"field.label\">\n                </lib-validation-error>\n            </div>\n        </div>\n    </div>\n</ng-container>\n\n",
        styles: [".datepicker-row{margin-left:0;margin-right:0}.date-time-picker input.form-control{background-color:#fff}.form-group.has-error .date-time-picker .input-group-addon{background-color:#b83b2f}.form-group.has-error .date-time-picker input.form-control{border-color:#b83b2f}.label-container{margin-bottom:.5em}.label-container .control-label{display:inline}"]
    }),
    __metadata("design:paramtypes", [FormBuilder, EventAggregatorService])
], DatepickerComponent);

let ValidationErrorComponent = class ValidationErrorComponent {
    constructor(tealiumdatasvc) {
        this.tealiumdatasvc = tealiumdatasvc;
        this.fieldErrors = [];
    }
    ngOnInit() {
    }
    ngOnChanges(validation) {
        if (validation && validation.message) {
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Field level Message',
                'event_type': 'Page Tag',
                'event_id': validation.message.currentValue,
                'event_value': (this.field && !this.isPII) ? this.field : top.location.href,
                'da_track': true
            });
        }
    }
};
ValidationErrorComponent.ctorParameters = () => [
    { type: TealiumDataService }
];
__decorate([
    Input(),
    __metadata("design:type", Array)
], ValidationErrorComponent.prototype, "validations", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], ValidationErrorComponent.prototype, "field", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], ValidationErrorComponent.prototype, "message", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], ValidationErrorComponent.prototype, "isPII", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], ValidationErrorComponent.prototype, "formErrors", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], ValidationErrorComponent.prototype, "fieldName", void 0);
ValidationErrorComponent = __decorate([
    Component({
        selector: 'lib-validation-error',
        template: "<div class=\"help-block with-error lib-validation-error\">\n  <span class=\"icon icon-attention alert-icon\" aria-hidden=\"true\"></span>\n  <ul class=\"list-unstyled alert-messages\">\n     <li>{{message}}</li>\n  </ul>\n</div>\n",
        styles: [".lib-validation-error{border:none;margin-top:1rem;padding:0;display:flex;margin-bottom:0}.lib-validation-error .icon{height:1em}.lib-validation-error .icon.icon-attention:before{color:#b83b2f;font-size:1em;position:relative;content:\"\\e082\"}.lib-validation-error .alert-messages{display:-webkit-inline-box;width:calc(100% - 3rem);position:relative;margin-top:-2px;margin-left:8px;margin-bottom:0}"]
    }),
    __metadata("design:paramtypes", [TealiumDataService])
], ValidationErrorComponent);

let FormGroupHighlightDirective = class FormGroupHighlightDirective {
    constructor(eventAggregatorService, el) {
        this.eventAggregatorService = eventAggregatorService;
        this.el = el;
    }
    ngAfterViewInit() {
        this.parentEl = this.el.nativeElement;
        if (this.parentEl) {
            this.inputEl = this.parentEl.querySelector('input, select, textarea, button');
            if (this.inputEl) {
                this.inputEl.addEventListener('focus', this.focusGroup.bind(this));
                this.inputEl.addEventListener('blur', this.unfocusGroup.bind(this));
            }
            this.eventEl = this.parentEl.querySelector('label');
            if (this.eventEl) {
                this.eventEl.addEventListener('click', this.handleEvent.bind(this));
            }
        }
    }
    /**
     * Handle event for the label element if there is html content in the innerHtml
     * @param event
     */
    handleEvent(event) {
        if (event && event.target && event.target.tagName.toUpperCase() === 'A') {
            event.preventDefault();
            if (this.field && this.field.labelEvent) {
                this.eventAggregatorService.broadcast(this.field.labelEvent, { event: event, field: this.field });
            }
        }
    }
    // validates input field based on their tagName
    getInputValidity(inputEl) {
        switch (inputEl.tagName.toUpperCase()) {
            case 'INPUT':
                return (inputEl.value.length === 0);
            case 'SELECT':
                return (inputEl.selectedIndex === -1 || inputEl.value !== '');
            case 'TEXTAREA':
                return (inputEl.value.length === 0);
            case 'BUTTON':
                return true;
            default:
                return false;
        }
    }
    focusGroup() {
        this.parentEl.classList.add('focused');
        // if the field as a data-min='true' it designates it as a minimum value field and it will reset when focused on.
        // ex: <input id="policyNumber" data-min='true' formControlName="policyNumber" (blur)="normalize(); validateForm()" minlength="3"/>
        // if the current value of the input is of length 0 and it's being revisited, clear the validation messages
        if (this.inputEl.dataset.min === 'true' || this.getInputValidity(this.inputEl)) {
            this.parentEl.classList.remove('ng-invalid'); // Angular error class
            this.parentEl.classList.remove('has-error'); // HIG UI Kit error class
            this.inputEl.classList.remove('ng-invalid');
            if (this.parentEl.querySelector('lib-validation-error') && !this.parentEl.querySelector('lib-validation-error')
                .classList.contains('hidden')) {
                this.parentEl.querySelector('lib-validation-error').classList.add('hidden');
            }
        }
    }
    unfocusGroup() {
        this.parentEl.classList.remove('focused');
        if (this.parentEl.querySelector('lib-validation-error')
            && this.parentEl.querySelector('lib-validation-error').classList.contains('hidden')) {
            this.parentEl.querySelector('lib-validation-error').classList.remove('hidden');
        }
        if (!this.inputEl.classList.contains('ng-valid')) {
            this.parentEl.classList.add('ng-invalid'); // Angular error class
            this.parentEl.classList.add('has-error'); // HIG UI Kit error class
            this.inputEl.classList.add('ng-invalid');
        }
    }
};
FormGroupHighlightDirective.ctorParameters = () => [
    { type: EventAggregatorService },
    { type: ElementRef }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], FormGroupHighlightDirective.prototype, "field", void 0);
FormGroupHighlightDirective = __decorate([
    Directive({
        selector: '[libFormGroupHighlight]'
    }),
    __metadata("design:paramtypes", [EventAggregatorService,
        ElementRef])
], FormGroupHighlightDirective);

var FormHelperModule_1;
let FormHelperModule = FormHelperModule_1 = class FormHelperModule {
    static forRoot() {
        return {
            ngModule: FormHelperModule_1,
            providers: [
                FormUtilitiesService
            ]
        };
    }
};
FormHelperModule = FormHelperModule_1 = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        declarations: [ValidationErrorComponent, FormGroupHighlightDirective],
        exports: [ValidationErrorComponent, FormGroupHighlightDirective],
        providers: [FormUtilitiesService],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], FormHelperModule);

let DatepickerModule = class DatepickerModule {
};
DatepickerModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule,
            ReactiveFormsModule,
            HigTooltipModule,
            FormHelperModule,
            PipesModule,
            BsDatepickerModule.forRoot(),
            TealiumModule.forRoot()
        ],
        declarations: [DatepickerComponent],
        exports: [DatepickerComponent],
        entryComponents: [DatepickerComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], DatepickerModule);

let InputComponent = 
/**
 * Use these patterns for phone number validation.
 * Copy this and put it in the the demo-dynamic.form.component.ts where you will be creating a new phoneNumber input JSON
 *
 * ^[0][1-9]\d{9}$|^[1-9]\d{9}$     -  xxxxxxxxxx
 * ((\d{3}-?)|(\d{3}-))?\d{3}-\d{4} -  xxx-xxx-xxxx
 */
class InputComponent extends FieldComponentBase {
    constructor(eventAggregatorService, tealiumdatasvc, formUtilitiesService) {
        super();
        this.eventAggregatorService = eventAggregatorService;
        this.tealiumdatasvc = tealiumdatasvc;
        this.formUtilitiesService = formUtilitiesService;
    }
    ngOnInit() {
        if (this.resetSubscription) {
            this.resetSubscription.unsubscribe();
            this.resetSubscription = null;
        }
        // Handles all the fields events
        this.resetSubscription = this.eventAggregatorService.subscribe(this.field.name + ':resetInput', (payload) => {
            this.field.checkboxSelected = false;
        });
    }
    getTypes(subType) {
        return 'text';
    }
    /**
     * conditions for input disable
     * checks for checkbox selected first and then disabled
     */
    isDisabled() {
        if (this.field.checkboxSelected) {
            return this.field.checkboxSelected;
        }
        else if (this.field.disabled) {
            return this.field.disabled;
        }
        else {
            return null;
        }
    }
    inputChacked(event) {
        let checkboxStatus;
        if (!this.currentFieldControl && this.group && this.field) {
            this.currentFieldControl = this.group.controls[this.field.name];
        }
        const control = this.group.get(this.field.name);
        control.clearValidators();
        if (event && event.currentTarget && event.currentTarget.checked) {
            checkboxStatus = 'Checked';
            this.field.checkboxSelected = true;
            if (this.field.validations && this.field.validations.length > 0) {
                control.setValidators([Validators.required]);
            }
            this.currentFieldControl.setValue(this.field.defaultValue);
        }
        else {
            checkboxStatus = 'UnChecked';
            if (this.field.validations && this.field.validations.length > 0) {
                control.setValidators(this.formUtilitiesService.bindValidations(this.field.validations, this.field));
            }
            this.field.checkboxSelected = false;
            this.currentFieldControl.setValue('');
        }
        if (this.field.isTealiumAllowed) {
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Checkbox',
                'event_id': this.field.label,
                'event_value': checkboxStatus,
                'da_track': true
            });
        }
    }
    changeHandler(event) {
        if (event && event.currentTarget) {
            this.field.value = event.currentTarget.value;
        }
        if (event && event.currentTarget && this.field.eventName) {
            this.eventAggregatorService.broadcast(this.field.eventName, { currentValue: event.currentTarget.value, formsGroup: this.group, field: this.field });
        }
        if (this.field.isTealiumAllowed) {
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Input Field Click - (text)',
                'event_id': this.field.label,
                'event_value': window.location.href,
                'da_track': true
            });
        }
    }
    getPlainTextLabel() {
        return FormUtilitiesService.getPlainTextLabel(this.field);
    }
    ngOnDestroy() {
        if (this.resetSubscription) {
            this.resetSubscription.unsubscribe();
            this.resetSubscription = null;
        }
    }
};
InputComponent.ctorParameters = () => [
    { type: EventAggregatorService },
    { type: TealiumDataService },
    { type: FormUtilitiesService }
];
__decorate([
    HostBinding('class.lib-input'),
    __metadata("design:type", Object)
], InputComponent.prototype, "true", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], InputComponent.prototype, "field", void 0);
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], InputComponent.prototype, "group", void 0);
InputComponent = __decorate([
    Component({
        selector: 'lib-input',
        template: "<div class=\"form-group {{field.className}}\" *ngIf=\"field && field.showField\" libFormGroupHighlight [field]=\"field\"\n    [ngClass]=\"{'ng-invalid has-error': hasError()}\" [formGroup]=\"group\">\n    <div class=\"row label-container\" *ngIf=\"field.label\">\n        <div class=\"{{field.labelClass}}\">\n            <ng-container *ngIf=\"field.hasHtml; else nonHtmlLabelTemRef\">\n                <div class=\"control-label\" aria-hidden=\"true\" [innerHTML]=\"field.label | safe: 'html'\"></div>\n                <label [for]=\"field.name\" class=\"sr-only\" [id]=\"field.name + 'Label'\">{{getPlainTextLabel()}}</label>\n            </ng-container>\n            <ng-template #nonHtmlLabelTemRef>\n                <label [for]=\"field.name\" class=\"control-label\" [id]=\"field.name + 'Label'\" aria-hidden=\"true\">\n                    {{field.label}}</label>\n            </ng-template>\n            <lib-tooltip placement=\"top\" *ngIf=\"field.helpText\" [id]=\"field.name + 'ToolTip'\"\n                [enableSingleTooltip]=\"true\"\n                [tealiumContent]=\"{'eventValue': field.helpText, 'tealiumTracking': field.isTealiumAllowed}\">\n                <p class=\"tooltip-content-body-text\" [innerHTML]=\"field.helpText\"></p>\n            </lib-tooltip>\n            <small class=\"help-block\" *ngIf=\"field.extraLabel\">{{field.extraLabel}}</small>\n        </div>\n    </div>\n    <div class=\"row\">\n        <div class=\"{{field.inputClass}}\">\n            <ng-container [ngSwitch]=\"field.subType\">\n                <ng-container *ngSwitchCase=\"'currency'\">\n                    <div class=\"input-group\">\n                        <span\n                            [ngClass]=\"{ disabled: field.disabled || field.checkboxSelected, 'input-group-addon': true }\">\n                            <ng-container *ngIf=\"field.icon; else dollarIcon\">\n                                {{ field.icon }}\n                            </ng-container>\n                            <ng-template #dollarIcon>\n                                <i class=\"icon icon-dollar\" aria-hidden=\"true\"></i>\n                            </ng-template>\n                        </span>\n                        <input type=\"text\" placeholder=\"{{field.placeHolder}}\" class=\"form-control\"\n                            [decimalPlaces]=\"field.decimalPlaces? field.decimalPlaces: 0\" [attr.disabled]=\"isDisabled()\"\n                            [minlength]=\"field.minLength? field.minLength: null\"\n                            [maxlength]=\"field.maxLength? field.maxLength: null\" [formControlName]=\"field.name\"\n                            data-min=\"true\" [id]=\"field.name\" title=\"{{field.title || field.placeHolder}}\"\n                            (change)=\"changeHandler($event)\" [displayCommaOnTyping]=\"field.displayCommaOnTyping\"\n                            libCurrencyInputMask [readonly]=\"field.readOnly\">\n                    </div>\n                </ng-container>\n                <ng-container *ngSwitchCase=\"'percent'\">\n                    <div class=\"input-group\">\n                        <ng-container *ngTemplateOutlet=\"numberInputTempRef\"></ng-container>\n                        <span class=\"input-group-addon\" *ngIf=\"field.subType === 'percent'\">\n                            <i class=\"icon icon-percentage\" aria-hidden=\"true\"></i>\n                        </span>\n                    </div>\n                </ng-container>\n                <ng-container *ngSwitchCase=\"'metric'\">\n                    <!-- If this field contains a custom metric, display it. Otherwise treat it as a normal numeric input -->\n                    <ng-container *ngIf=\"field.metric; else numberInput\">\n                        <div class=\"input-group\">\n                            <ng-container *ngTemplateOutlet=\"numberInputTempRef\"></ng-container>\n                            <span class=\"input-group-addon\" [ngClass]=\"{ disabled: field.disabled }\">\n                                {{ field.metric }}\n                            </span>\n                        </div>\n                    </ng-container>\n                    <ng-template #numberInput>\n                        <ng-container *ngTemplateOutlet=\"numberInputTempRef\"></ng-container>\n                    </ng-template>\n                </ng-container>\n                <ng-container *ngSwitchCase=\"'number'\">\n                    <ng-container *ngTemplateOutlet=\"numberInputTempRef\"></ng-container>\n                </ng-container>\n                <ng-container *ngSwitchCase=\"'phoneNumber'\">\n                    <ng-container *ngTemplateOutlet=\"phoneNumberInputTempRef\"></ng-container>\n                </ng-container>\n                <ng-container *ngSwitchDefault>\n                    <input placeholder=\"{{field.placeHolder}}\" [type]=\"getTypes(field.subTypes)\"\n                        class=\"form-control {{field.className}}\" [ngClass]=\"field.checkboxSelected? 'hidden': ''\"\n                        name=\"{{field.name}}\" [formControlName]=\"field.name\" [id]=\"field.name\"\n                        [minlength]=\"field.minLength? field.minLength: null\"\n                        [maxlength]=\"field.maxLength? field.maxLength: null\"\n                        title=\"{{field.title || field.placeHolder}}\" [attr.disabled]=\"isDisabled()\" data-min=\"true\"\n                        (change)=\"changeHandler($event)\" [readonly]=\"field.readOnly\">\n                    <!-- Added fake input field to show only when checkbox selected -->\n                    <label [for]=\"field.name + 'Secondary'\" class=\"hidden\" [attr.aria-hidden]=\"field.checkboxSelected\"\n                        *ngIf=\"field.checkboxLabel\">{{getPlainTextLabel()}}</label>\n                    <input placeholder=\"{{field.placeHolder}}\" [type]=\"getTypes(field.subTypes)\"\n                        class=\"form-control {{field.className}}\" [ngClass]=\"field.checkboxSelected? '': 'hidden'\"\n                        [attr.aria-hidden]=\"field.checkboxSelected\" title=\"{{field.title || field.placeHolder}}\"\n                        [attr.disabled]=\"field.checkboxSelected?field.checkboxSelected: null\"\n                        [id]=\"field.name + 'Secondary'\" *ngIf=\"field.checkboxLabel\">\n                </ng-container>\n            </ng-container>\n            <ng-template #numberInputTempRef>\n                <input type=\"text\" placeholder=\"{{field.placeHolder}}\" class=\"form-control\"\n                    [formControlName]=\"field.name\" libNumbersOnly [ngClass]=\"field.checkboxSelected? 'hidden': ''\"\n                    [attr.aria-hidden]=\"field.checkboxSelected\"\n                    [decimalPlaces]=\"field.decimalPlaces? field.decimalPlaces: 0\"\n                    [minlength]=\"field.minLength? field.minLength: null\"\n                    [maxlength]=\"field.maxLength? field.maxLength: null\" onlyNumber=\"true\" data-min=\"true\"\n                    [id]=\"field.name\" title=\"{{field.title || field.placeHolder}}\" [attr.disabled]=\"isDisabled()\"\n                    (change)=\"changeHandler($event)\" decimalPlaces=\"{{field.decimalPlaces}}\" [readonly]=\"field.readOnly\"\n                    maxValue=\"{{field.maxValue}}\">\n                <!-- Added fake input field to show only when checkbox selected -->\n                <label [for]=\"field.name + 'Secondary'\" [attr.aria-hidden]=\"field.checkboxSelected\" class=\"hidden\"\n                    [id]=\"field.name + 'Label'\" *ngIf=\"field.checkboxLabel\">{{getPlainTextLabel()}}</label>\n                <input placeholder=\"{{field.placeHolder}}\" [type]=\"getTypes(field.subTypes)\"\n                    class=\"form-control {{field.className}}\" [ngClass]=\"field.checkboxSelected? '': 'hidden'\"\n                    [id]=\"field.name + 'Secondary'\" title=\"{{field.title || field.placeHolder}}\"\n                    [attr.disabled]=\"field.checkboxSelected?field.checkboxSelected: null\" *ngIf=\"field.checkboxLabel\">\n            </ng-template>\n            <ng-template #phoneNumberInputTempRef>\n                <input type=\"tel\" title=\"{{field.title || field.placeHolder}}\" class=\"form-control\" libPhoneNumber\n                    [formControlName]=\"field.name\" [disabled]=\"field.disabled\" (change)=\"changeHandler($event)\"\n                    [unMaskedPhoneNumber]=\"field.unMaskedPhoneNumber\" [id]=\"field.name\" [readonly]=\"field.readOnly\">\n            </ng-template>\n            <small class=\"help-block\" *ngIf=\"field.extraText\" [innerHTML]=\"field.extraText\"></small>\n        </div>\n        <div *ngIf=\"field.checkboxLabel\" class=\"col-md-7 checkbox-option\">\n            <label class=\"checkbox-inline\">\n                <input type=\"checkbox\" id=\"{{field.name}}\" (change)=\"inputChacked($event)\"\n                    title=\"{{field.title || field.placeHolder}}\" [checked]=\"field.checkboxSelected\"\n                    [attr.aria-describedby]=\"field.helpText\u00A0?\u00A0field.name\u00A0+\u00A0'CheckBoxToolTip'\u00A0:\u00A0null\"\n                    value=\"{{field.defaultValue}}\">\n                <span>{{field.checkboxLabel}}</span>\n            </label>\n            <lib-tooltip placement=\"top\" *ngIf=\"field.checkboxLabelHelpText\" [id]=\"field.name + 'CheckBoxToolTip'\"\n                [enableSingleTooltip]=\"true\"\n                [tealiumContent]=\"{'eventValue': field.checkboxLabelHelpText, 'tealiumTracking': field.isTealiumAllowed}\">\n                <p class=\"tooltip-content-body-text\" [innerHTML]=\"field.checkboxLabelHelpText\"></p>\n            </lib-tooltip>\n        </div>\n    </div>\n    <div class=\"row\">\n        <div class=\"{{field.inputClass}}\">\n            <lib-validation-error *ngIf=\"_hasError\" [isPII]=\"field.isPII\" [message]=\"errorMessage\"\n                [field]=\"field.label\"></lib-validation-error>\n        </div>\n    </div>\n</div>",
        styles: [":host(.lib-input) .help-block{margin-bottom:0;margin-top:0}:host(.lib-input) .checkbox-option{margin-left:-1em;display:flex;margin-top:10px}@media (max-width:768px){:host(.lib-input) .checkbox-option{margin-left:0}}:host(.lib-input) .checkbox-inline{margin-right:0}:host(.lib-input) .disabled{border-color:#ededed}:host(.lib-input) .label-container{margin-bottom:.5em}:host(.lib-input) .label-container .control-label{display:inline}:host(.lib-input) .input-group-addon{color:#3a5a78}"]
    })
    /**
     * Use these patterns for phone number validation.
     * Copy this and put it in the the demo-dynamic.form.component.ts where you will be creating a new phoneNumber input JSON
     *
     * ^[0][1-9]\d{9}$|^[1-9]\d{9}$     -  xxxxxxxxxx
     * ((\d{3}-?)|(\d{3}-))?\d{3}-\d{4} -  xxx-xxx-xxxx
     */
    ,
    __metadata("design:paramtypes", [EventAggregatorService,
        TealiumDataService,
        FormUtilitiesService])
], InputComponent);

let NumbersOnlyDirective = class NumbersOnlyDirective {
    constructor(el) {
        this.el = el;
        // Default keys that should be allowed, including period(keyCode=190) for decimal value
        this.exceptionKeyCodes = [46, 8, 9, 27, 13, 110, 190];
        this.elemRef = el;
    }
    onKeyDown(event) {
        if (this.zipCode) {
            // Do not allow user to enter period(KeyCode = 190)
            this.exceptionKeyCodes = [46, 8, 9, 27, 13];
        }
        const e = event;
        if (this.onlyNumber) {
            if (this.exceptionKeyCodes.indexOf(e.keyCode) !== -1 ||
                // Allow: Ctrl+A, track metaKey for MAC command key
                (e.keyCode === 65 && (e.ctrlKey || e.metaKey)) ||
                // Allow: Ctrl+C, track metaKey for MAC command key
                (e.keyCode === 67 && (e.ctrlKey || e.metaKey)) ||
                // Allow: Ctrl+V, track metaKey for MAC command key
                (e.keyCode === 86 && (e.ctrlKey || e.metaKey)) ||
                // Allow: Ctrl+X, track metaKey for MAC command key
                (e.keyCode === 88 && (e.ctrlKey || e.metaKey)) ||
                // Allow: home, end, left, right
                (e.keyCode >= 35 && e.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            // Ensure that it is a number and stop the keypress
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            }
        }
    }
    onKeyPress(event) {
        const e = event;
        if (this.decimalPlaces) {
            let currentCursorPos = -1;
            if (typeof this.elemRef.nativeElement.selectionStart === 'number') {
                currentCursorPos = this.elemRef.nativeElement.selectionStart;
            }
            const dotLength = e.target.value.replace(/[^\.]/g, '').length;
            // If user has not entered a dot(.) e.target.value.split('.')[1] will be undefined
            const decimalLength = e.target.value.split('.')[1] ? e.target.value.split('.')[1].length : 0;
            // (this.DecimalPlaces - 1) because we don't get decimalLength including currently pressed character
            // currentCursorPos > e.target.value.indexOf('.') because we must allow user's to enter value before dot(.)
            // Checking Backspace etc.. keys because firefox doesn't pressing them while chrome does by default
            if (dotLength > 1 || (dotLength === 1 && e.key === '.') || (decimalLength > (parseInt(this.decimalPlaces, 10) - 1) &&
                currentCursorPos > e.target.value.indexOf('.')) && ['Backspace', 'ArrowLeft', 'ArrowRight'].indexOf(e.key) === -1) {
                e.preventDefault();
            }
        }
    }
    // Event handler for the paste
    onPaste($clipBoardevent) {
        event.preventDefault();
        if (this.zipCode) {
            this.pasteFormattedText(/[^\d]/g, $clipBoardevent);
        }
        else {
            this.pasteFormattedText(/[^\d.-]/g, $clipBoardevent);
        }
    }
    pasteFormattedText(pattern, $clipBoardevent) {
        let pastedInput;
        if (window['clipboardData']) { // IE 
            pastedInput = window['clipboardData'].getData('Text')
                .replace(pattern, '');
            document.execCommand('paste', false, pastedInput);
        }
        else {
            pastedInput = $clipBoardevent.clipboardData
                .getData('text/plain')
                .replace(pattern, '');
            document.execCommand('insertText', false, pastedInput);
        }
    }
    // Event handler for the drop
    onDrop(event) {
        event.preventDefault();
        let textData;
        if (this.zipCode) {
            textData = event.dataTransfer
                .getData('text').replace(/[^\d]/g, '');
        }
        else {
            textData = event.dataTransfer
                .getData('text').replace(/[^\d.-]/g, '');
        }
        document.execCommand('insertText', false, textData);
    }
};
NumbersOnlyDirective.ctorParameters = () => [
    { type: ElementRef }
];
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], NumbersOnlyDirective.prototype, "onlyNumber", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], NumbersOnlyDirective.prototype, "zipCode", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], NumbersOnlyDirective.prototype, "decimalPlaces", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], NumbersOnlyDirective.prototype, "minValue", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], NumbersOnlyDirective.prototype, "maxValue", void 0);
__decorate([
    HostListener('keydown', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], NumbersOnlyDirective.prototype, "onKeyDown", null);
__decorate([
    HostListener('keypress', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], NumbersOnlyDirective.prototype, "onKeyPress", null);
__decorate([
    HostListener('paste', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], NumbersOnlyDirective.prototype, "onPaste", null);
__decorate([
    HostListener('drop', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [DragEvent]),
    __metadata("design:returntype", void 0)
], NumbersOnlyDirective.prototype, "onDrop", null);
NumbersOnlyDirective = __decorate([
    Directive({
        selector: '[libNumbersOnly]'
    }),
    __metadata("design:paramtypes", [ElementRef])
], NumbersOnlyDirective);

const CURRENCY_INPUT_MASK_DIRECTIVE_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CurrencyInputMaskDirective),
    multi: true
};
let CurrencyInputMaskDirective = class CurrencyInputMaskDirective {
    constructor(elementRef, decimalPipe) {
        this.elementRef = elementRef;
        this.decimalPipe = decimalPipe;
        /**
         * decimalPlaces input field
         */
        this.decimalPlaces = 0;
        this.displayCommaOnTyping = false;
        this.DECIMAL_MARK = '.';
    }
    ngOnInit() {
        this.el = this.elementRef.nativeElement;
    }
    /**
     * Handle Focus event
     * @param event
     */
    handleFocus(event) {
        const strVal = this.getInputValue();
        const unmaskedStr = this.getUnmaskedValue(strVal);
        this.updateInputValue(unmaskedStr);
        this.displayCommaInCurrency();
    }
    /**
     * handle cut event
     * @param event
     */
    handleCut(event) {
        setTimeout(() => {
            this.inputUpdated();
        }, 0);
    }
    /**
     * handle keypress event
     * @param event
     */
    handleKeypress(event) {
        // Restrict characters
        const newChar = String.fromCharCode(event.which);
        const allowedChars = /^[\d.,]+$/;
        if (!allowedChars.test(newChar)) {
            event.preventDefault();
            return;
        }
        // Handle decimal mark input
        const currentValue = event.target.value;
        const separatorIdx = currentValue.indexOf(this.DECIMAL_MARK);
        const hasFractionalPart = (separatorIdx >= 0);
        if (!hasFractionalPart || newChar !== this.DECIMAL_MARK) {
            return;
        }
        const isOutsideSelection = !this.isIdxBetweenSelection(separatorIdx);
        if (isOutsideSelection) {
            const positionAfterMark = separatorIdx + 1;
            this.setCursorPosition(positionAfterMark);
            event.preventDefault();
            return;
        }
    }
    /**
     * handle keyup event
     * @param event
     */
    handleKeyup(event) {
        this.displayCommaInCurrency();
    }
    /**
     * show/hide commas in currency field
     */
    displayCommaInCurrency() {
        if (this.displayCommaOnTyping && this.getInputValue()) {
            const strVal = this.getInputValue();
            const unmaskedStr = this.getUnmaskedValue(strVal);
            // display comma separated currency while typing
            const commaSeparatedValue = this.transformWithPipe(unmaskedStr);
            let currentCursorPos = -1;
            if (typeof this.el.selectionStart === 'number') {
                currentCursorPos = this.el.selectionStart;
            }
            const existingCommaCount = (strVal.match(/,/g) || []).length;
            const updatedCommaCount = (commaSeparatedValue.match(/,/g) || []).length;
            const commaChanges = updatedCommaCount - existingCommaCount;
            const cursorPosition = currentCursorPos + commaChanges;
            this.updateInputValue(commaSeparatedValue);
            this.setCursorPosition(cursorPosition);
        }
    }
    /**
     * handle input event
     * @param event
     */
    handleInput(event) {
        this.inputUpdated();
    }
    /**
     * handle blur event
     * @param event
     */
    handleBlur(event) {
        const strVal = this.getInputValue();
        const numVal = this.convertStrToDecimal(strVal);
        this.maskInput(numVal);
        this.onModelTouched.apply(event);
    }
    /**
     * register callback function for change
     * @param callbackFunction
     */
    registerOnChange(callbackFunction) {
        this.onModelChange = callbackFunction;
    }
    /**
     * register callback function for touched
     * @param callbackFunction
     */
    registerOnTouched(callbackFunction) {
        this.onModelTouched = callbackFunction;
    }
    /**
     * set disable state
     * @param value
     */
    setDisabledState(value) {
        this.el.disabled = value;
    }
    /**
     * write back input value
     * @param numValue
     */
    writeValue(numValue) {
        this.maskInput(numValue);
    }
    /**
     * mask input value
     * @param numVal
     */
    maskInput(numVal) {
        if (!this.isNumeric(numVal)) {
            this.updateInputValue('');
            return;
        }
        const strVal = this.convertDecimalToStr(numVal);
        const newVal = this.transformWithPipe(strVal);
        this.updateInputValue(newVal);
    }
    /**
     * Update input value
     */
    inputUpdated() {
        this.restrictDecimalValue();
        const strVal = this.getInputValue();
        const unmaskedVal = this.getUnmaskedValue(strVal);
        const numVal = this.convertStrToDecimal(unmaskedVal);
        if (numVal !== this.lastNumVal) {
            this.lastNumVal = numVal;
            this.onModelChange(numVal);
        }
    }
    /**
     * decimal handling
     */
    restrictDecimalValue() {
        const strVal = this.getInputValue();
        const dotIdx = strVal.indexOf(this.DECIMAL_MARK);
        const hasFractionalPart = (dotIdx >= 0);
        if (hasFractionalPart) {
            const fractionalPart = strVal.substring(dotIdx + 1);
            if (fractionalPart.length > 2) {
                const choppedVal = strVal.substring(0, dotIdx + 3);
                this.updateInputValue(choppedVal, true);
                return;
            }
        }
    }
    /**
     * based on the input of decimalPlaces apply decimal formatting
     * @param str
     */
    transformWithPipe(str) {
        return this.decimalPipe.transform(str, '1.' + this.decimalPlaces + '-' + this.decimalPlaces);
    }
    /**
     * return unmasked value
     * @param value
     */
    getUnmaskedValue(value) {
        return value.replace(/[^-\d\\.]/g, '');
    }
    /**
     * Update input value
     * @param value
     * @param savePosition
     */
    updateInputValue(value, savePosition = false) {
        if (savePosition) {
            this.saveCursorPosition();
        }
        this.el.value = value;
    }
    /**
     * return input value
     */
    getInputValue() {
        return this.el.value;
    }
    /**
     * converts string to decimal
     * @param str
     */
    convertStrToDecimal(str) {
        if (str.indexOf(',') > -1) {
            str = str.replace(/,/g, '');
        }
        return (this.isNumeric(str)) ? parseFloat(str) : null;
    }
    /**
     * converts decimal to string
     * @param n
     */
    convertDecimalToStr(n) {
        return (this.isNumeric(n)) ? n + '' : '';
    }
    /**
     * check if its numeric
     * @param n
     */
    isNumeric(n) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    }
    saveCursorPosition() {
        const position = this.el.selectionStart;
        setTimeout(() => {
            this.setCursorPosition(position);
        }, 1);
    }
    /**
     * maintains cusrsor position
     * @param position
     */
    setCursorPosition(position) {
        this.el.selectionStart = position;
        this.el.selectionEnd = position;
    }
    /**
     * isIdxBetweenSelection
     * @param idx
     */
    isIdxBetweenSelection(idx) {
        if (this.el.selectionStart === this.el.selectionEnd) {
            return false;
        }
        return (idx >= this.el.selectionStart && idx < this.el.selectionEnd);
    }
};
CurrencyInputMaskDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: DecimalPipe }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], CurrencyInputMaskDirective.prototype, "decimalPlaces", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], CurrencyInputMaskDirective.prototype, "displayCommaOnTyping", void 0);
__decorate([
    HostListener('focus', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CurrencyInputMaskDirective.prototype, "handleFocus", null);
__decorate([
    HostListener('paste', ['$event']),
    HostListener('cut', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CurrencyInputMaskDirective.prototype, "handleCut", null);
__decorate([
    HostListener('keypress', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CurrencyInputMaskDirective.prototype, "handleKeypress", null);
__decorate([
    HostListener('keyup', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CurrencyInputMaskDirective.prototype, "handleKeyup", null);
__decorate([
    HostListener('input', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CurrencyInputMaskDirective.prototype, "handleInput", null);
__decorate([
    HostListener('blur', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CurrencyInputMaskDirective.prototype, "handleBlur", null);
CurrencyInputMaskDirective = __decorate([
    Directive({
        selector: '[libCurrencyInputMask]',
        providers: [
            CURRENCY_INPUT_MASK_DIRECTIVE_VALUE_ACCESSOR,
            DecimalPipe
        ]
    }),
    __metadata("design:paramtypes", [ElementRef,
        DecimalPipe])
], CurrencyInputMaskDirective);

let PhoneNumberDirective = 
// Checks to see if the value is greater than 0, a number, and not a period or a dash.
class PhoneNumberDirective {
    constructor(el, control) {
        this.el = el;
        this.control = control;
        this.maxLength = 10;
        this.unMaskedPhoneNumber = false;
    }
    ngOnInit() {
        this.el.nativeElement.placeholder = 'xxx-xxx-xxxx';
        this.el.nativeElement.pattern = new RegExp(/((\d{3}-?)|(\d{3}-))?\d{3}-\d{4}/);
        this.onInput();
    }
    onInput() {
        let value = this.el.nativeElement.value;
        if (value) {
            value = value.replace(/[^0-9]/g, '').slice(0, this.maxLength);
            this.unMaskedValue = value;
            if (value.length > 0 && value.length < 4) {
                value = value.replace(/(\d{1,3})/, '$1');
            }
            else if (value.length < 7) {
                value = value.replace(/(\d{1,3})(\d{1,3})/, '$1-$2');
            }
            else {
                value = value.replace(/(\d{1,3})(\d{1,3})(\d{0,4})/, '$1-$2-$3');
            }
        }
        if (this.control) {
            if (this.unMaskedPhoneNumber) {
                this.control.control.setValue(this.unMaskedValue);
            }
            else {
                this.control.control.setValue(value);
            }
            this.el.nativeElement.value = value;
            this.control.control.updateValueAndValidity();
        }
        else {
            this.el.nativeElement.value = value;
        }
    }
    onKeyPress(event) {
        return !(event.charCode === 46 || event.charCode === 45);
    }
    handleWindowChange(event) {
        this.onInput();
    }
};
PhoneNumberDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: NgControl, decorators: [{ type: Optional }] }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], PhoneNumberDirective.prototype, "unMaskedPhoneNumber", void 0);
__decorate([
    HostListener('input'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PhoneNumberDirective.prototype, "onInput", null);
__decorate([
    HostListener('keypress', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PhoneNumberDirective.prototype, "onKeyPress", null);
__decorate([
    HostListener('window:change', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PhoneNumberDirective.prototype, "handleWindowChange", null);
PhoneNumberDirective = __decorate([
    Directive({
        selector: '[libPhoneNumber]'
    })
    // Checks to see if the value is greater than 0, a number, and not a period or a dash.
    ,
    __param(1, Optional()),
    __metadata("design:paramtypes", [ElementRef,
        NgControl])
], PhoneNumberDirective);

let InputModule = class InputModule {
};
InputModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            HigTooltipModule,
            FormHelperModule,
            FormsModule,
            PipesModule,
            ReactiveFormsModule,
            TealiumModule.forRoot()
        ],
        declarations: [InputComponent, NumbersOnlyDirective, CurrencyInputMaskDirective, PhoneNumberDirective],
        exports: [InputComponent, NumbersOnlyDirective, CurrencyInputMaskDirective, PhoneNumberDirective],
        entryComponents: [InputComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], InputModule);

let RadioComponent = class RadioComponent extends FieldComponentBase {
    constructor(eventAggregatorService, tealiumdatasvc) {
        super();
        this.eventAggregatorService = eventAggregatorService;
        this.tealiumdatasvc = tealiumdatasvc;
        this.hideOptions = true;
    }
    selectHandler() {
        this.field.value = this.group.get(this.field.name).value;
        if (this.field.eventName) {
            this.eventAggregatorService.broadcast(this.field.eventName, { selectedOption: this.field.value, formsGroup: this.group, field: this.field });
        }
        if (this.field.isTealiumAllowed) {
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Radio Button',
                'event_id': this.field.label,
                'event_value': this.field.value,
                'da_track': true
            });
        }
    }
    getPlainTextLabel() {
        return FormUtilitiesService.getPlainTextLabel(this.field);
    }
    toggleHideOptions(event) {
        event.preventDefault();
        this.hideOptions = !this.hideOptions;
        if (this.field.isTealiumAllowed) {
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Link Click',
                'event_id': this.hideOptions ? this.field.showLessText : this.field.showMoreText,
                'event_value': this.field.label,
                'da_track': true
            });
        }
    }
};
RadioComponent.ctorParameters = () => [
    { type: EventAggregatorService },
    { type: TealiumDataService }
];
__decorate([
    HostBinding('class.lib-radio'),
    __metadata("design:type", Object)
], RadioComponent.prototype, "true", void 0);
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], RadioComponent.prototype, "group", void 0);
RadioComponent = __decorate([
    Component({
        selector: 'lib-radio',
        template: "<div class=\"form-group\"\n   *ngIf=\"field && field.showField\"\n  libFormGroupHighlight [field]=\"field\" [ngClass]=\"{'ng-invalid has-error': hasError(), 'tile-selectors': field.subType === 'tile'}\" [formGroup]=\"group\">\n  <div class=\"row label-container\" *ngIf=\"field.label\">\n    <div class=\"{{field.labelClass}} radio-label\" [ngClass]=\"{'extra-label': field.extraLabel && field.extraLabel !== '' }\">\n      <ng-container *ngIf=\"field.hasHtml; else nonHtmlLabelTemRef\">\n        <div class=\"control-label\" aria-hidden=\"true\" [innerHTML]=\"field.label | safe: 'html'\"></div>\n        <label [for]=\"field.name\" class=\"sr-only\" [id]=\"'ngKit-radio-' + field.name + 'Label'\">{{getPlainTextLabel()}}</label>\n      </ng-container>\n      <ng-template #nonHtmlLabelTemRef>\n        <label [for]=\"field.name\" class=\"control-label\" [id]=\"'ngKit-radio-' + field.name + 'Label'\" aria-hidden=\"true\">\n          {{field.label}}</label>\n      </ng-template>\n      <lib-tooltip placement=\"top\" *ngIf=\"field.helpText\" [enableSingleTooltip]=\"true\" [id]=\"'ngKit-radio-' + field.name + 'ToolTip'\"\n      [tealiumContent]=\"{'eventValue': field.helpText, 'tealiumTracking': field.isTealiumAllowed}\">\n        <p class=\"tooltip-content-body-text\" [innerHTML]=\"field.helpText\"></p>\n      </lib-tooltip>\n      <small class=\"help-block\" *ngIf=\"field.extraLabel\">{{field.extraLabel}}</small>\n    </div>\n  </div>\n  <div class=\"row\">\n      <div class=\"col-xs-12\">\n        <ng-container [ngSwitch]=\"field.subType\">\n            <ng-container *ngSwitchCase=\"'vertical'\">\n                <ng-container *ngTemplateOutlet=\"radioVTempRef\"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'tile'\">\n                <ng-container *ngTemplateOutlet=\"radioTileTempRef\"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"'tileV2'\">\n              <ng-container *ngTemplateOutlet=\"radioTileVersion2TempRef\"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchDefault>\n                <ng-container *ngTemplateOutlet=\"radioHTempRef\"></ng-container>\n            </ng-container>\n        </ng-container>\n        <small class=\"help-block\" *ngIf=\"field.extraText\" [innerHTML]=\"field.extraText\"></small>\n      </div>\n  </div>\n  <lib-validation-error *ngIf=\"_hasError\"  [message]=\"errorMessage\" [isPII]=\"field.isPII\" [field] = \"field.label\"></lib-validation-error>\n  <!-- template for the vertical radio -->\n  <ng-template #radioVTempRef>\n    <div class=\"radio\" *ngFor=\"let option of field.options; let i = index\"\n      [ngStyle]=\"{'display': hideOptions && field.showMoreLessAfterIndex && i > field.showMoreLessAfterIndex ? 'none' : '' }\">\n        <label class=\"radio-inline\" [attr.disabled]=\"field.disabled?field.disabled: null\" [id]=\"'ngKit-radio-' + field.name + 'Vertical' + i\">\n          <input type=\"radio\" value=\"{{option.value}}\" name=\"{{field.name}}\" [formControlName]=\"field.name\" required\n           class=\"form-control\" [attr.disabled]=\"field.disabled?field.disabled: null\" \n            (change)=\"selectHandler()\">\n            <!-- custom template to show as label -->\n           <ng-container *ngIf=\"option.template; else nonHtmlOption\">\n             <span>\n              <ng-container  *ngTemplateOutlet=\"option.template;context:{option: option}\">\n              </ng-container>\n            </span>\n           </ng-container>\n          <ng-template #nonHtmlOption>\n            <span>\n                {{option.label}}\n            </span>\n          </ng-template>\n        </label>\n        <small class=\"help-block option-help-block\" *ngIf=\"option.extraText\" [innerHTML]=\"option.extraText\"></small>\n    </div>\n    <div *ngIf=\"field.showMoreLessAfterIndex && field.options.length - 1 > field.showMoreLessAfterIndex\" class=\"show-more-container\">\n      <a (click)=\"toggleHideOptions($event)\" href=\"#\" id=\"ngKit-radio-show-more-Link-{{field.name}}\">\n        {{hideOptions ? field.showMoreText : field.showLessText}}\n      </a>\n    </div>\n  </ng-template>\n  <!-- template for the horizontal radio -->\n  <ng-template #radioHTempRef>\n    <div>\n      <label class=\"radio-inline\" *ngFor=\"let option of field.options; let i = index\" [attr.disabled]=\"field.disabled?field.disabled: null\"\n             id=\"ngKit-horizontal-radio-{{field.name}}-{{i}}\">\n        <input type=\"radio\" value=\"{{option.value}}\" name=\"{{field.name}}\" [formControlName]=\"field.name\"\n        class=\"form-control\" [attr.disabled]=\"field.disabled?field.disabled: null\"\n          (change)=\"selectHandler()\">\n          <span>\n              {{option.label}}\n          </span>\n      </label>\n    </div>\n  </ng-template>\n  <!-- template for the tile radio -->\n  <ng-template #radioTileTempRef>\n    <div class=\"row\">\n        <div class=\"radio col-sm-{{field.customColWidth ? field.customColWidth : 4}}\" *ngFor=\"let option of field.options; let i = index\">\n          <label [ngClass]=\"{'radio-active': option.value === field.value, 'input-disabled': field.disabled}\" [attr.disabled]=\"field.disabled?field.disabled: null\" id=\"ngKit-tile-radio-{{field.name}}-{{i}}\">\n            <input type=\"radio\" value=\"{{option.value}}\" name=\"{{field.name}}\"\n             [formControlName]=\"field.name\" class=\"form-control\"\n             [attr.disabled]=\"field.disabled?field.disabled: null\"\n              (change)=\"selectHandler()\">\n            <span>\n              <ng-container *ngIf=\"option.icon\">\n                <i class=\"icon icon-2x hidden-xs\" [ngClass]=\"option.icon\" aria-hidden=\"true\"></i>\n                <br class=\"hidden-xs\">\n              </ng-container>\n              {{option.label}}\n            </span>\n          </label>\n        </div>\n      </div>\n  </ng-template>\n  <!-- template for the tile radio version 2-->\n  <ng-template #radioTileVersion2TempRef>\n    <div class=\"row tile-click-radio form-group\">\n      <div class=\"col-sm-{{field.customColWidth ? field.customColWidth : 4}}\" *ngFor=\"let option of field.options; let i = index\">\n        <label class=\"radio-inline card offset\" [ngClass]=\"{'tile-radio-active': option.value === field.value,\n        'input-disabled': field.disabled}\" [attr.disabled]=\"field.disabled?field.disabled: null\"\n        id=\"ngKit-radio-version2-{{i}}\">\n          <input type=\"radio\" value=\"{{option.value}}\" name=\"{{field.name}}\" [formControlName]=\"field.name\"\n            class=\"form-control\" [attr.disabled]=\"field.disabled?field.disabled: null\" (change)=\"selectHandler()\">\n          {{option.label}}\n          <span class=\"info-tile-selected\"></span>\n        </label>\n      </div>\n    </div>\n  </ng-template>\n</div>\n",
        styles: [":host(.lib-radio) .radio-label label{margin-right:5px}:host(.lib-radio) .radio-label .help-block{margin-bottom:0}:host(.lib-radio) .extra-label{margin-bottom:10px}:host(.lib-radio) .option-help-block{margin-left:2.3em;margin-top:-8px;margin-bottom:15px}:host(.lib-radio) .label-container{margin-bottom:.5em}:host(.lib-radio) .label-container .control-label{display:inline}:host(.lib-radio) .show-more-container a{cursor:pointer}"]
    }),
    __metadata("design:paramtypes", [EventAggregatorService,
        TealiumDataService])
], RadioComponent);

let RadioModule = class RadioModule {
};
RadioModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule,
            ReactiveFormsModule,
            FormHelperModule,
            PipesModule,
            HigTooltipModule
        ],
        declarations: [RadioComponent],
        exports: [RadioComponent],
        entryComponents: [RadioComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], RadioModule);

let CheckboxComponent = class CheckboxComponent extends FieldComponentBase {
    constructor(eventAggregatorService, tealiumdatasvc) {
        super();
        this.eventAggregatorService = eventAggregatorService;
        this.tealiumdatasvc = tealiumdatasvc;
        this.formArray = [];
    }
    /**
     * creating formArray of controls if there are multiple options for checkboxes
     */
    ngOnInit() {
        if (this.field.options.length > 1) {
            this.field.options.forEach(option => {
                const control = new FormControl(option.checked, Validators.required);
                this.formArray.push(control);
            });
            this.group.setControl(this.field.name, new FormArray(this.formArray, this.minSelectedCheckboxes()));
        }
    }
    selectHandler(option) {
        if (option && this.field) {
            if (option.checked) {
                this.selectedOption = option.value;
                this.checkboxStatus = 'Checked';
            }
            else {
                this.selectedOption = '';
                this.checkboxStatus = 'Unchecked';
            }
            this.eventAggregatorService.broadcast(this.field.eventName, { selectedOption: this.selectedOption, formsGroup: this.group, field: this.field });
        }
        if (this.field.isTealiumAllowed) {
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Checkbox',
                'event_id': option.label,
                'event_value': this.checkboxStatus,
                'da_track': true
            });
        }
    }
    /**
     * This gets invoked only if there are multiple options
     * It loops through all the controls of formArray and checks
     * if at least one check box is selected.
     */
    minSelectedCheckboxes() {
        const validator = (formArray) => {
            const totalSelected = formArray.controls
                .map(control => control.value)
                .reduce((prev, next) => next ? prev + next : prev, 0);
            return totalSelected >= 1 ? null : { required: true };
        };
        return validator;
    }
};
CheckboxComponent.ctorParameters = () => [
    { type: EventAggregatorService },
    { type: TealiumDataService }
];
__decorate([
    HostBinding('class.lib-checkbox'),
    __metadata("design:type", Object)
], CheckboxComponent.prototype, "true", void 0);
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], CheckboxComponent.prototype, "group", void 0);
CheckboxComponent = __decorate([
    Component({
        selector: 'lib-checkbox',
        template: "<div class=\"form-group {{field.className}}\"\n     *ngIf=\"field && field.showField\"\n     libFormGroupHighlight [ngClass]=\"{'ng-invalid has-error': hasError(), 'tile-selectors': field.subType === 'tile'}\"\n     [formGroup]=\"group\" [field]=\"field\">\n    <div class=\"row label-container\" *ngIf=\"field.label\">\n        <div class=\"{{field.labelClass}} label-block\">\n            <label class=\"control-label\" *ngIf=\"field.label\">{{field.label}}</label>\n            <lib-tooltip placement=\"top\" *ngIf=\"field.helpText\" [enableSingleTooltip]=\"true\" [tealiumContent] = \"{'eventValue': field.helpText, 'tealiumTracking': field.isTealiumAllowed}\">\n                <p class=\"tooltip-content-body-text\" [innerHTML]=\"field.helpText\"></p>\n            </lib-tooltip>\n        </div>\n    </div>\n    <div class=\"row\">\n        <div class=\"col-xs-12\">\n            <small class=\"help-block\" *ngIf=\"field.extraLabel\">{{field.extraLabel}}</small>\n            <ng-container [ngSwitch]=\"field.subType\">\n                <ng-container *ngSwitchCase=\"'vertical'\">\n                    <ng-container *ngTemplateOutlet=\"checkboxVTempRef\"></ng-container>\n                </ng-container>\n                <ng-container *ngSwitchCase=\"'tile'\">\n                    <ng-container *ngTemplateOutlet=\"checkboxTileTempRef\"></ng-container>\n                </ng-container>\n                <ng-container *ngSwitchDefault>\n                    <ng-container *ngTemplateOutlet=\"checkboxHTempRef\"></ng-container>\n                </ng-container>\n            </ng-container>\n            <small class=\"help-block\" *ngIf=\"field.extraText\" [innerHTML]=\"field.extraText\"></small>\n        </div>\n    </div>\n    <lib-validation-error *ngIf=\"_hasError && errorMessage\" [isPII]=\"field.isPII\" [message]=\"errorMessage\"></lib-validation-error>\n    <!-- template for the vertical checkbox -->\n    <ng-template #checkboxVTempRef>\n        <div class=\"checkbox\" *ngFor=\"let option of field.options; let i = index\">\n            <label class=\"checkbox-inline\" [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\" [formArrayName]=\"field.name\"\n                   *ngIf=\"field.options.length > 1\" [ngClass]=\"{'option-tooltip': option.helpText,'checkbox-inline-alt': field.isCheckboxAlt}\" id=\"ngKit-checkbox-{{field.name}}-{{i}}\">\n                <input type=\"checkbox\" value=\"{{option.value}}\" name=\"{{field.name}}\" [formControlName]=\"i\"\n                       [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\"\n                       class=\"form-control\" [checked]=\"option.checked\" (change)=\"option.checked= !option.checked; selectHandler(option);\">\n                <span>\n                    {{option.label}}\n                </span>\n            </label>\n            <label class=\"checkbox-inline\" \n            [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\" *ngIf=\"field.options.length === 1\"\n                   [ngClass]=\"{'option-tooltip': option.helpText , 'checkbox-inline-alt': field.isCheckboxAlt}\" id=\"ngKit-checkbox-{{field.name}}\">\n                <input type=\"checkbox\" value=\"{{option.value}}\" name=\"{{field.name}}\" [formControlName]=\"field.name\"\n                       [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\"\n                       class=\"form-control\" [checked]=\"option.checked\" (change)=\"option.checked= !option.checked; selectHandler(option);\">\n                <span>\n                    {{option.label}}\n                </span>\n            </label>\n          <lib-tooltip placement=\"top\" *ngIf=\"option.helpText\" [enableSingleTooltip]=\"true\" [tealiumContent] = \"{'eventValue': option.helpText, 'tealiumTracking': field.isTealiumAllowed}\">\n            <p class=\"tooltip-content-body-text\"  [innerHTML]=\"option.helpText\"></p>\n          </lib-tooltip>\n          <small class=\"help-block option-help-block\" *ngIf=\"option.extraText\" [innerHTML]=\"option.extraText\"></small>\n        </div>\n    </ng-template>\n    <!-- template for the horizontal checkbox -->\n    <ng-template #checkboxHTempRef>\n        <div *ngIf=\"field.options.length > 1\">\n            <ng-container *ngFor=\"let option of field.options; let i = index\">\n                <label class=\"checkbox-inline\" [ngClass]=\"{'checkbox-inline-alt': field.isCheckboxAlt}\" [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\"\n                    [formArrayName]=\"field.name\" id=\"ngKit-horizontal-checkbox-{{field.name}}-{{i}}\">\n                    <input type=\"checkbox\" value=\"{{option.value}}\" name=\"{{field.name}}\" [formControlName]=\"i\"\n                        class=\"form-control\" [checked]=\"option.checked\"\n                        [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\"\n                        (change)=\"option.checked=!option.checked; selectHandler(option);\">\n                    <span>\n                    {{option.label}}\n                    </span>\n                </label>\n                <small class=\"help-block option-help-block\" *ngIf=\"option.extraText\" [innerHTML]=\"option.extraText\"></small>\n            </ng-container>\n        </div>\n        <div *ngIf=\"field.options.length === 1\">\n            <ng-container *ngFor=\"let option of field.options\">\n                <label class=\"checkbox-inline\" [ngClass]=\"{'checkbox-inline-alt': field.isCheckboxAlt}\" [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\"\n                id=\"ngKit-single-checkbox-{{field.name}}\">\n                    <input type=\"checkbox\" value=\"{{option.value}}\" name=\"{{field.name}}\" [formControlName]=\"field.name\"\n                        class=\"form-control\" [checked]=\"option.checked\"\n                        [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\"\n                        (change)=\"option.checked=!option.checked; selectHandler(option);\">\n                    <span>\n                    {{option.label}}\n                    </span>\n                </label>\n                <small class=\"help-block option-help-block\" *ngIf=\"option.extraText\" [innerHTML]=\"option.extraText\"></small>\n            </ng-container>\n        </div>\n    </ng-template>\n    <!-- template for the tile checkbox -->\n    <ng-template #checkboxTileTempRef>\n        <div class=\"row\">\n            <div class=\"checkbox col-sm-4 col-md-3\" *ngFor=\"let option of field.options; let i = index\">\n                <label [ngClass]=\"{'checkbox-active': option.checked, 'input-disabled': field.disabled}\"\n                       [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\" [formArrayName]=\"field.name\" id=\"ngKit-tile-checkbox-{{field.name}}-{{i}}\">\n                    <input type=\"checkbox\" [value]=\"option.value\" name=\"{{field.name}}\"\n                           [attr.disabled]=\"(field.disabled || option.disabled)?(field.disabled || option.disabled): null\"\n                           [formControlName]=\"i\" [checked]=\"option.checked\"\n                           (change)=\"option.checked= !option.checked; selectHandler(option);\">\n                    <span>\n                        <ng-container *ngIf=\"option.icon\">\n                            <i class=\"icon icon-2x hidden-xs\" [ngClass]=\"option.icon\"  aria-hidden=\"true\"></i>\n                            <br class=\"hidden-xs\">\n                        </ng-container>\n                        {{option.label}}\n                    </span>\n                </label>\n            </div>\n        </div>\n    </ng-template>\n</div>\n",
        styles: [":host(.lib-checkbox) .label-block label{margin-right:5px}:host(.lib-checkbox) .label-block .help-block{margin-bottom:0;margin-top:0}:host(.lib-checkbox) .checkbox .checkbox-inline{margin-right:0}:host(.lib-checkbox) .option-tooltip{display:inline}:host(.lib-checkbox) .option-help-block{margin-left:2.3em;margin-top:0}:host(.lib-checkbox) .label-container{margin-bottom:.5em}:host(.lib-checkbox) .label-container .control-label{display:inline}.checkbox{margin-top:0}.form-group.has-error label.checkbox-inline [type=checkbox]~::before{color:#b83b2f}"]
    }),
    __metadata("design:paramtypes", [EventAggregatorService,
        TealiumDataService])
], CheckboxComponent);

let CheckboxModule = class CheckboxModule {
};
CheckboxModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule,
            ReactiveFormsModule,
            FormHelperModule,
            PipesModule,
            HigTooltipModule
        ],
        declarations: [CheckboxComponent],
        exports: [CheckboxComponent],
        entryComponents: [CheckboxComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], CheckboxModule);

let SelectComponent = class SelectComponent extends FieldComponentBase {
    constructor(eventAggregatorService, tealiumdatasvc) {
        super();
        this.eventAggregatorService = eventAggregatorService;
        this.tealiumdatasvc = tealiumdatasvc;
    }
    selectHandler() {
        this.field.value = this.group.get(this.field.name).value;
        if (this.field.eventName) {
            this.eventAggregatorService.broadcast(this.field.eventName, { selectedOption: this.field.value, formsGroup: this.group, field: this.field });
        }
        if (this.field.isTealiumAllowed) {
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Select Click - (select-one)',
                'event_id': this.field.label,
                // If it is PII field, then don't track the value
                'event_value': this.field.isPii ? top.location.href : this.field.value,
                'da_track': true
            });
        }
    }
    getPlainTextLabel() {
        return FormUtilitiesService.getPlainTextLabel(this.field);
    }
};
SelectComponent.ctorParameters = () => [
    { type: EventAggregatorService },
    { type: TealiumDataService }
];
SelectComponent = __decorate([
    Component({
        selector: 'lib-select',
        template: "<div class=\"form-group\" *ngIf=\"field && field.showField\" libFormGroupHighlight [field]=\"field\" \n    [ngClass]=\"{'ng-invalid has-error': hasError()}\" [formGroup]=\"group\">\n    <div class=\"row label-container\" *ngIf=\"field.label\">\n        <div class=\"{{field.labelClass}}\">\n            <ng-container *ngIf=\"field.hasHtml; else nonHtmlLabelTemRef\">\n                <div class=\"control-label\" aria-hidden=\"true\" [innerHTML]=\"field.label | safe: 'html'\"></div>\n                <label [for]=\"field.name\" class=\"sr-only\" [id]=\"field.name + 'Label'\">{{getPlainTextLabel()}}</label>\n            </ng-container>\n            <ng-template #nonHtmlLabelTemRef>\n                <label [for]=\"field.name\" class=\"control-label\" [id]=\"field.name + 'Label'\" aria-hidden=\"true\">\n                    {{field.label}}</label>\n            </ng-template>\n            <lib-tooltip placement=\"top\" *ngIf=\"field.helpText\" [id]=\"field.name + 'ToolTip'\" [enableSingleTooltip]=\"true\" [tealiumContent]=\"{'eventValue': field.helpText, 'tealiumTracking': field.isTealiumAllowed}\">\n                <p class=\"tooltip-content-body-text\" [innerHTML]=\"field.helpText\"></p>\n            </lib-tooltip>\n            <small class=\"help-block\" *ngIf=\"field.extraLabel\">{{field.extraLabel}}</small>\n        </div>\n    </div>\n    <div class=\"row\">\n        <div class=\"{{field.className}}\">\n            <div class=\"hig-select-container select-container\">\n                <select class=\"form-control\" (change)=\"selectHandler()\" [formControlName]=\"field.name\"\n                    [attr.data-dl]='field.dataDl' [id]=\"field.name\" [attr.disabled]=\"field.disabled?field.disabled: null\">\n                    <option [ngValue]=\"null\" selected=\"selected\" hidden></option>\n                    <option [ngValue]=\"item.value\" *ngFor=\"let item of field.options; let i = index\" id=\"ngKit-select-{{field.name}}-{{i}}\">{{item.label}}</option>\n                </select>\n                <lib-validation-error *ngIf=\"_hasError\" [isPII]=\"field.isPII\" [message]=\"errorMessage\" [field]=\"field.label\">\n                </lib-validation-error>\n            </div>\n            <small class=\"help-block\" *ngIf=\"field.extraText\" [innerHTML]=\"field.extraText\"></small>\n        </div>\n    </div>\n</div>\n",
        styles: [".hig-select-container{margin-bottom:0}.label-container{margin-bottom:.5em}.label-container .control-label{display:inline}"]
    }),
    __metadata("design:paramtypes", [EventAggregatorService,
        TealiumDataService])
], SelectComponent);

let SelectModule = class SelectModule {
};
SelectModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule,
            ReactiveFormsModule,
            FormHelperModule,
            HigTooltipModule,
            PipesModule
        ],
        declarations: [SelectComponent],
        exports: [SelectComponent],
        entryComponents: [SelectComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], SelectModule);

let TextareaComponent = class TextareaComponent extends FieldComponentBase {
    constructor(eventAggregatorService, tealiumdatasvc) {
        super();
        this.eventAggregatorService = eventAggregatorService;
        this.tealiumdatasvc = tealiumdatasvc;
        this._hasError = false;
    }
    ngOnInit() {
    }
    contentChangeHandler(event) {
        if (event && event.currentTarget) {
            this.field.value = event.currentTarget.value;
        }
        if (this.field.eventName) {
            this.eventAggregatorService.broadcast(this.field.eventName, { selectedOption: this.field.value, formsGroup: this.group, field: this.field });
        }
        if (this.field.isTealiumAllowed) {
            let ei = this.field.value;
            if (this.field.label) {
                ei = this.field.label;
            }
            this.tealiumdatasvc.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Textbox',
                'event_id': ei,
                'event_value': window.location.href,
                'da_track': true
            });
        }
    }
    getPlainTextLabel() {
        return FormUtilitiesService.getPlainTextLabel(this.field);
    }
};
TextareaComponent.ctorParameters = () => [
    { type: EventAggregatorService },
    { type: TealiumDataService }
];
TextareaComponent = __decorate([
    Component({
        selector: 'lib-textarea',
        template: "<div class=\"form-group {{field.className}}\" id=\"{{field.name}}\" *ngIf=\"field && field.showField\" libFormGroupHighlight [field]=\"field\"\n    [ngClass]=\"{'ng-invalid has-error': hasError()}\" [formGroup]=\"group\">\n    <div class=\"row label-container\" *ngIf=\"field.label\">\n        <div class=\"{{field.labelClass}}\">\n            <ng-container *ngIf=\"field.hasHtml; else nonHtmlLabelTemRef\">\n                <div class=\"control-label\" aria-hidden=\"true\" [innerHTML]=\"field.label | safe: 'html'\"></div>\n                <label [for]=\"field.name\" class=\"sr-only\" [id]=\"field.name + 'Label'\">{{getPlainTextLabel()}}</label>\n            </ng-container>\n            <ng-template #nonHtmlLabelTemRef>\n                <label [for]=\"field.name\" class=\"control-label\" [id]=\"field.name + 'Label'\" aria-hidden=\"true\">\n                    {{field.label}}</label>\n            </ng-template>\n            <lib-tooltip placement=\"top\" *ngIf=\"field.helpText\" [enableSingleTooltip]=\"true\" [id]=\"field.name\u00A0+\u00A0'Tooltip'\"\n                         [tealiumContent] = \"{'eventValue': field.helpText, 'tealiumTracking': field.isTealiumAllowed}\">\n              <p class=\"tooltip-content-body-text\" [innerHTML]=\"field.helpText\"></p>\n            </lib-tooltip>\n            <small class=\"help-block\" *ngIf=\"field.extraLabel\">{{field.extraLabel}}</small>\n        </div>\n    </div>\n    <div class=\"row\">\n       <div class=\"{{field.inputClass}}\">\n           <textarea class=\"form-control gbx-unmasked\" #textAreaTempRef [formControlName]=\"field.name\" maxlength=\"{{field.maxLength}}\"\n               (change)=\"contentChangeHandler($event)\" [id]=\"field.name + 'Textarea'\"\n               [value]=\"field.value && field.value.length<=field.maxLength? field.value: ''\">\n            </textarea>\n           <small class=\"textarea-character-limit\" *ngIf=\"field.extraText\">\n               {{ field.maxLength - textAreaTempRef.value.length }} {{field.extraText}}\n            </small>\n       </div>\n    </div>\n    <div class=\"row\">\n        <div class=\"{{field.inputClass}}\">\n            <lib-validation-error *ngIf=\"_hasError\" [message]=\"errorMessage\" [field]=\"field.label\"></lib-validation-error>\n        </div>\n    </div>\n</div>\n",
        styles: [".label-container{margin-bottom:.5em}.label-container .control-label{display:inline}"]
    }),
    __metadata("design:paramtypes", [EventAggregatorService,
        TealiumDataService])
], TextareaComponent);

let TextareaModule = class TextareaModule {
};
TextareaModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            HigTooltipModule,
            FormHelperModule,
            FormsModule,
            ReactiveFormsModule,
            PipesModule
        ],
        declarations: [TextareaComponent],
        exports: [TextareaComponent],
        entryComponents: [TextareaComponent]
    })
], TextareaModule);

let ToggleButtonComponent = class ToggleButtonComponent extends FieldComponentBase {
    constructor(eventAggregatorService, tealiumdatasvc) {
        super();
        this.eventAggregatorService = eventAggregatorService;
        this.tealiumdatasvc = tealiumdatasvc;
    }
    ngOnInit() {
    }
    onClickBtn(option, event) {
        if (event) {
            /**
             * added below line to prevent from triggering multiple events
             */
            event.preventDefault();
        }
        if (option) {
            if (option.value) {
                this.field.value = option.value;
                this.group.get(this.field.name).setValue(this.field.value);
            }
            if (this.field.eventName) {
                this.eventAggregatorService.broadcast(this.field.eventName, { field: this.field, selectedOption: option.value });
            }
            if (this.field.isTealiumAllowed) {
                this.tealiumdatasvc.addImpressionEvent({
                    'event_parent': 'Page Tag',
                    'event_type': 'Button Click',
                    'event_id': option.label,
                    'event_value': this.field.label,
                    'da_track': true
                });
            }
        }
    }
    getPlainTextLabel() {
        return FormUtilitiesService.getPlainTextLabel(this.field);
    }
};
ToggleButtonComponent.ctorParameters = () => [
    { type: EventAggregatorService },
    { type: TealiumDataService }
];
__decorate([
    HostBinding('class.lib-toggle-button'),
    __metadata("design:type", Object)
], ToggleButtonComponent.prototype, "true", void 0);
ToggleButtonComponent = __decorate([
    Component({
        selector: 'lib-toggle-button',
        template: "<div class=\"form-group {{field.className}}\" id=\"ngKit-toggle-button-{{field.name}}\" *ngIf=\"field && field.showField\" libFormGroupHighlight\n[field]=\"field\" [ngClass]=\"{'ng-invalid has-error': hasError()}\" [formGroup]=\"group\">\n  <!-- Label row -->\n  <div class=\"row label-container\">\n    <div class=\"{{field.labelClass}}\">\n      <ng-container *ngIf=\"field.hasHtml; else nonHtmlLabelTemRef\">\n          <div class=\"control-label\" aria-hidden=\"true\" [innerHTML]=\"field.label | safe: 'html'\"></div>\n          <label [for]=\"field.name\" class=\"sr-only\" [id]=\"'ngKit-toggle-button-' + field.name + 'Tooltip'\">{{getPlainTextLabel()}}</label>\n      </ng-container>\n      <ng-template #nonHtmlLabelTemRef>\n          <label [for]=\"field.name\" class=\"control-label\" [id]=\"'ngKit-toggle-button-' + field.name + 'Tooltip'\" aria-hidden=\"true\"\n          [attr.aria-describedby]=\"field.helpText\u00A0?\u00A0field.name\u00A0+\u00A0'ToolTip'\u00A0:\u00A0null\">\n              {{field.label}}</label>\n      </ng-template>\n      <lib-tooltip placement=\"top\" *ngIf=\"field.helpText\" [enableSingleTooltip]=\"true\" [id]=\"'ngKit-toggle-button-' + field.name\u00A0+\u00A0'Tooltip'\"\n                   [tealiumContent] = \"{'eventValue': field.helpText, 'tealiumTracking': field.isTealiumAllowed}\"> \n        <p class=\"tooltip-content-body-text\" [innerHTML]=\"field.helpText\"></p>\n      </lib-tooltip>\n      <small class=\"help-block\" *ngIf=\"field.extraLabel\">{{field.extraLabel}}</small>\n    </div>\n  </div>\n  <!-- toggle button field row -->\n  <div class=\"row\">\n    <div class=\"{{field.inputClass}}\">\n      <div class=\"btn-group btn-group-toggle\" data-toggle=\"buttons\">\n        <ng-container *ngFor=\"let btn of field.buttons; let i = index\">\n          <label class=\"btn btn-secondary\" (click)=\"onClickBtn(btn, $event)\" (keydown.enter)=\"onClickBtn(btn, $event)\"\n            [ngClass]=\"{'active': group.get(field.name)?.value === btn.value}\" tabindex=\"0\"\n            id=\"ngKit-toggle-button-{{field.name}}-{{i}}\">\n            <input type=\"radio\" name=\"{{field.name}}\"\n              value=\"{{btn.value}}\" formControlName=\"{{field.name}}\" tabindex=\"-1\">\n            {{btn.label}}\n          </label>\n        </ng-container>\n      </div>\n      <small class=\"help-block\" *ngIf=\"field.extraText\" [innerHTML]=\"field.extraText\"></small>\n    </div>\n  </div>\n  <div class=\"row\">\n      <div class=\"{{field.inputClass}}\">\n          <lib-validation-error *ngIf=\"_hasError\" [isPII]=\"field.isPII\"  [message]=\"errorMessage\" [field] = \"field.label\"></lib-validation-error>\n      </div>\n  </div>\n</div>\n",
        styles: [":host(.lib-toggle-button) .form-group.has-error .btn-group.btn-group-toggle label{border-color:#b83b2f;color:#b83b2f}:host(.lib-toggle-button) .label-container{margin-bottom:.5em}:host(.lib-toggle-button) .label-container .control-label{display:inline}"]
    }),
    __metadata("design:paramtypes", [EventAggregatorService,
        TealiumDataService])
], ToggleButtonComponent);

let ToggleButtonModule = class ToggleButtonModule {
};
ToggleButtonModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule,
            ReactiveFormsModule,
            HigTooltipModule,
            FormHelperModule,
            PipesModule
        ],
        declarations: [ToggleButtonComponent],
        exports: [ToggleButtonComponent],
        entryComponents: [ToggleButtonComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], ToggleButtonModule);

let ButtonComponent = class ButtonComponent extends FieldComponentBase {
    constructor(eventAggregatorService) {
        super();
        this.eventAggregatorService = eventAggregatorService;
    }
    ngOnInit() {
    }
    /**
     * onClickBtn should broadcast event if field config has eventName
     */
    onClickBtn() {
        if (this.field && this.field.eventName) {
            this.eventAggregatorService.broadcast(this.field.eventName, { formsGroup: this.group, field: this.field });
        }
    }
};
ButtonComponent.ctorParameters = () => [
    { type: EventAggregatorService }
];
ButtonComponent = __decorate([
    Component({
        selector: 'lib-button',
        template: "<div class=\"row form-group\" *ngIf=\"field && field.showField\">\n  <div class=\"{{field.className}}\">\n      <button class=\"btn {{field.btnClass}} btn-block\" (click)=\"onClickBtn()\"\n              id=\"{{field.id ? field.id : 'ngKit-button-' + field.name}}\">\n          <i *ngIf=\"field.icon\" class=\"icon {{field.icon}}\" aria-hidden=\"true\"></i>\n          <span>{{field.label}}</span>\n      </button>\n  </div>\n</div>\n",
        styles: [""]
    }),
    __metadata("design:paramtypes", [EventAggregatorService])
], ButtonComponent);

let ButtonModule = class ButtonModule {
};
ButtonModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule,
            ReactiveFormsModule
        ],
        declarations: [ButtonComponent],
        exports: [ButtonComponent],
        entryComponents: [ButtonComponent]
    })
], ButtonModule);

let TypeaheadSelectComponent = 
/**
 * This component handles two type of input options
 * 1. String list- Single/Multiple selection
 * 2. Object list- Single/Multiple selection
 */
class TypeaheadSelectComponent extends FieldComponentBase {
    constructor(eventAggregatorService, tealiumdatasvc) {
        super();
        this.eventAggregatorService = eventAggregatorService;
        this.tealiumdatasvc = tealiumdatasvc;
    }
    ngOnInit() {
        this.currentFieldControl = this.group.get(this.field.name);
        if (this.field.value && this.currentFieldControl) {
            this.currentFieldControl.setValue(this.field.value);
        }
    }
    /**
     * handle select event of ng-selet
     * @param event
     */
    selectHandler(event) {
        if (event) {
            // type is string, so update selection option is straight
            if (typeof event === 'string') {
                this.selectedOption = event;
            }
            else if (typeof event === 'object') {
                this.handleObjectList(event);
            }
            this.currentFieldControl.setValue(this.selectedOption);
            this.field.value = this.selectedOption;
            if (this.field.eventName) {
                this.eventAggregatorService.broadcast(this.field.eventName, { selectedOption: this.selectedOption, formsGroup: this.group, field: this.field });
            }
            if (this.field.isTealiumAllowed) {
                this.tealiumdatasvc.addImpressionEvent({
                    'event_parent': 'Page Tag',
                    'event_type': 'Select Click',
                    'event_id': this.field.label,
                    'event_value': this.selectedOption,
                    'da_track': true
                });
            }
        }
    }
    /**
     * this method handles the value selection for the field with input list of type object.
     * @param event
     */
    handleObjectList(event) {
        // type is object so, the get the value based on the bind value provided
        if (this.field.multiple) {
            // multiple options allowed, so building a list of selected values
            this.selectedOption = [];
            // list of selected items
            for (const item of event) {
                if (typeof item === 'object') {
                    // get the value using bindValue
                    this.selectedOption.push(item[this.field.bindValue]);
                }
                else {
                    // type is string, push the value to list
                    this.selectedOption.push(item);
                }
            }
        }
        else {
            // for single selection
            this.selectedOption = event[this.field.bindValue];
        }
    }
    /**
     * on blur mark field as touched
     */
    onBlur() {
        if (this.currentFieldControl.untouched) {
            this.currentFieldControl.markAsTouched({ onlySelf: true });
        }
    }
};
TypeaheadSelectComponent.ctorParameters = () => [
    { type: EventAggregatorService },
    { type: TealiumDataService }
];
TypeaheadSelectComponent = __decorate([
    Component({
        selector: 'lib-typeahead-select',
        template: "<div class=\"form-group\" *ngIf=\"field && field.showField\" [ngClass]=\"{'ng-invalid has-error': hasError()}\"\n  [formGroup]=\"group\">\n  <div class=\"row\" *ngIf=\"field.label\">\n    <div class=\"{{field.labelClass}} label-block\">\n      <label class=\"control-label\" [innerHTML]=\"field.label | safe: 'html'\"></label>\n      <lib-tooltip placement=\"top\" *ngIf=\"field.helpText\" [enableSingleTooltip]=\"true\"\n        [tealiumContent]=\"{'eventValue': field.helpText, 'tealiumTracking': field.isTealiumAllowed}\">\n        <p class=\"tooltip-content-body-text\">{{field.helpText}}</p>\n      </lib-tooltip>\n      <small class=\"help-block\" *ngIf=\"field.extraLabel\">{{field.extraLabel}}</small>\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"{{field.className}}\">\n      <ng-select [items]=\"field.options\" class=\"huk\" [ngClass]=\"{'ng-invalid has-error': hasError()}\"\n        (change)=\"selectHandler($event)\"\n        [maxSelectedItems] = \"field.maxAllowed\"\n        (blur)=\"onBlur()\"\n        [formControlName]=\"field.name\"\n        [autoCapitalize]=\"true\"\n        [bindLabel]=\"field.bindLabel\"\n        [bindValue]=\"field.bindValue\"\n        [multiple]=\"field.multiple\"\n        [notFoundText]=\"field.notFoundText\"\n        [groupBy]=\"field.groupBy\"\n        [typeahead]=\"field.typeahead$\"\n        [minTermLength]=\"field.minTermLength\"\n        [placeholder]=\"field.placeHolder\">\n        <ng-template ng-option-tmp let-item=\"item\" let-search=\"searchTerm\">\n          <div  [ngOptionHighlight]=\"search\" >{{ field.bindLabel ? item[field.bindLabel] : item }}</div>\n        </ng-template>\n      </ng-select>\n      <lib-validation-error *ngIf=\"_hasError\" [message]=\"errorMessage\" [field]=\"field.label\">\n      </lib-validation-error>\n\n    </div>\n  </div>\n  <small class=\"help-block\" *ngIf=\"field.extraText\" [innerHTML]=\"field.extraText\"></small>\n</div>\n",
        encapsulation: ViewEncapsulation.None,
        styles: [".ng-select.huk .ng-select-container{border:1px solid #3a5a78;border-radius:0;color:#484848;padding:6px;height:2.5em}.ng-select.huk .ng-select-container .ng-value-container{padding:0}.ng-select.huk .ng-select-container .ng-value-container .ng-placeholder{color:#aaa;position:absolute;top:10px}.ng-select.huk .ng-select-container .ng-value-container .ng-value{margin-bottom:0}.ng-select.huk .ng-select-container .ng-value-container .ng-input{height:2.5em;padding:0}.ng-select.huk .ng-select-container .ng-arrow-wrapper,.ng-select.huk .ng-select-container .ng-clear-wrapper{display:none}.ng-select.huk .ng-value-container{padding-left:5px;padding-top:0}.ng-select.huk .ng-dropdown-panel{background-color:#fff;border:1px solid #4e79a2;border-radius:0}.ng-select.huk .ng-dropdown-panel .ng-dropdown-panel-items{max-height:310px}.ng-select.huk .ng-dropdown-panel .ng-dropdown-panel-items .highlight{font-weight:500}.ng-select.huk .ng-dropdown-panel .ng-dropdown-panel-items .ng-option .highlighted{text-decoration:none}.ng-select.huk.ng-select-single .ng-select-container .ng-value-container .ng-input{padding-left:6px;top:0}.ng-select.ng-invalid.ng-touched .ng-select-container{border-color:#b83b2f}.ng-select-error{position:relative;color:#b83b2f}.ng-select-error span.icon{left:-10px;display:inline-block}.ng-select-error .help-block{margin-left:26px;display:inline-block;color:#b83b2f}"]
    })
    /**
     * This component handles two type of input options
     * 1. String list- Single/Multiple selection
     * 2. Object list- Single/Multiple selection
     */
    ,
    __metadata("design:paramtypes", [EventAggregatorService,
        TealiumDataService])
], TypeaheadSelectComponent);

let TypeaheadSelectModule = class TypeaheadSelectModule {
};
TypeaheadSelectModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule,
            NgSelectModule,
            NgOptionHighlightModule,
            ReactiveFormsModule,
            FormHelperModule,
            HigTooltipModule,
            PipesModule
        ],
        declarations: [TypeaheadSelectComponent],
        exports: [TypeaheadSelectComponent],
        entryComponents: [TypeaheadSelectComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], TypeaheadSelectModule);

class Message {
    constructor() {
        this.messageTitle = '';
        this.messageText = '';
    }
}

let MessagingComponent = class MessagingComponent extends FieldComponentBase {
    constructor(elt, tealiumDataService) {
        super();
        this.elt = elt;
        this.tealiumDataService = tealiumDataService;
        this.messageBxHide = false;
        this.titleCase = new TitleCasePipe();
    }
    ngOnInit() {
        this.successMsg = false;
        this.infoMsg = false;
        this.warningMsg = false;
        this.dangerMsg = false;
        if (this.message) {
            this.renderMsgBox(this.message.messageType);
        }
        this.denyCodeText = 'B';
    }
    ngAfterViewInit() {
        this.msg = Object.assign({}, this.message);
        this.msg.messageText = this.elt.nativeElement.innerText;
    }
    renderMsgBox(messageType) {
        switch (messageType.toLocaleLowerCase()) {
            case 'success':
                this.successMsg = true;
                break;
            case 'info':
                this.infoMsg = true;
                break;
            case 'warning':
                this.warningMsg = true;
                break;
            case 'danger':
                this.dangerMsg = true;
                break;
        }
        if (this.field && this.field.showField && this.field.isTealiumAllowed && !this.isCustomHtml) {
            if (this.field.customTealiumData) {
                this.tealiumDataService.addImpressionEvent(this.field.customTealiumData);
            }
            else if (this.message) {
                this.tealiumDataService.addImpressionEvent({
                    'event_name': 'Application Messages',
                    'event_parent': this.titleCase.transform(this.message.messageType) + ' Message',
                    'event_type': 'Page Tag',
                    'event_id': this.message.messageText,
                    'event_value': window.location.href,
                    'da_track': true
                });
            }
        }
    }
    messageBoxHideCheck() {
        this.messageBxHide = !this.messageBxHide;
    }
    trackLinkClick() {
        if (this.field.isTealiumAllowed) {
            this.tealiumDataService.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': 'Link Click',
                'event_id': this.message.linkText,
                'event_value': window.location.href,
                'da_track': true
            }, true);
        }
    }
};
MessagingComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: TealiumDataService }
];
__decorate([
    Input(),
    __metadata("design:type", Message)
], MessagingComponent.prototype, "message", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], MessagingComponent.prototype, "isCustomHtml", void 0);
MessagingComponent = __decorate([
    Component({
        selector: 'lib-messaging',
        template: "<div *ngIf=\"field && field.showField && (successMsg || infoMsg || dangerMsg || warningMsg )\"\nclass=\"alert-messages form-group\" [ngClass]= \"{'hidden': messageBxHide, 'alert-messages-optional': !message.messageTitle}\">\n  <!-- Parse message as html safe -- *ngif changed for style implementation-->\n  <div [ngClass]= \"{'message-success': successMsg,'message-info': infoMsg,'message-warning': warningMsg,'message-danger': dangerMsg}\" id=\"ngKit-messaging-{{field.name}}\">\n    <strong class=\"message-header\">\n      <i class=\"message-header-icon\" aria-hidden=\"true\"\n         [ngClass]= \"{'icon-bullet-check-mark': (successMsg),'icon-attention-alt': infoMsg||dangerMsg,'icon-alert-warning-alt': warningMsg}\"></i>\n      <content *ngIf=\"message.messageTitle\" class=\"message-header-text\" [innerHTML]=\"message.messageTitle\"></content>\n    </strong>\n    <p *ngIf=\"!isCustomHtml\">\n      <content [innerHTML]=\"message.messageText\"></content>\n      <span *ngIf=\"message.messageLinkUrl\"><a (click)=\"trackLinkClick()\" href=\"{{message.messageLinkUrl}}\" class=\"alert-link\" id=\"ngKit-messaging-{{field.name}}-AlertLink\">{{message.linkText}}</a></span>\n    </p>\n    <div *ngIf=\"isCustomHtml\">\n      <ng-content select=\".message-content\"></ng-content>\n    </div>\n  </div>\n  <!-- Use custom HTML content-- *ngif changed for style implementation -->\n</div>\n\n\n\n",
        styles: [""]
    }),
    __metadata("design:paramtypes", [ElementRef, TealiumDataService])
], MessagingComponent);

let ParagraphComponent = class ParagraphComponent extends FieldComponentBase {
    constructor(eventAggregatorService) {
        super();
        this.eventAggregatorService = eventAggregatorService;
    }
    ngOnInit() {
    }
    onLinkClick(event) {
        const href = event.target.getAttribute('href');
        if (href) {
            event.preventDefault();
            if (this.field.eventName) {
                this.eventAggregatorService.broadcast(this.field.eventName, { field: this.field, event: event });
            }
        }
    }
};
ParagraphComponent.ctorParameters = () => [
    { type: EventAggregatorService }
];
ParagraphComponent = __decorate([
    Component({
        selector: 'lib-paragraph',
        template: "<ng-container *ngIf=\"field && field.showField\">\n  <ng-container *ngIf=\"field.hasHtml; else stringOnlyRef\">\n      <p class=\"{{field.className}}\" [innerHTML]=\"field.label | safe: 'html'\"\n         id=\"ngKit-paragraph-{{field.name}}-Link\" (click)=\"onLinkClick($event)\">\n      </p>\n  </ng-container>\n  <ng-template #stringOnlyRef>\n      <p class=\"{{field.className}}\" id=\"ngKit-paragraph-{{field.name}}\">\n        {{field.label}}\n      </p>\n  </ng-template>\n</ng-container>\n\n",
        styles: [""]
    }),
    __metadata("design:paramtypes", [EventAggregatorService])
], ParagraphComponent);

let HeadingComponent = class HeadingComponent extends FieldComponentBase {
    constructor(eventAggregatorService) {
        super();
        this.eventAggregatorService = eventAggregatorService;
    }
    ngOnInit() {
    }
    onLinkClick(event) {
        const href = event.target.getAttribute('href');
        if (href) {
            event.preventDefault();
            if (this.field.eventName) {
                this.eventAggregatorService.broadcast(this.field.eventName, { field: this.field, event: event });
            }
        }
    }
};
HeadingComponent.ctorParameters = () => [
    { type: EventAggregatorService }
];
HeadingComponent = __decorate([
    Component({
        selector: 'lib-heading',
        template: "<ng-container *ngIf=\"field && field.showField\">\n    <ng-container *ngIf=\"field.hasHtml; else stringOnlyRef\">\n        <h3 class=\"{{field.className}}\" [innerHTML]=\"field.label | safe: 'html'\" id=\"ngKit-heading-{{field.name}}-header\" (click)=\"onLinkClick($event)\">\n        </h3>\n    </ng-container>\n    <ng-template #stringOnlyRef>\n        <ng-container [ngSwitch]=\"field.subType\">\n            <h1 *ngSwitchCase=\"'h1'\" class=\"{{field.className}}\" id=\"ngKit-heading-{{field.name}}-h1\">{{field.label}}</h1>\n            <h2 *ngSwitchCase=\"'h2'\" class=\"{{field.className}}\" id=\"ngKit-heading-{{field.name}}-h2\">{{field.label}}</h2>\n            <h3 *ngSwitchCase=\"'h3'\" class=\"{{field.className}}\" id=\"ngKit-heading-{{field.name}}-h3\">{{field.label}}</h3>\n            <h4 *ngSwitchCase=\"'h4'\" class=\"{{field.className}}\" id=\"ngKit-heading-{{field.name}}-h4\">{{field.label}}</h4>\n            <h5 *ngSwitchCase=\"'h5'\" class=\"{{field.className}}\" id=\"ngKit-heading-{{field.name}}-h5\">{{field.label}}</h5>\n            <!-- h3 tag would be default selection is subType not defined -->\n            <h3 *ngSwitchDefault class=\"{{field.className}}\" id=\"ngKit-heading-{{field.name}}-h3-default\">{{field.label}}</h3>\n        </ng-container>\n    </ng-template>\n</ng-container>\n"
    }),
    __metadata("design:paramtypes", [EventAggregatorService])
], HeadingComponent);

let ListComponent = class ListComponent extends FieldComponentBase {
    constructor() {
        super();
    }
    ngOnInit() {
    }
};
ListComponent = __decorate([
    Component({
        selector: 'lib-list',
        template: "<ul class=\"list-group benefit\" *ngIf=\"field && field.showField\">\n  <li *ngFor=\"let option of field.options; let i = index\" id=\"ngKit-list-{{field.name}}-{{i}}\">{{option.label}}</li>\n</ul>\n",
        styles: [".benefit li{margin-left:0}"]
    }),
    __metadata("design:paramtypes", [])
], ListComponent);

let InfoFieldsModule = class InfoFieldsModule {
};
InfoFieldsModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            PipesModule.forRoot(),
        ],
        declarations: [MessagingComponent, ParagraphComponent, HeadingComponent, ListComponent],
        exports: [MessagingComponent, ParagraphComponent, HeadingComponent, ListComponent],
        entryComponents: [MessagingComponent, ParagraphComponent, HeadingComponent, ListComponent]
    })
], InfoFieldsModule);

// field types for isFormControlNotRequired check
const fieldTypes = ['button', 'heading', 'container', 'datePicker', 'paragraph', 'list', 'messaging', 'address'];
class FormEngineBase {
    constructor(fb, eventAggregatorService) {
        this.fb = fb;
        this.eventAggregatorService = eventAggregatorService;
        this.submit = new EventEmitter();
        this.getFields = new EventEmitter();
        // manages cleanup of subscriptions
        this.subManager = new Subscription();
        this.allFields = [];
        this.addressFieldKeyList = [];
    }
    /**
     * subscribeEventAggregator handles form validator events for all fields
     */
    subscribeEventAggregator() {
        if (this.fields && this.fields.name) {
            const subscription = this.eventAggregatorService.subscribe(this.fields.name + ':validateAllFields', (payload) => {
                if (payload && payload.event) {
                    this.onSubmit(event);
                }
                else {
                    this.validateAllFormFields(this.form);
                }
            });
            // add subscription to subscription manager
            this.subManager.add(subscription);
            const formSubscription = this.eventAggregatorService.subscribe(this.fields.name + ':updateFormGroup', (payload) => {
                // Resets formsCtrlList with updated fields
                const fieldList = [];
                this.getAllFields(this.fields, fieldList);
                this.formsCtrlList = fieldList;
                this.createControl(true);
                this.form.updateValueAndValidity();
            });
            this.subManager.add(formSubscription);
        }
    }
    /**
     * Common onSubmit method
     * @param event
     */
    onSubmit(event) {
        event.preventDefault();
        event.stopPropagation();
        if (this.form.valid) {
            this.submit.emit(this.form.value);
        }
        else {
            this.validateAllFormFields(this.form);
        }
    }
    /**
     * recursive method to retun all the field as an array
     * @param fieldConfig
     * @param fieldList
     */
    getAllFields(fieldConfig, fieldList) {
        if (fieldConfig && fieldConfig.children && fieldConfig.children.length > 0) {
            for (const field of fieldConfig.children) {
                fieldList.push(field);
                if (field.children && field.children.length > 0) {
                    this.getAllFields(field, fieldList);
                }
            }
        }
    }
    /**
     * Create/Update form controls for all the fields
     * @param updateCtrl
     */
    createControl(updateCtrl) {
        // Run only once if formsCtrlList not having all the fields
        if (!this.formsCtrlList) {
            const fieldList = [];
            this.getAllFields(this.fields, fieldList);
            this.formsCtrlList = fieldList;
            this.getFields.emit({ fields: this.formsCtrlList, formGroup: this.form });
        }
        this.updateAddressControls();
        // cleanup form if field removed from the fieldList
        if (this.form) {
            const fieldNames = Object.keys(this.form.controls);
            for (const fieldName of fieldNames) {
                if (!this.isAddressField(fieldName) && this.formsCtrlList.findIndex((item) => item.name === fieldName) === -1) {
                    this.form.removeControl(fieldName);
                }
            }
        }
        // Loop through each fields
        for (const field of this.formsCtrlList) {
            this.behaviourUpdate(field, this.form);
            if (!this.isNotAllowedFormCtrlField(field.type)) {
                // If showField true then create form control else remove form control if exist
                if (field.showField) {
                    this.createFormControl(field);
                }
                else if (updateCtrl) {
                    if (this.form && this.form.controls) {
                        this.form.removeControl(field.name);
                    }
                }
            }
        }
    }
    /**
     * update address form controls
     */
    updateAddressControls() {
        const addressFields = this.formsCtrlList.filter(field => {
            return field.type === 'address';
        });
        this.addressFieldKeyList = [];
        if (addressFields && addressFields.length > 0) {
            const addressFieldList = ['addressLine1', 'city', 'state', 'zipCode', 'apt', 'addressLine2'];
            for (const addressField of addressFields) {
                if (addressField.name) {
                    for (const addressFieldName of addressFieldList) {
                        this.addressFieldKeyList.push(this.getFieldControlName(addressField.name, addressFieldName));
                    }
                }
            }
            // adding quality code
            if (this.addressFieldKeyList.length > 0) {
                this.addressFieldKeyList.push('qualityCode');
            }
        }
    }
    /**
     * return control name for the selected field
     * @param fieldName
     */
    getFieldControlName(fieldName, addressFieldName) {
        if (fieldName && addressFieldName) {
            switch (addressFieldName) {
                case 'addressLine1':
                    return fieldName + 'AddressLine1';
                case 'city':
                    return fieldName + 'City';
                case 'state':
                    return fieldName + 'State';
                case 'zipCode':
                    return fieldName + 'ZipCode';
                case 'apt':
                    return fieldName + 'Apt';
                case 'addressLine2':
                    return fieldName + 'AddressLine2';
            }
        }
        return fieldName;
    }
    /**
     * returns true if field name contains anyof the address field
     * @param fieldName
     */
    isAddressField(fieldName) {
        if (fieldName && this.addressFieldKeyList.length > 0) {
            for (const field of this.addressFieldKeyList) {
                if (fieldName.indexOf(field) > -1) {
                    return true;
                }
            }
        }
        return false;
    }
    /**
     *  Returns true if formControl not required for selected field
     * @param fieldType
     */
    isNotAllowedFormCtrlField(fieldType) {
        return fieldTypes.indexOf(fieldType) > -1;
    }
    /**
     * Creates formControl
     * @param field
     */
    createFormControl(field) {
        if (this.form && field) {
            const control = this.fb.control({ value: field.value, disabled: field.disabled }, this.bindValidations(field.validations || [], field));
            this.form.addControl(field.name, control);
        }
    }
    /**
     * Common method to returns index of array for the given key value
     * @param arry
     * @param key
     * @param value
     */
    getIndex(arry, key, value) {
        if (arry && key) {
            return arry.findIndex((element) => {
                return element[key] === value;
            });
        }
        return -1;
    }
    /**
     * binds validations with field if applicable
     * @param validations
     */
    bindValidations(validations, field) {
        if (validations.length > 0) {
            const validList = [];
            for (const validation of validations) {
                if (validation && validation.name && field) {
                    switch (validation.name) {
                        case 'min':
                            validList.push(Validators.min(field.minValue));
                            break;
                        case 'max':
                            validList.push(Validators.max(field.maxValue));
                            break;
                        case 'minLength':
                            validList.push(Validators.minLength(field.minLength));
                            break;
                        case 'maxLength':
                            validList.push(Validators.maxLength(field.maxLength));
                            break;
                        case 'required':
                            validList.push(Validators.required);
                            break;
                        case 'pattern':
                            validList.push(Validators.pattern(validation.pattern));
                            break;
                    }
                }
            }
            return Validators.compose(validList);
        }
        return null;
    }
    /**
     * Validates each fields in the form
     * @param formGroup
     */
    validateAllFormFields(formGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control) {
                control.markAsTouched({ onlySelf: true });
            }
        });
        this.markControlsDirty(formGroup);
    }
    /**
     * Validates each fields in the form (dirtycheck)
     * @param formGroup
     */
    markControlsDirty(group) {
        Object.keys(group.controls).forEach((key) => {
            const abstractControl = group.controls[key];
            if (abstractControl instanceof FormGroup || abstractControl instanceof FormArray) {
                this.markControlsDirty(abstractControl);
            }
            else {
                abstractControl.markAsDirty();
                abstractControl.updateValueAndValidity({ onlySelf: false, emitEvent: true });
            }
        });
    }
    /**
     * Upodated form controls for shown/hidden fields and subscribe events
     * @param update
     */
    syncForm(update) {
        this.createControl(update);
        this.form.updateValueAndValidity();
        this.subscribeEventAggregator();
    }
    /**
     * Updated field behaviour based on the behaviour Object
     * @param field
     */
    behaviourUpdate(field, form) {
        if (field.behaviors && field.behaviors.length > 0) {
            for (const behavior of field.behaviors) {
                if (behavior && behavior.statements) {
                    const stmtResponse = [];
                    const action = behavior.action;
                    const operator = behavior.operator;
                    this.recurLogic(behavior.statements, stmtResponse, form);
                    const updatedResponse = [];
                    if (stmtResponse.length > 0) {
                        for (const stmtRes of stmtResponse) {
                            if (typeof stmtRes === 'boolean') {
                                updatedResponse.push(stmtRes);
                            }
                            else if (stmtRes['OR']) {
                                const objArray = stmtRes['OR'];
                                if (objArray.length > 0) {
                                    updatedResponse.push(objArray.indexOf(true) > -1);
                                }
                            }
                            else if (stmtRes['AND']) {
                                const objArray = stmtRes['AND'];
                                if (objArray.length > 0) {
                                    updatedResponse.push(!(objArray.indexOf(false) > -1));
                                }
                            }
                        }
                    }
                    let fieldToUpdate;
                    if (action === 'show') {
                        fieldToUpdate = 'showField';
                    }
                    else if (action === 'disable') {
                        fieldToUpdate = 'disabled';
                    }
                    if (operator === 'OR') {
                        field[fieldToUpdate] = updatedResponse.indexOf(true) > -1;
                    }
                    else if (operator === 'AND') {
                        field[fieldToUpdate] = !(updatedResponse.indexOf(false) > -1);
                    }
                }
            }
        }
        /**
         * broadcast events to update address fields
         */
        if (field.type === 'address') {
            this.eventAggregatorService.broadcast('validateAddressForFormEngine', {});
        }
        /**
         * broadcast events to update datepicker field if used in the behaviour
         */
        if (field.type === 'datePicker') {
            this.eventAggregatorService.broadcast('validateDatepickerForFormEngine', {});
        }
    }
    /**
     * Recursive method to execute nested behaviour statements
     * @param statements
     * @param stmtResponse
     */
    recurLogic(statements, stmtResponse, form) {
        for (const stmt of statements) {
            if (stmt['type'] === 'statement') {
                const targetFieldValue = form.value[stmt.name];
                stmtResponse.push(this.compare(targetFieldValue, stmt.operator, stmt.value));
            }
            else if (stmt.statements) {
                const obj = {};
                obj[stmt.operator] = [];
                stmtResponse.push(obj);
                this.recurLogic(stmt.statements, obj[stmt.operator], form);
            }
        }
    }
    /**
     * compare method return boolean after logical operation
     * @param post
     * @param operator
     * @param value
     */
    compare(post, operator, value) {
        switch (operator) {
            case '>': return post > value;
            case '<': return post < value;
            case '>=': return post >= value;
            case '<=': return post <= value;
            case '===': return post === value;
            case '!==': return post !== value;
        }
    }
    ngOnDestroy() {
        this.subManager.unsubscribe();
    }
}
__decorate([
    Input(),
    __metadata("design:type", Object)
], FormEngineBase.prototype, "fields", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], FormEngineBase.prototype, "submit", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], FormEngineBase.prototype, "getFields", void 0);
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], FormEngineBase.prototype, "form", void 0);

let FormEngineComponent = class FormEngineComponent extends FormEngineBase {
    constructor(fb, eventAggregatorService, differs) {
        super(fb, eventAggregatorService);
        this.fb = fb;
        this.eventAggregatorService = eventAggregatorService;
        this.differs = differs;
        this.differ = differs.find({}).create();
    }
    ngOnInit() {
        /**
         * create formGroup if not passed from parent component
         */
        if (!this.form) {
            this.form = this.fb.group({});
        }
        this.syncForm(false);
    }
    /**
     * if field config or formGroup changes then call syncForm method
     * @param changes
     */
    ngOnChanges(changes) {
        if (changes.fields && this.form) {
            const fieldList = [];
            this.getAllFields(this.fields, fieldList);
            this.formsCtrlList = fieldList;
            this.getFields.emit({ fields: this.formsCtrlList, formGroup: this.form });
            this.syncForm(true);
        }
    }
    /**
     * Call syncForm method there has been update in the form value
     */
    ngDoCheck() {
        const formValueChanges = this.differ.diff(this.form.value);
        if (formValueChanges) {
            this.syncForm(true);
        }
    }
};
FormEngineComponent.ctorParameters = () => [
    { type: FormBuilder },
    { type: EventAggregatorService },
    { type: KeyValueDiffers }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], FormEngineComponent.prototype, "fields", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FormEngineComponent.prototype, "mapper", void 0);
FormEngineComponent = __decorate([
    Component({
        selector: 'lib-form-engine',
        template: "<form class=\"dynamic-form\" [formGroup]=\"form\">\n  <ng-container *ngFor=\"let fieldConfig of fields.children\">\n    <ng-template [ngTemplateOutlet]=\"nodeTemplateRef\" [ngTemplateOutletContext]=\"{ $implicit: fieldConfig }\">\n    </ng-template>\n  </ng-container>\n  <ng-template #nodeTemplateRef let-fieldConfig>\n    <ng-container *ngIf=\"fieldConfig && fieldConfig.children && fieldConfig.children.length > 0 else fieldTempRef\">\n      <div [ngClass]=\"fieldConfig.className\" *ngIf=\"fieldConfig.children.length && fieldConfig.showField\">\n        <ng-template ngFor [ngForOf]=\"fieldConfig.children\" [ngForTemplate]=\"nodeTemplateRef\">\n        </ng-template>\n      </div>\n    </ng-container>\n    <ng-template #fieldTempRef>\n      <ng-container libFormEngine [field]=\"fieldConfig\" [group]=\"form\" [mapper]=\"mapper\">\n      </ng-container>\n    </ng-template>\n  </ng-template>\n</form>\n",
        styles: [".grey-bg{background-color:#f2f2f2;padding:1em;margin:0}.no-left-padding,.no-right-padding{padding-left:0}"]
    }),
    __metadata("design:paramtypes", [FormBuilder,
        EventAggregatorService,
        KeyValueDiffers])
], FormEngineComponent);

class FormEngineDirectiveBase {
    constructor(resolver, container) {
        this.resolver = resolver;
        this.container = container;
    }
    /**
     * This method loads dynamic fields in DOM and create angular components for the fields config
     */
    renderFields() {
        if (this.field && this.field.type && this.componentMapper) {
            const factory = this.resolver.resolveComponentFactory(this.componentMapper[this.field.type]);
            this.componentRef = this.container.createComponent(factory);
            this.componentRef.instance.field = this.field;
            this.componentRef.instance.group = this.group;
            if (this.field.type === 'messaging') {
                this.componentRef.instance.message = this.field.message;
                this.componentRef.instance.isCustomHtml = this.field.isCustomHtml;
            }
            if (this.field.type === 'select' && this.field.value) {
                this.componentRef.instance.selectedOption = this.field.value;
            }
        }
    }
}
__decorate([
    Input(),
    __metadata("design:type", Object)
], FormEngineDirectiveBase.prototype, "field", void 0);
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], FormEngineDirectiveBase.prototype, "group", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FormEngineDirectiveBase.prototype, "componentMapper", void 0);

let FormEngineDirective = class FormEngineDirective extends FormEngineDirectiveBase {
    constructor(resolver, container) {
        super(resolver, container);
        this.resolver = resolver;
        this.container = container;
    }
    /**
     * ngOnChanges method detect changes for all the input fields
     * @param changes
     */
    ngOnChanges(changes) {
        /**
         * If mapper object changes reflects here, assign it to componentMapper for rendering
         */
        if (changes && changes.mapper && this.mapper) {
            this.componentMapper = this.mapper;
            this.renderFields();
        }
    }
};
FormEngineDirective.ctorParameters = () => [
    { type: ComponentFactoryResolver },
    { type: ViewContainerRef }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], FormEngineDirective.prototype, "field", void 0);
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], FormEngineDirective.prototype, "group", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], FormEngineDirective.prototype, "mapper", void 0);
FormEngineDirective = __decorate([
    Directive({
        selector: '[libFormEngine]'
    }),
    __metadata("design:paramtypes", [ComponentFactoryResolver,
        ViewContainerRef])
], FormEngineDirective);

let FormEngineModule = class FormEngineModule {
};
FormEngineModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            FormsModule,
            ReactiveFormsModule
        ],
        declarations: [FormEngineComponent, FormEngineDirective],
        exports: [FormEngineComponent, FormEngineDirective],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], FormEngineModule);

let ModalScrollService = class ModalScrollService {
    constructor() {
        this.isScrollableSubject = new Subject();
        this.scrollStatus = {};
    }
    /**
     * Set the status is scrollable by modal name
     */
    setModalScroll(modalKey, allowScrolling) {
        if (!allowScrolling) {
            this.scrollStatus[modalKey] = true; // Add a no scroll
        }
        else {
            delete this.scrollStatus[modalKey]; // Remove a no scroll
        }
        this.isScrollableSubject.next(this.isScrollable());
    }
    /**
     * Returns scrollable status, if any no scrolls are in place prevent it from scrolling
     */
    isScrollable() {
        return Object.keys(this.scrollStatus).length === 0;
    }
    /**
     * Returns the observable for subscriptions
     */
    getScrollableObservable() {
        return this.isScrollableSubject;
    }
};
ModalScrollService = __decorate([
    Injectable()
], ModalScrollService);

let ModalComponent = class ModalComponent {
    constructor(modalScrollService) {
        this.modalScrollService = modalScrollService;
        if (!this.modalName) {
            this.modalName = 'generated-' + (Math.floor(Math.random() * 10000000)).toString();
        }
    }
    ngOnInit() {
        if (typeof this.dismissibleCallback === 'function') {
            this.showDismissButton = true;
        }
        this.setElementClass();
    }
    ngOnChanges(changes) {
        const showModal = changes['showModal'];
        if (showModal && showModal.currentValue === true) {
            this.modalScrollService.setModalScroll(this.modalName, false);
        }
        else {
            this.modalScrollService.setModalScroll(this.modalName, true);
        }
    }
    elementClicked(element) {
        if (element.elementCallback) {
            element.elementCallback();
        }
    }
    setElementClass() {
        if (this.elements) {
            if (this.elements.length === 1) {
                this.layoutClasses = 'one-element';
            }
            if (this.elements.length === 2) {
                this.layoutClasses = 'two-elements';
            }
            if (this.elements.length >= 3) {
                this.layoutClasses = 'three-elements';
            }
        }
    }
    getModalType() {
        if (this.modalType === 'danger') {
            return 'modal-dialog-content-alert-danger';
        }
        if (this.modalType === 'warning') {
            return 'modal-dialog-content-alert';
        }
        return '';
    }
    closeModal() {
        this.showModal = false;
        this.modalScrollService.setModalScroll(this.modalName, true);
        this.dismissibleCallback();
    }
    getModalSize() {
        switch (this.modalSize) {
            case 'large':
                return 'modal-lg';
                break;
            case 'medium':
                return 'modal-md';
                break;
            case 'small':
                return 'modal-sm';
                break;
            default:
                return 'modal-lg';
        }
    }
    getModalDialogClasses() {
        return this.getModalSize() + ' ' + this.getModalType();
    }
};
ModalComponent.ctorParameters = () => [
    { type: ModalScrollService }
];
__decorate([
    Input(),
    __metadata("design:type", String)
], ModalComponent.prototype, "header", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], ModalComponent.prototype, "headerSubtext", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], ModalComponent.prototype, "body", void 0);
__decorate([
    Input(),
    __metadata("design:type", Function)
], ModalComponent.prototype, "dismissibleCallback", void 0);
__decorate([
    Input(),
    __metadata("design:type", Array)
], ModalComponent.prototype, "elements", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], ModalComponent.prototype, "showModal", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], ModalComponent.prototype, "modalName", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], ModalComponent.prototype, "modalSize", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], ModalComponent.prototype, "modalType", void 0);
ModalComponent = __decorate([
    Component({
        selector: 'lib-modal',
        template: "<div class=\"modal fade\" [ngClass]=\"{'in': showModal}\" role=\"dialog\">\n  <div [ngClass]=\"getModalDialogClasses()\" class=\"modal-dialog\">\n    <div class=\"modal-content card offset\">\n      <div class=\"modal-header\">\n        <button\n          *ngIf=\"showDismissButton\"\n          type=\"button\"\n          class=\"close\"\n          data-dismiss=\"modal\"\n          id=\"ngKit-modal-close\"\n          (click)=\"closeModal()\">\n          <i class=\"icon icon-close\"></i>\n        </button>\n        <div class=\"modal-title\" *ngIf=\"header\" [innerHTML]=\"header\"></div>\n        <div class=\"modal-title\" *ngIf=\"headerSubtext\" [innerHTML]=\"headerSubtext\"></div>\n      </div>\n      <div class=\"modal-body\" *ngIf=\"body\" [innerHTML]=\"body\">\n      </div>\n      <div class=\"modal-footer\" *ngIf=\"elements\">\n        <div [ngClass]=\"layoutClasses\">\n          <ng-container *ngFor=\"let element of elements; let i = index\">\n            <button *ngIf=\"element.type === 'button'\"\n                    type=\"button\"\n                    class=\"btn\"\n                    id=\"ngKit-modal-button-{{i}}\"\n                    [ngClass]=\"element.elementClass\"\n                    (click)=\"elementClicked(element)\"\n                    [innerHTML]=\"element.html\"\n                    [attr.data-action]=\"i\">\n            </button>\n            <a *ngIf=\"element.type === 'link'\"\n               id=\"ngKit-modal-Link-{{i}}\"\n               [ngClass]=\"element.elementClass\"\n               (click)=\"elementClicked(element)\"\n               [innerHTML]=\"element.html\"\n               [attr.data-action]=\"i\">\n            </a>\n          </ng-container>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n",
        styles: [".one-element{float:right}.three-elements{display:inline-block;width:100%;text-align:center}.no-float{float:none!important}.btn{min-width:32%;margin:0}.modal-footer{margin-top:1em}.modal-footer a,.modal-footer a:hover{cursor:pointer}.modal-body{max-height:calc(70vh);overflow:auto}"]
    }),
    __metadata("design:paramtypes", [ModalScrollService])
], ModalComponent);

// Should be imported at the parent application
let ModalScrollDirective = class ModalScrollDirective {
    constructor(el, render, scrollService) {
        this.el = el;
        this.render = render;
        this.scrollService = scrollService;
        this.scrollService.getScrollableObservable().subscribe((scrollable) => {
            this.allowScroll(scrollable);
        });
    }
    /**
     * Determine if a scroll should be allowed and append approriate style
     */
    allowScroll(scrollable) {
        if (!scrollable) {
            if (this.bodyScroll) {
                (document).body.style.overflow = 'hidden';
            }
            else {
                this.render.setStyle(this.el, 'overflow', 'hidden');
            }
        }
        else {
            if (this.bodyScroll) {
                (document).body.style.overflow = 'auto';
            }
            else {
                this.render.removeStyle(this.el, 'overflow');
            }
        }
    }
};
ModalScrollDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 },
    { type: ModalScrollService }
];
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], ModalScrollDirective.prototype, "bodyScroll", void 0);
ModalScrollDirective = __decorate([
    Directive({
        selector: '[libAppModalScroll]'
    }),
    __metadata("design:paramtypes", [ElementRef, Renderer2, ModalScrollService])
], ModalScrollDirective);

var HiguxModalModule_1;
let HiguxModalModule = HiguxModalModule_1 = class HiguxModalModule {
    static forRoot() {
        return {
            ngModule: HiguxModalModule_1,
            providers: [ModalScrollService]
        };
    }
};
HiguxModalModule = HiguxModalModule_1 = __decorate([
    NgModule({
        imports: [CommonModule],
        declarations: [ModalComponent, ModalScrollDirective],
        exports: [ModalComponent, ModalScrollDirective]
    })
], HiguxModalModule);

let CustomModalComponent = class CustomModalComponent {
    constructor(injector) {
        /**
         * flag to show the footer section
         */
        this.showFooter = true;
        /**
         * flag to show the header section
         */
        this.showHeader = true;
        /**
         * for alert icon in the header section
         */
        this.showAlertIconHeader = false;
        /**
         * to show the header content, this flag goes with showHeader attribute
         */
        this.hideHeaderContent = true;
        /**
         * Setting default iconType as Success Check Mark
         */
        this.iconType = 'icon-check-mark';
        /**
         * to display close('X') icon at the top right corner of the modal
         */
        this.showCloseIcon = true;
        /**
         * event emitter on close event of popup
         */
        this.close = new EventEmitter();
        /**
         * visible and visible animate are used in showing and hiding the modal
         */
        this.visible = false;
        /**
         * flag to enable animation
         */
        this.visibleAnimate = false;
        this.document = injector.get(DOCUMENT);
        this.renderer = injector.get(Renderer2);
    }
    show() {
        this.visible = true;
        // hide browser scrollbar to prevent double scrollbars when modal open
        this.renderer.addClass(this.document.body, 'modal-open');
        setTimeout(() => this.visibleAnimate = true, 100);
    }
    hide() {
        this.close.emit({});
        this.visibleAnimate = false;
        // set browser scrollbar back to normal
        this.renderer.removeClass(this.document.body, 'modal-open');
        setTimeout(() => this.visible = false, 300);
    }
    /**
     * Keyboard Navigation Handlers
     */
    handleKeydownEvent(event) {
        if (event.key === 'Escape') {
            this.hide();
        }
    }
    /**
     * click anywhere outside the modal box the popup(session timeout) will close
     */
    clickedOutBox(event) {
        if (event.target.className === 'modal fade in' && this.hideOnClickAnyWhere) {
            this.hide();
        }
    }
    /**
      * Provides the class required according to the modalSize input
      */
    getModalSizeClass() {
        switch (this.modalSize) {
            case 'large':
                return 'modal-lg';
            case 'medium':
                return 'modal-md';
            case 'small':
                return 'modal-sm';
            default:
                return '';
        }
    }
};
CustomModalComponent.ctorParameters = () => [
    { type: Injector }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], CustomModalComponent.prototype, "showFooter", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], CustomModalComponent.prototype, "showHeader", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], CustomModalComponent.prototype, "showAlertIconHeader", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], CustomModalComponent.prototype, "showBody", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], CustomModalComponent.prototype, "title", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], CustomModalComponent.prototype, "hideHeaderContent", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], CustomModalComponent.prototype, "iconType", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], CustomModalComponent.prototype, "modalId", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], CustomModalComponent.prototype, "modalSize", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], CustomModalComponent.prototype, "showCloseIcon", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], CustomModalComponent.prototype, "close", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], CustomModalComponent.prototype, "hideOnClickAnyWhere", void 0);
__decorate([
    HostListener('document:keydown', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [KeyboardEvent]),
    __metadata("design:returntype", void 0)
], CustomModalComponent.prototype, "handleKeydownEvent", null);
CustomModalComponent = __decorate([
    Component({
        selector: 'lib-custom-modal',
        template: "<div class=\"modal fade\"\n     tabindex=\"-1\"\n     [ngClass]=\"{'in': visibleAnimate, 'modal-alert-icon': showAlertIconHeader}\"\n     [ngStyle]=\"{'display': visible ? 'flex' : 'none'}\"\n     aria-hidden=\"true\"\n     aria-labelledby=\"modalTitle\"\n     role=\"dialog\" (click)=\"clickedOutBox($event)\">\n  <div class=\"modal-dialog\" [ngClass]=\"getModalSizeClass()\" [attr.modalId]=\"modalId\" [attr.visible]=\"visible\">\n    <div class=\"modal-content card offset\">\n      <div class=\"modal-header\" *ngIf=\"showHeader\">\n        <button *ngIf=\"showCloseIcon\" type=\"button\" class=\"close\" data-dismiss=\"modal\" (click)=\"hide()\">\n          <i class=\"icon icon-close\" aria-label=\"Close\"></i>\n        </button>\n        <span *ngIf=\"showAlertIconHeader\">\n            <i class=\"icon\" [ngClass]=\"iconType\" aria-hidden=\"true\"></i>\n        </span>\n        <ng-content select=\".app-modal-header\" *ngIf=\"hideHeaderContent\"></ng-content>\n        <ng-container *ngIf=\"title\">\n          <h3 class=\"modal-title\">{{ title }}</h3>\n        </ng-container>\n      </div>\n      <div class=\"modal-body\" data-height>\n        <ng-content select=\".app-modal-body\"></ng-content>\n      </div>\n      <div class=\"modal-footer\" *ngIf=\"showFooter\">\n        <ng-content select=\".app-modal-footer\"></ng-content>\n      </div>\n    </div>\n  </div>\n</div>\n",
        styles: [".modal.in{display:block;z-index:9999}.modal .modal-dialog .modal-content .modal-body[data-height] .learn i.icon{float:left;padding:0 15px 10px 0;font-size:2em}.modal .modal-dialog .modal-content .modal-body[data-height] .learn h3{margin-bottom:0}.modal .modal-dialog .modal-content .modal-body[data-height] .learn .row{margin:0}@media only screen and (max-width:480px){.modal .modal-dialog .modal-content .modal-body[data-height] .learn i.icon{padding:0 15px 0 0}}.modal.modal-alert-icon .modal-dialog .modal-content .modal-header{text-align:center;padding-bottom:0}.modal.modal-alert-icon .modal-dialog .modal-content .modal-header i.icon-alert-warning{margin-left:24px;font-size:4em;color:#f36621}.modal.modal-alert-icon .modal-dialog .modal-content .modal-header i.icon-check-mark{margin-left:24px;font-size:4em;color:#118654}.modal.modal-alert-icon .modal-dialog .modal-content .modal-body{text-align:center}"]
    }),
    __metadata("design:paramtypes", [Injector])
], CustomModalComponent);

let CustomModalModule = class CustomModalModule {
};
CustomModalModule = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        exports: [CustomModalComponent],
        declarations: [CustomModalComponent]
    })
], CustomModalModule);

let MedalliaFeedbackService = class MedalliaFeedbackService {
    constructor() { }
    medalliaFeedbackFormLoad(medalliaFormid) {
        KAMPYLE_ONSITE_SDK.showForm(medalliaFormid);
    }
};
MedalliaFeedbackService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [])
], MedalliaFeedbackService);

let MedalliaFeedbackComponent = class MedalliaFeedbackComponent {
    constructor(medalliaFeedbackService) {
        this.medalliaFeedbackService = medalliaFeedbackService;
    }
    // Loads the medallia overlay
    loadMedallia() {
        this.medalliaFeedbackService.medalliaFeedbackFormLoad(this.medalliaFormId);
    }
};
MedalliaFeedbackComponent.ctorParameters = () => [
    { type: MedalliaFeedbackService }
];
__decorate([
    Input(),
    __metadata("design:type", Number)
], MedalliaFeedbackComponent.prototype, "medalliaFormId", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], MedalliaFeedbackComponent.prototype, "feedbackText", void 0);
MedalliaFeedbackComponent = __decorate([
    Component({
        selector: 'lib-medallia-feedback',
        template: "<div class=\"alert-messages message\">\n  <div class=\"message-info\">\n    <div class=\"row message-body\">\n      <div class=\"col-sm-8\">\n        <div class=\"row\">\n          <div class=\"col-md-2 col-xs-3\">\n            <i class=\"icon icon-5x icon-chat-alt\"></i>\n          </div>\n          <div class=\"col-md-10 col-xs-9 feedback-text\">\n            <h4 class=\"message-header\">\n              <span class=\"message-header-text\" id=\"ngKit-medallia-feedback-Text\">Feedback</span>\n            </h4>\n            <p>{{feedbackText}}</p>\n          </div>\n        </div>\n      </div>\n      <div class=\"col-sm-4\">\n        <div class=\"feedback-button\">\n          <a (click)=\"loadMedallia()\" class=\"btn btn-secondary-paired btn-block\" id=\"ngKit-medallia-feedback-Link\">\n            Tell us what you think\n          </a>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n",
        styles: [".message-header-text{padding:0}.message .feedback-text{padding:.8em}.message .feedback-button{padding:1.5em}"]
    }),
    __metadata("design:paramtypes", [MedalliaFeedbackService])
], MedalliaFeedbackComponent);

let MedalliaFeedbackModule = class MedalliaFeedbackModule {
};
MedalliaFeedbackModule = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        declarations: [MedalliaFeedbackComponent],
        exports: [MedalliaFeedbackComponent],
        providers: [MedalliaFeedbackService]
    })
], MedalliaFeedbackModule);

class ExtendedHttpHeaders extends HttpHeaders {
}
const usOnlyStates = [
    { key: 'AL', value: 'Alabama' },
    { key: 'AK', value: 'Alaska' },
    { key: 'AZ', value: 'Arizona' },
    { key: 'AR', value: 'Arkansas' },
    { key: 'CA', value: 'California' },
    { key: 'CO', value: 'Colorado' },
    { key: 'CT', value: 'Connecticut' },
    { key: 'DE', value: 'Delaware' },
    { key: 'DC', value: 'District Of Columbia' },
    { key: 'FL', value: 'Florida' },
    { key: 'GA', value: 'Georgia' },
    { key: 'HI', value: 'Hawaii' },
    { key: 'ID', value: 'Idaho' },
    { key: 'IL', value: 'Illinois' },
    { key: 'IN', value: 'Indiana' },
    { key: 'IA', value: 'Iowa' },
    { key: 'KS', value: 'Kansas' },
    { key: 'KY', value: 'Kentucky' },
    { key: 'LA', value: 'Louisiana' },
    { key: 'ME', value: 'Maine' },
    { key: 'MD', value: 'Maryland' },
    { key: 'MA', value: 'Massachusetts' },
    { key: 'MI', value: 'Michigan' },
    { key: 'MN', value: 'Minnesota' },
    { key: 'MS', value: 'Mississippi' },
    { key: 'MO', value: 'Missouri' },
    { key: 'MT', value: 'Montana' },
    { key: 'NE', value: 'Nebraska' },
    { key: 'NV', value: 'Nevada' },
    { key: 'NH', value: 'New Hampshire' },
    { key: 'NJ', value: 'New Jersey' },
    { key: 'NM', value: 'New Mexico' },
    { key: 'NY', value: 'New York' },
    { key: 'NC', value: 'North Carolina' },
    { key: 'ND', value: 'North Dakota' },
    { key: 'OH', value: 'Ohio' },
    { key: 'OK', value: 'Oklahoma' },
    { key: 'OR', value: 'Oregon' },
    { key: 'PA', value: 'Pennsylvania' },
    { key: 'RI', value: 'Rhode Island' },
    { key: 'SC', value: 'South Carolina' },
    { key: 'SD', value: 'South Dakota' },
    { key: 'TN', value: 'Tennessee' },
    { key: 'TX', value: 'Texas' },
    { key: 'UT', value: 'Utah' },
    { key: 'VT', value: 'Vermont' },
    { key: 'VA', value: 'Virginia' },
    { key: 'WA', value: 'Washington' },
    { key: 'WV', value: 'West Virginia' },
    { key: 'WI', value: 'Wisconsin' },
    { key: 'WY', value: 'Wyoming' }
];
const usTerritories = [
    { key: 'PR', value: 'Puerto Rico' },
    { key: 'VI', value: 'Virgin Islands' }
];
const armedForces = [
    { key: 'AA', value: 'Armed Forces America' },
    { key: 'AP', value: 'Armed Forces Pacific' },
    { key: 'AE', value: 'Armed Forces All Other' }
];
let AddressService = class AddressService {
    constructor(http) {
        this.http = http;
        /**
         * url for global address standardization service
         *
         * cache service responses
         */
        this.responseCache = new Map();
    }
    /**
    * Caches validation request by provided Address key
    * @param trilliumConfig
    * @param requestAddress
    */
    standardizeAddress(addressValidationConfig, requestAddress, fieldName) {
        // create a cache key based on submitted address data
        const address = this.getAddressForStandardize(requestAddress, fieldName);
        const cacheKey = Address.formatAddressString(address);
        const responseFromCache = this.responseCache.get(cacheKey);
        // if we already have a cache entry for this address then return it
        if (responseFromCache) {
            return of(responseFromCache);
        }
        const payload = {
            request: [this.mapAddressForStandardize(address)]
        };
        // make a service request w/passed address
        const response = this.submitRequest(addressValidationConfig, payload);
        // cache the response by address key
        response.subscribe(results => this.responseCache.set(cacheKey, results));
        return response;
    }
    /**
     * this method maps the request which IBA address service expects.
     * The reason for this method is, our existing address model and IBM address request payload have different field names.
     * Ex: our model have addressLine1 and IBM api expects in addressLineOne
     * @param address
     */
    mapAddressForStandardize(address) {
        const request = new Address();
        /*
        * In case of multiple address validations in single request, the sequenceNo below should be unique for each address.
        * As we are requesting for one address each time, so hard coded it to '1'
        * */
        request.sequenceNo = '1';
        request.addressLineOne = address.addressLine1;
        if (address.addressLine2) {
            request.addressLineTwo = address.addressLine2;
        }
        request.city = address.city;
        request.state = address.state;
        request.postalCode = address.zipCode;
        return request;
    }
    /**
     * return address object for standardize
     * @param requestAddress
     * @param fieldName
     */
    getAddressForStandardize(requestAddress, fieldName) {
        let address;
        if (fieldName && requestAddress) {
            address = new Address();
            address.addressLine1 = requestAddress[fieldName + 'AddressLine1'];
            address.city = requestAddress[fieldName + 'City'];
            address.state = requestAddress[fieldName + 'State'];
            address.zipCode = requestAddress[fieldName + 'ZipCode'];
        }
        else {
            address = new Address(requestAddress);
        }
        return address;
    }
    /**
     * Submits request to address validation service
     * @param addressValidationConfig
     * @param requestBody
     */
    submitRequest(addressValidationConfig, requestBody) {
        let params = new HttpParams();
        params = params.set('version', addressValidationConfig.version);
        params = params.set('client_id', addressValidationConfig.clientId);
        if (addressValidationConfig.sessionEnv) {
            params = params.set('session_env', addressValidationConfig.sessionEnv);
        }
        // do we need to specify a target env?
        const targetEnv = addressValidationConfig.targetEnv;
        if (targetEnv !== '') {
            params = params.set('target_env', targetEnv);
        }
        const headerOptions = {
            'Content-Type': 'application/json'
        };
        // use ExtendedHttpHeaders to bypass default HttpInterceptor error handling to not redirect user to error if service down
        const headers = new ExtendedHttpHeaders(headerOptions);
        headers.errorHandler = this.handleError;
        const httpOptions = {
            headers: headers,
            params: params
        };
        return this.http.post(addressValidationConfig.endpointUrl, requestBody, httpOptions)
            .pipe(shareReplay(1), map((response) => {
            return response;
        }), catchError(this.handleError));
    }
    /**
     * custom error handler for bubbling up error returned from service
     * @param request
     */
    handleError(request) {
        return throwError(request);
    }
    /**
     * return all the states including US territories and military
     */
    getAllStates() {
        return usOnlyStates.concat(usTerritories, armedForces);
    }
    /**
     * return US Only states
     */
    getUSOnlyStates() {
        return usOnlyStates;
    }
};
AddressService.ctorParameters = () => [
    { type: HttpClient }
];
AddressService.ɵprov = ɵɵdefineInjectable({ factory: function AddressService_Factory() { return new AddressService(ɵɵinject(HttpClient)); }, token: AddressService, providedIn: "root" });
AddressService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [HttpClient])
], AddressService);

let AddressComponent = class AddressComponent {
    constructor(formUtils, ref, fb, eventAggregatorService, addressService, tealiumDataService) {
        this.formUtils = formUtils;
        this.ref = ref;
        this.fb = fb;
        this.eventAggregatorService = eventAggregatorService;
        this.addressService = addressService;
        this.tealiumDataService = tealiumDataService;
        this.field = {
            'type': 'address',
            'name': '',
            'isTealiumAllowed': true,
            'label': 'Mailing Address',
            'showField': true,
            'googleAutofill': false,
            'showApt': false,
            'aptFieldLabel': 'Apt / Suite #',
            'showAddressLine2': false,
            'addressLine2Label': 'Address Line 2 (optional)'
        };
        /** real-time postal address standardization / validation **/
        this.standardizeAddress = false; // default to off
        this.warningTextHeadline = 'Please Verify';
        this.warningTextMessage = 'We could not match this address with a known address. Please verify.';
        this.verificationHeader = 'Is this address correct?';
        this.verificationBody = 'We matched your address to the following:';
        // RBAL_159: allow the user to proceed even if we don't have a match on the 2nd attempt
        this.standardizationAttempts = 0;
        // model data
        this.formData = {};
        /**
         * Subscription property
         */
        this.subsManager = new Subscription();
        /**
         * hasError holds boolean value for each fields in address component
         */
        this.hasError = {};
        /**
         * hasError holds error messages for each fields in address component
         */
        this.errorMessage = {};
        /**
         * all the possible address fields, required for dynamic control creation and validations
         */
        this.addressFields = ['addressLine1', 'city', 'state', 'zipCode', 'apt', 'addressLine2'];
        this.messageConfig = {
            name: 'standardizeMessage',
            type: 'messaging',
            showField: true
        };
    }
    ngOnInit() {
        // create new instance for maintaining form value state
        this.addressValidations = {
            addressLine1: [{
                    name: 'required',
                    message: 'Please enter an address.'
                }],
            city: [{
                    name: 'required',
                    message: 'Please enter a city.'
                }],
            state: [{
                    name: 'required',
                    message: 'Please select a state.'
                }],
            zipCode: [{
                    name: 'minLength',
                    minLength: 5,
                    message: 'Please enter a 5-digit ZIP code.'
                }, {
                    name: 'maxLength',
                    minLength: 5,
                    message: 'Please enter a 5-digit ZIP code.'
                }, {
                    name: 'required',
                    message: 'Please enter a 5-digit ZIP code.'
                }],
        };
        if (this.field && this.field.patternMatch) {
            this.addressValidations.addressLine1.push({
                name: 'pattern',
                pattern: this.field.patternMatch.pattern,
                message: this.field.patternMatch.patternMessage,
                globalModifiers: this.field.patternMatch.globalModifiers || ''
            });
        }
        /**
         * set the state list based on the US Only states flag
         * or all states
         */
        if (this.field.showUSOnlyStates) {
            this.states = this.addressService.getUSOnlyStates();
        }
        else {
            this.states = this.addressService.getAllStates();
        }
        /**
         * was a FieldConfig passed w/standardizeAddress property?
         */
        if (this.field.standardizeAddress) {
            this.standardizeAddress = this.field.standardizeAddress;
        }
        /**
         * was a FieldConfig passed w/standardizeAddress property?
         */
        if (this.field.googleAutofill) {
            this.googleAutofill = this.field.googleAutofill;
        }
        /**
         * was a FieldConfig passed w/addressValidationConfig property?
         */
        if (this.field.addressValidationConfig) {
            this.addressValidationConfig = this.field.addressValidationConfig;
        }
        /**
        * was a FieldConfig passed w/warningTextHeadline property?
        */
        if (this.field.warningTextHeadline) {
            this.warningTextHeadline = this.field.warningTextHeadline;
        }
        /**
        * was a FieldConfig passed w/warningTextMessage property?
        */
        if (this.field.warningTextMessage) {
            this.warningTextMessage = this.field.warningTextMessage;
        }
        if (!this.id && this.field.name) {
            this.id = this.field.name;
        }
        this.subscribeEventAggregator();
        this.createControl();
        /**
         * set up listeners for address standardization service
         */
        this.subscribeAddressStandarization();
    }
    ngOnChanges(changes) {
        if (changes && changes.field && this.field.value) {
            this.formData = this.field.value;
        }
    }
    /**
     * are we using the address standardization service?
     */
    subscribeAddressStandarization() {
        if (this.standardizeAddress) {
            this.group.addControl('qualityCode', new FormControl(null, [Validators.max(0)]));
            // subscribe to validation events from the parent component (eg: when Continue/Submit button is clicked)
            this.subsManager.add(this.eventAggregatorService.subscribe('validateFormForAdvancement', (payload) => {
                this.group.removeControl('qualityCode');
                // RBAL_155: only make validation service request if all address fields entered are valid
                if (this.isFormValid()) {
                    // add hidden control to control form group validity if address service returns invalid matched address
                    this.group.addControl('qualityCode', new FormControl(null, [Validators.max(0)], this.validateAddress.bind(this)));
                    this.standardizationAttempts += 1;
                }
            }));
            /**
             * This event handling required if once AddressStandarization message shown and we need to reset from the application
             */
            this.subsManager.add(this.eventAggregatorService.subscribe(this.field.name + ':resetAddressStandarizationMessage', (payload) => {
                if (payload && payload.qualityCode >= 0) {
                    this.standardizationAttempts = payload.standardizationAttempts;
                    this.qualityCode = payload.qualityCode;
                }
                else {
                    this.standardizationAttempts = 0;
                    this.qualityCode = 0;
                }
            }));
        }
    }
    /**
     * method return form validity for address validations
     */
    isFormValid() {
        // ensure all required fields are present in the form group prior to validating
        for (const field of this.addressFields) {
            if (field && this.group && this.group.controls[this.getFieldControlName(field)]
                && this.group.controls[this.getFieldControlName(field)].invalid) {
                return false;
            }
        }
        return this.group.valid;
    }
    /**
     * subscribeEventAggregator subscribe broadcasted event for address validations.
     */
    subscribeEventAggregator() {
        // subscribe to validation events from form engine parent component
        this.subsManager.add(this.eventAggregatorService.subscribe('validateAddressForFormEngine', (payload) => {
            this.createControl(true);
        }));
    }
    /**
     * Calls address standardization / validation service, updates form group value w/validated address if a match was made
     *
     * Alerts user to non-matches and allows user to update address and re-validate or proceed without any changes
     */
    validateAddress(control) {
        // prevent duplicate service requests from Angular async validator getting called multiple times
        if (control.status === 'PENDING') {
            return of$1(null);
        }
        /**
         * was a FieldConfig passed w/addressValidationConfig property?
         */
        if (!(this.addressValidationConfig && this.addressValidationConfig.endpointUrl) && this.field.addressValidationConfig) {
            this.addressValidationConfig = this.field.addressValidationConfig;
        }
        // call global address standardization service
        return this.addressService.standardizeAddress(this.addressValidationConfig, this.group.value, this.field.name).pipe(map(res => {
            if (res && res.addresses && res.addresses.length > 0) {
                this.cleansedLocation = res.addresses[0];
                /*
                * IBM address response fields are different from our model, so mapping those field values into the existing fields.
                * */
                this.cleansedLocation.addressLine1 = this.cleansedLocation.addressLineOne;
                this.cleansedLocation.addressLine2 = this.cleansedLocation.addressLineTwo;
                this.cleansedLocation.zipCode = this.cleansedLocation.postalCode;
                this.cleansedLocation.qualityCode = this.cleansedLocation.addressCleanse;
                /**
                 * if standardizeAddressEvent passed in the field config broadcast cleansing response to injecting application
                 * Injecting application should have all the logic to handle
                 */
                if (this.field.standardizeAddressEvent) {
                    this.eventAggregatorService.broadcast(this.field.standardizeAddressEvent, {
                        cleansedResponse: this.cleansedLocation,
                        field: this.field,
                        address: this.mapAddressValues(this.cleansedLocation),
                        standardizationAttempts: this.standardizationAttempts,
                        qualityCode: this.qualityCode
                    });
                }
                else {
                    // set response quality code - this will show/hide warning message
                    this.qualityCode = Number(this.cleansedLocation.addressCleanse);
                    this.group.get('qualityCode').patchValue(this.qualityCode, { emitEvent: false });
                    // RBAL_156: replace user entered address field data w/validation service data if qualityCode is zero
                    if (this.qualityCode === 0) {
                        // show verification modal if specified
                        if (this.field.showAddressVerificationModal) {
                            // if we have already tried to standardize, dont show modal
                            if (this.standardizationAttempts <= 1) {
                                this.verificationModalRef.show();
                                // patch invalid quality code value to prevent continue
                                this.group.get('qualityCode').patchValue(1, { emitEvent: false });
                                return { 'qualityCode': this.qualityCode };
                            }
                        }
                        else {
                            this.patchValues();
                        }
                    }
                    else {
                        if (this.standardizationAttempts < 2) {
                            this.tealiumDataService.addImpressionEvent({
                                'event_parent': 'Page Tag',
                                'event_type': 'Warning Message',
                                'event_id': this.warningTextMessage,
                                'event_value': top.location.href,
                                'da_track': true
                            });
                        }
                    }
                    // RBAL_159: allow the user to proceed even if we don't have a match on the 2nd attempt
                    if (this.standardizationAttempts > 1) {
                        // RBAL_159: allow the user to proceed even if we don\'t have a match on the 2nd attempt
                        this.group.get('qualityCode').patchValue(0, { emitEvent: false });
                        return null;
                    }
                    else {
                        // RBAL_157: if value > 0 then form group will be invalid
                        // the user will not be able to advance and show the warning message will display
                        const isValid = (this.qualityCode === 0) ? null : { 'qualityCode': this.qualityCode };
                        return isValid;
                    }
                }
            }
        }), catchError(() => {
            // RBAL_160: if the service returns a error, allow the user to proceed
            return of$1(null);
        }));
    }
    /**
     * Broadcast any time a field is changed so the application can react based on which field it is
     * @param fieldName
     * @param event
     */
    broadcastFieldEvent(fieldName, event) {
        if (this.field.broadcastAddressFieldEvents && this.field.eventName) {
            // let the application know an address field was changed and provide the formData
            // uses addressFieldChange so application knows why this was fired
            this.eventAggregatorService.broadcast(this.field.eventName, { field: this.field, address: this.formData, addressFieldChange: true });
        }
        // call methods specific to this field
        switch (fieldName) {
            case 'googleAddress':
                this.handleAddressChange(event);
                break;
            case 'addressLine1':
                this.analyticsUpdate('Textbox', this.field.label);
                break;
            case 'addressLine2':
                this.analyticsUpdate('Textbox', this.field.addressLine2Label);
                break;
            case 'city':
                this.analyticsUpdate('Textbox', 'City');
                break;
            case 'state':
                this.stateChange();
                break;
            case 'zipCode':
                this.analyticsUpdate('Textbox', 'ZIP Code');
                break;
            default:
                break;
        }
    }
    /**
    * Close the verification modal and react based on user choice to accept or reject cleansed address
    * @param acceptCleanse
    */
    closeVerificationModal(acceptCleanse) {
        if (acceptCleanse) {
            this.patchValues();
            // set attempts to 2 so we don't try to re-verify
            this.standardizationAttempts = 2;
            this.verificationModalRef.hide();
            // remove quality code check and broadcast to application that user has accepted cleanse
            this.group.removeControl('qualityCode');
            this.eventAggregatorService.broadcast(this.field.name + ':acceptAddressCleanse', '');
        }
        else {
            // hide modal and let app now cleanse was rejected
            this.verificationModalRef.hide();
            this.eventAggregatorService.broadcast(this.field.name + ':rejectAddressCleanse', '');
        }
    }
    /**
    * On successful cleanse, patch values provided from cleansing API to the form
    */
    patchValues() {
        this.formData = this.mapAddressValues(this.cleansedLocation);
        this.standardizationAttempts = 0;
        // update form model values
        this.group.patchValue(this.formData, { emitEvent: false });
        // if a custom event was specified in the field config json, broadcast the updated address data
        // Added isStandardizeAddress in the payload to confirm this response from standardizeAddress api call
        if (this.field.eventName) {
            this.eventAggregatorService.broadcast(this.field.eventName, { field: this.field,
                address: this.formData, isStandardizeAddress: true });
        }
        this.ref.detectChanges();
    }
    /**
     * map address fields value with formData
     * @param address
     */
    mapAddressValues(address) {
        const mappedFormData = {};
        if (address) {
            for (const addressField of this.addressFields) {
                if (address[addressField]) {
                    if (addressField === 'zipCode' && address[addressField] && address[addressField].length > 5) {
                        mappedFormData[this.getFieldControlName(addressField)] = address[addressField].substr(0, 5);
                    }
                    else {
                        mappedFormData[this.getFieldControlName(addressField)] = address[addressField];
                    }
                }
            }
        }
        return mappedFormData;
    }
    stateChange() {
        // broadcast state change for form engine
        if (this.field && this.field.value && this.group.get(this.getFieldControlName('state'))) {
            this.field.value[this.getFieldControlName('state')] = this.group.get(this.getFieldControlName('state')).value;
            this.eventAggregatorService.broadcast(this.field.eventName, { field: this.field, address: this.field.value });
            if (this.field.isTealiumAllowed) {
                this.analyticsUpdate('Select', 'State', this.field.value[this.getFieldControlName('state')]);
            }
        }
    }
    /**
     * Google Address method used to set form address fields from selected Google Place response object
     * @param response Google Place response object: https://developers.google.com/places/web-service/details
     */
    handleAddressChange(response) {
        // set formatted place values from service response data
        if (response) {
            for (const field of this.addressFields) {
                // if selected address field value not available in the response set it as blank string
                if (response[field]) {
                    this.formData[this.getFieldControlName(field)] = response[field];
                }
                else {
                    this.formData[this.getFieldControlName(field)] = '';
                }
            }
            // update form model values
            this.group.patchValue(this.formData, { emitEvent: false });
            // store reference to updated address value for form engine field config
            this.field.value = this.formData;
            // if a custom event was specified in the field config json, broadcast the updated address data
            if (this.field.eventName) {
                this.eventAggregatorService.broadcast(this.field.eventName, { field: this.field, address: this.formData });
            }
            if (this.field.isTealiumAllowed) {
                this.tealiumDataService.addImpressionEvent({
                    'event_parent': 'Page Tag',
                    'event_type': 'Textbox',
                    'event_id': 'Google Autocomplete Selected',
                    'event_value': top.location.href,
                    'da_track': true
                });
            }
            this.ref.detectChanges();
        }
    }
    /**
     * sets validation errorMessage for the invalid field
     * @param fieldName
     */
    validateError(fieldName) {
        /**
         * Get the right field name
         */
        const updatedFieldName = this.getFieldControlName(fieldName);
        if (this.field && this.group && this.group.controls && this.group.controls[updatedFieldName]
            && this.group.controls[updatedFieldName].touched) {
            for (const validation of this.addressValidations[fieldName]) {
                if (this.group && this.group.get(updatedFieldName).hasError(validation.name.toLowerCase())) {
                    this.hasError[updatedFieldName] = true;
                    this.errorMessage[updatedFieldName] = validation.message;
                    break;
                }
                else {
                    this.hasError[updatedFieldName] = false;
                    this.errorMessage[updatedFieldName] = null;
                }
            }
        }
        else {
            this.hasError[updatedFieldName] = false;
            this.errorMessage[updatedFieldName] = null;
        }
        return this.hasError[updatedFieldName];
    }
    /**
     * create form controls for the address component
     * @param updated
     */
    createControl(updated) {
        // if value exist in the fieldConfig assign it to formData
        if (this.field.value) {
            this.formData = this.field.value;
        }
        for (const addressField of this.addressFields) {
            if ((this.field.showApt && addressField === 'apt') || (this.field.showAddressLine2 && addressField === 'addressLine2')
                || (addressField !== 'apt' && addressField !== 'addressLine2')) {
                if (updated && !this.field.showField) {
                    this.group.removeControl(this.getFieldControlName(addressField));
                }
                else if (this.field.showField && !this.group.get(this.getFieldControlName(addressField))) {
                    const formCreationParam = {
                        formGroup: this.group,
                        field: this.field,
                        fieldValue: this.formData[this.getFieldControlName(addressField)],
                        fieldName: this.getFieldControlName(addressField),
                        validations: this.addressValidations[addressField]
                    };
                    this.formUtils.createFormControl(formCreationParam);
                }
            }
        }
        /**
         * remove quality code if this.field.showField is false
         */
        if (!this.field.showField) {
            this.group.removeControl('qualityCode');
        }
    }
    /**
     * return control name for the selected field
     * @param fieldName
     */
    getFieldControlName(fieldName) {
        if (this.field && this.field.name) {
            switch (fieldName) {
                case 'addressLine1':
                    return this.field.name + 'AddressLine1';
                case 'city':
                    return this.field.name + 'City';
                case 'state':
                    return this.field.name + 'State';
                case 'zipCode':
                    return this.field.name + 'ZipCode';
                case 'apt':
                    return this.field.name + 'Apt';
                case 'addressLine2':
                    return this.field.name + 'AddressLine2';
            }
        }
        return fieldName;
    }
    analyticsUpdate(eventLabel, eventId, eventValue) {
        if (this.field.isTealiumAllowed) {
            this.tealiumDataService.addImpressionEvent({
                'event_parent': 'Page Tag',
                'event_type': eventLabel,
                'event_id': eventId,
                'event_value': eventValue ? eventValue : window.location.href,
                'da_track': true
            });
        }
    }
    ngOnDestroy() {
        // remove the async validator on destroy
        if (this.group.get('qualityCode')) {
            this.group.removeControl('qualityCode');
        }
        if (this.subsManager) {
            this.subsManager.unsubscribe();
        }
    }
};
AddressComponent.ctorParameters = () => [
    { type: FormUtilitiesService },
    { type: ChangeDetectorRef },
    { type: FormBuilder },
    { type: EventAggregatorService },
    { type: AddressService },
    { type: TealiumDataService }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], AddressComponent.prototype, "addressValidationConfig", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], AddressComponent.prototype, "googleAutofill", void 0);
__decorate([
    Input(),
    __metadata("design:type", FormGroup)
], AddressComponent.prototype, "group", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AddressComponent.prototype, "field", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], AddressComponent.prototype, "id", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AddressComponent.prototype, "standardizeAddress", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AddressComponent.prototype, "warningTextHeadline", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AddressComponent.prototype, "warningTextMessage", void 0);
__decorate([
    ViewChild('verificationModal'),
    __metadata("design:type", CustomModalComponent)
], AddressComponent.prototype, "verificationModalRef", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AddressComponent.prototype, "verificationHeader", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AddressComponent.prototype, "verificationBody", void 0);
AddressComponent = __decorate([
    Component({
        selector: 'lib-address',
        template: "<!-- Address validation message -->\n<ng-container *ngIf=\"qualityCode > 0 && field.showField\">\n  <lib-messaging [message]=\"{messageType: 'warning', messageTitle: warningTextHeadline, messageText: warningTextMessage }\"\n    [field]=\"messageConfig\" id=\"{{id}}-address-validation-warning\"></lib-messaging>\n</ng-container>\n<!-- Address fields container -->\n<div [formGroup]=\"group\" *ngIf=\"field.showField\">\n  <div class=\"input-fields-row field-selectors-row\">\n    <!-- Container to show APT field based on the field.showApt -->\n    <ng-container *ngIf=\"field.showApt; else addressLine1Ref\">\n      <div class=\"row\">\n        <div class=\"col-xs-12 col-sm-9 addressLine1-container\">\n          <ng-container [ngTemplateOutlet]=\"addressLine1Ref\"></ng-container>\n        </div>\n        <div class=\"col-xs-12 col-sm-3 apt-container\">\n          <div class=\"form-group\">\n            <label for=\"{{id}}-{{getFieldControlName('apt')}}\" class=\"control-label\">{{field.aptFieldLabel}}</label>\n            <input type=\"text\" [formControlName]=\"getFieldControlName('apt')\" class=\"form-control\" id=\"{{id}}-{{getFieldControlName('apt')}}\"\n            (change)=\"analyticsUpdate('Textbox', field.aptFieldLabel)\">\n          </div>\n        </div>\n      </div>\n    </ng-container>\n    <!-- addressLine1 template -->\n    <ng-template #addressLine1Ref>\n      <div class=\"form-group form-field-list\" libFormGroupHighlight [ngClass]=\"{'ng-invalid has-error':validateError('addressLine1')}\">\n          <label for=\"{{id}}-{{getFieldControlName('addressLine1')}}\" class=\"control-label\">{{field.label}}</label>\n          <!-- addressLine1 field with google autocomplete  -->\n          <ng-container *ngIf=\"googleAutofill; else withoutGoogle\">\n            <input type=\"text\"\n                    libGoogleAutocomplete\n                    autocomplete=\"off\"\n                    (addressChange)=\"broadcastFieldEvent('googleAddress', $event)\"\n                    [formControlName]=\"getFieldControlName('addressLine1')\" id=\"{{id}}-{{getFieldControlName('addressLine1')}}\"\n                    class=\"form-control\"/>\n          </ng-container>\n          <!-- addressLine1 field without google autocomplete  -->\n          <ng-template #withoutGoogle>\n            <input type=\"text\"\n                    required\n                    [formControlName]=\"getFieldControlName('addressLine1')\" id=\"{{id}}-{{getFieldControlName('addressLine1')}}\"\n                    class=\"form-control\"\n                    (change)=\"broadcastFieldEvent('addressLine1')\"/>\n          </ng-template>\n          <lib-validation-error *ngIf=\"hasError[getFieldControlName('addressLine1')]\" [message]=\"errorMessage[getFieldControlName('addressLine1')]\"></lib-validation-error>\n      </div>\n    </ng-template>\n    <!-- Optional AddressLine2 field container-->\n    <div class=\"row addressLine2-container\" *ngIf=\"field.showAddressLine2\">\n      <div class=\"col-xs-12\" [ngClass]=\"{'col-sm-9': field.showApt}\">\n        <div class=\"form-group\">\n          <label for=\"{{id}}-{{getFieldControlName('addressLine2')}}\" class=\"control-label\">{{field.addressLine2Label}}</label>\n          <input type=\"text\" [formControlName]=\"getFieldControlName('addressLine2')\" class=\"form-control\" id=\"{{id}}-{{getFieldControlName('addressLine2')}}\"\n          (change)=\"broadcastFieldEvent('addressLine2')\">\n        </div>\n      </div>\n    </div>\n    <!-- Container for the City, state and zipCode -->\n    <div class=\"row\">\n      <!-- City container -->\n      <div class=\"col-xs-12 col-sm-5 city-container\">\n        <div class=\"form-group\" libFormGroupHighlight [ngClass]=\"{'ng-invalid has-error':validateError('city')}\">\n          <label for=\"{{id}}-{{getFieldControlName('city')}}\" class=\"control-label\">City</label>\n          <input type=\"text\" [formControlName]=\"getFieldControlName('city')\" class=\"form-control\" id=\"{{id}}-{{getFieldControlName('city')}}\" name=\"city\" maxlength=\"50\"\n          (change)=\"broadcastFieldEvent('city')\">\n          <lib-validation-error *ngIf=\"hasError[getFieldControlName('city')]\" [message]=\"errorMessage[getFieldControlName('city')]\"></lib-validation-error>\n        </div>\n      </div>\n      <!-- State container -->\n      <div class=\"col-xs-12 col-sm-4 state-container\">\n        <div class=\"form-group\" libFormGroupHighlight [ngClass]=\"{'ng-invalid has-error':validateError('state')}\">\n          <label for=\"{{id}}-{{getFieldControlName('state')}}\" class=\"control-label custom-label-one\">State</label>\n          <div class=\"select-container\">\n            <select class=\"state form-control\" id=\"{{id}}-{{getFieldControlName('state')}}\" name=\"select\" [formControlName]=\"getFieldControlName('state')\"\n                    (change)=\"broadcastFieldEvent('state')\">\n              <option [ngValue]=\"null\" selected=\"selected\" hidden>Please Select</option>\n              <option *ngFor=\"let state of states\" value=\"{{state.key}}\">{{state.value}}</option>\n            </select>\n            <lib-validation-error *ngIf=\"hasError[getFieldControlName('state')]\"  [message]=\"errorMessage[getFieldControlName('state')]\"></lib-validation-error>\n          </div>\n        </div>\n      </div>\n      <!-- zipCode container -->\n      <div class=\"col-xs-12 col-sm-3 zipCode-container\">\n        <div class=\"form-group\" libFormGroupHighlight [ngClass]=\"{'ng-invalid has-error':validateError('zipCode')}\">\n          <label for=\"{{id}}-{{getFieldControlName('zipCode')}}\" class=\"control-label\">ZIP Code</label>\n          <input type=\"text\" [formControlName]=\"getFieldControlName('zipCode')\" class=\"form-control\" id=\"{{id}}-{{getFieldControlName('zipCode')}}\"\n                 data-min=\"true\" libNumbersOnly [onlyNumber]=\"true\" [zipCode]=\"true\" maxlength=\"5\" (change)=\"broadcastFieldEvent('zipCode')\">\n          <lib-validation-error *ngIf=\"hasError[getFieldControlName('zipCode')]\"  [message]=\"errorMessage[getFieldControlName('zipCode')]\"></lib-validation-error>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n<lib-custom-modal class=\"verification-modal\" [showHeader]=\"false\" #verificationModal>\n  <ng-container class=\"app-modal-body\" *ngIf=\"cleansedLocation\">\n    <h3>{{verificationHeader}}</h3>\n    <p>{{verificationBody}}</p>\n    <p>\n      <strong>{{cleansedLocation.addressLine1 | titlecase}}</strong>\n      <br>\n      <strong>{{cleansedLocation.city | titlecase}}, {{cleansedLocation.state}} {{cleansedLocation.zipCode}}</strong>\n    </p>\n    <p>Is this correct?</p>\n  </ng-container>\n  <ng-container class=\"app-modal-footer\">\n    <button id=\"ngKit-button-{{id}}-verificationModal-no\" class=\"btn btn-link\" (click)=\"closeVerificationModal(false)\">No</button>\n    <button id=\"ngKit-button-{{id}}-verificationModal-yes\" class=\"btn btn-primary\" (click)=\"closeVerificationModal(true)\">Yes, this is correct</button>\n  </ng-container>\n</lib-custom-modal>\n",
        styles: [".verification-modal .btn.btn-link{float:left;padding-left:0}.verification-modal .btn.btn-primary{margin-left:0}.verification-modal .remove-btn{margin-top:0}"]
    }),
    __metadata("design:paramtypes", [FormUtilitiesService,
        ChangeDetectorRef,
        FormBuilder,
        EventAggregatorService,
        AddressService,
        TealiumDataService])
], AddressComponent);

var AddressModule_1;
let AddressModule = AddressModule_1 = class AddressModule {
    static forRoot(config) {
        return {
            ngModule: AddressModule_1,
            providers: [
                GoogleAutocompleteService,
                {
                    provide: ApiKeyConfigService,
                    useValue: config
                }
            ]
        };
    }
};
AddressModule = AddressModule_1 = __decorate([
    NgModule({
        imports: [
            CommonModule,
            ReactiveFormsModule,
            FormsModule,
            FormHelperModule,
            InfoFieldsModule,
            InputModule,
            GoogleAutocompleteModule,
            CustomModalModule,
            TealiumModule.forRoot(),
        ],
        declarations: [
            AddressComponent
        ],
        exports: [
            AddressComponent
        ],
        entryComponents: [AddressComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
], AddressModule);

let TabComponent = class TabComponent {
    constructor() {
        this.icon = '';
        this.active = false;
        this.isLoaded = false;
        this.accTabChange = new EventEmitter();
    }
    selectTab(tab) {
        if (tab.active) {
            // selected tab is active tab, close it
            tab.active = false;
        }
        else {
            // load new tab and close existing active tab
            this.accTabChange.emit(tab);
        }
    }
};
__decorate([
    Input(),
    __metadata("design:type", Object)
], TabComponent.prototype, "icon", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], TabComponent.prototype, "customClass", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], TabComponent.prototype, "tabTitle", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], TabComponent.prototype, "url", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], TabComponent.prototype, "active", void 0);
__decorate([
    ViewChild('container', { read: ViewContainerRef }),
    __metadata("design:type", Object)
], TabComponent.prototype, "dynamicTabPlaceholder", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], TabComponent.prototype, "accTabChange", void 0);
TabComponent = __decorate([
    Component({
        selector: 'lib-tab',
        template: "<div [hidden]=\"!active\" class=\"tab-pane\">\n  <div class=\"panel panel-primary\">\n    <a class=\"accordion-toggle\" [class.collapsed]=\"!active\" (click)=\"selectTab(this)\" id=\"ngKit-select-Tab\">\n      <div class=\"panel-heading\">\n        <h3 class=\"panel-title\">\n          <span class=\"panel-title-text\">{{tabTitle}}</span>\n          <i class=\"icon icon-caret-down pull-right\"></i>\n        </h3>\n      </div>\n    </a>\n    <div class=\"panel-collapse collapse\" [class.in]=\"active\">\n      <div class=\"panel-body\">\n        <ng-content></ng-content>\n        <ng-template #container></ng-template>\n      </div>\n    </div>\n  </div>\n</div>\n",
        styles: ["@media (max-width:767px){.tab-pane a{cursor:pointer;text-decoration:none}.tab-pane a.active{cursor:none}.tab-pane .collapse{display:none}.tab-pane .collapse.in{display:block}}"]
    }),
    __metadata("design:paramtypes", [])
], TabComponent);

let TabsComponent = class TabsComponent {
    constructor(router, componentFactoryResolver) {
        this.router = router;
        this.componentFactoryResolver = componentFactoryResolver;
        this.unsubscribe = new Subject();
        this.subscribeToRouteEvents = true;
        this.tabChange = new EventEmitter();
    }
    ngOnInit() {
        // select tab based on current url
        if (this.subscribeToRouteEvents) {
            this.routerSubscription = this.router.events.pipe(filter(e => e instanceof NavigationEnd))
                .pipe(takeUntil(this.unsubscribe))
                .subscribe((e) => {
                this.markActiveTab();
            });
        }
    }
    ngAfterContentInit() {
        // mark active tab after initialization
        this.markActiveTab();
        if (this.tabs && this.tabs.length) {
            this.tabs.forEach((item) => {
                // listen for tab select events so we can dynamically load the component
                item.accTabChange
                    .pipe(takeUntil(this.unsubscribe))
                    .subscribe((tab) => {
                    this.selectTab(tab);
                    this.tabChange.emit(tab);
                });
            });
        }
    }
    /**
     * Loops through tabs and selects active tab based on status or current url
     */
    markActiveTab() {
        if (this.tabs && this.tabs.length) {
            // get the first active tab found
            let activeTab = this.tabs.find((tab) => {
                if (tab.url) {
                    return this.router.isActive(tab.url, false);
                }
                else {
                    return tab.active;
                }
            });
            if (!activeTab) {
                // if there is no active tab set, activate the first
                activeTab = this.tabs.first;
            }
            // mark the tab as active
            this.selectTab(activeTab);
            this.tabChange.emit(activeTab);
        }
    }
    loadComponent(tab, component, inputData) {
        // only load new component if not already loaded
        if (!tab.isLoaded) {
            try {
                // get a component factory for our passed component to load
                const componentFactory = this.componentFactoryResolver.resolveComponentFactory(component);
                // get a reference to the view container the component will be loaded into and clear it's current contents
                const viewContainerRef = tab.dynamicTabPlaceholder;
                viewContainerRef.clear();
                // create the new component instance
                const componentRef = viewContainerRef.createComponent(componentFactory);
                if (inputData) {
                    Object.keys(inputData).forEach(propertyName => {
                        componentRef.instance[propertyName] = inputData[propertyName];
                    });
                }
                // mark the tab as loaded so we don't load it again on future select
                tab.isLoaded = true;
            }
            catch (e) {
                throw new Error('Unable to load component from tabset');
            }
        }
    }
    // it selects the particular tab and activate
    selectTab(tab) {
        // deactivate all tabs
        this.tabs.toArray().forEach(item => item.active = false);
        // activate the tab the user has clicked on
        tab.active = true;
        // if a url is set then update history state
        if (tab.url) {
            this.router.navigate([tab.url], { queryParamsHandling: 'merge' });
        }
        else {
            this.tabChange.emit(tab);
        }
    }
    ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
};
TabsComponent.ctorParameters = () => [
    { type: Router },
    { type: ComponentFactoryResolver }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], TabsComponent.prototype, "subscribeToRouteEvents", void 0);
__decorate([
    ContentChildren(TabComponent),
    __metadata("design:type", QueryList)
], TabsComponent.prototype, "tabs", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], TabsComponent.prototype, "tabChange", void 0);
TabsComponent = __decorate([
    Component({
        selector: 'lib-tabs',
        template: "<div class=\"tab-accordion\">\n  <div class=\"nav-tabs-wrapper\" data-overflow=\"tab\" id=\"Tabs_Container\">\n    <ul class=\"nav nav-tabs\">\n      <li *ngFor=\"let tab of tabs; let i = index\" (click)=\"selectTab(tab)\" [class.active]=\"tab.active\" [ngClass]=\"tab.customClass\">\n        <a id=\"ngKit-tab-{{i}}\"><i [ngClass]=\"['icon', tab.icon]\"></i>{{tab.tabTitle}}</a>\n      </li>\n    </ul>\n  </div>\n  <div class=\"tab-content\">\n    <ng-content></ng-content>\n  </div>\n</div>\n",
        styles: [".nav-tabs .icon{display:none}.nav-tabs .icon::after{content:\" \";white-space:pre-wrap}.nav-tabs a{cursor:pointer}.nav-tabs a.active{cursor:none}"]
    }),
    __metadata("design:paramtypes", [Router, ComponentFactoryResolver])
], TabsComponent);

let TabsModule = class TabsModule {
};
TabsModule = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        exports: [
            TabsComponent,
            TabComponent
        ],
        declarations: [
            TabsComponent,
            TabComponent
        ]
    })
], TabsModule);

let BreadcrumbService = class BreadcrumbService {
    constructor(router, activatedRoute) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        /**
         * Breadcrumbs with custom attributes; e.g. labels.
         * @note We keep track of custom breadcrumbs because we rebuild the breadcrumbs
         * every single time the route changes; if we did not, then our set breadcrumbs
         * would be overwritten when the screen changes.
         */
        this._customBreadcrumbs = [];
        /** List of current breadcrumbs */
        this._currentBreadcrumbs = [];
        /** Our BehaviorSubject of the current breadcrumbs */
        this._breadcrumbs = new BehaviorSubject([]);
        /** Observable list of the current breadcrumbs */
        this.breadcrumbs$ = this._breadcrumbs.asObservable();
        /** Should we include the root label */
        this._includeRoot = true;
        /** The root label */
        this._rootLabel = 'Home';
        this.detectRouterChanges();
    }
    /** Listen to Router events and updates the Breadcrumbs accordingly */
    detectRouterChanges() {
        this.router.events.pipe(filter(event => event instanceof NavigationCancel || event instanceof NavigationEnd), distinctUntilChanged()).subscribe(() => {
            this._currentBreadcrumbs = this.buildBreadcrumb(this.activatedRoute.root);
            this._breadcrumbs.next(this._currentBreadcrumbs);
        });
    }
    /**
     * Allows the ability to set a custom label on a given alias.
     * Aliases are defined in the RouteConfig and are prefixed with an '@' symbol,
     * For example: { data: { breadcrumb: { label: 'Summary List', alias: '@summaryList' } } }
     */
    set(alias, label) {
        // Let's find the alias in the current breadcrumbs if it exists, otherwise do nothing
        const updateIndex = this._currentBreadcrumbs.findIndex(b => b.alias === alias);
        if (updateIndex >= 0) {
            // Let's see if we already set this breadcrumb to a custom value
            const predefinedIndex = this._customBreadcrumbs.findIndex(b => b.alias === alias);
            if (predefinedIndex >= 0) { // If we did, simply update it
                this._customBreadcrumbs[predefinedIndex] = { label, alias };
            }
            else { // If we haven't then let's push it to the customBreadcrumbs array
                this._customBreadcrumbs.push({ label, alias });
            }
            this._currentBreadcrumbs[updateIndex].label = label;
            this._breadcrumbs.next(this._currentBreadcrumbs);
        }
    }
    /**
     * Build your breadcrumb starting with the root route of your current activated route
     */
    buildBreadcrumb(route, url = '', breadcrumbs = []) {
        let path = '';
        let label = '';
        let alias = '';
        // If no routeConfig is available, we are on the root path
        if (route && route.routeConfig) {
            path = route.snapshot.url.join('/');
            // is there a label specified for this route? we only want to show items w/labels set
            if (route.routeConfig.data && route.routeConfig.data['breadcrumb']) {
                const breadcrumb = route.routeConfig.data['breadcrumb'];
                // If breadcrumb is a string, then it's just a label
                if (typeof breadcrumb === 'string') {
                    label = breadcrumb;
                }
                else { // Otherwise it is a BreadCrumb object
                    // Find a customized breadcrumb for an alias, if any.
                    const customBreadcrumb = this._customBreadcrumbs.find((cb) => {
                        return cb.alias === breadcrumb.alias;
                    });
                    if (customBreadcrumb) { // If we find a customized breadcrumb for the alias, use custom data
                        label = customBreadcrumb.label;
                        alias = customBreadcrumb.alias;
                    }
                    else { // Otherwise let's grab the default values from the route config
                        label = breadcrumb.label;
                        alias = breadcrumb.alias;
                    }
                }
            }
            else {
                // if there is no label set then we have nothing to show so exit fast and return existing crumbs
                if (!this.includeRoot) {
                    // remove the root route
                    breadcrumbs.shift();
                }
                return breadcrumbs;
            }
        }
        else { // root route reached
            label = this.rootLabel;
        }
        // In the routeConfig the complete path is not available,
        // so we rebuild it each time
        const nextUrl = `${url}${path}/`;
        const currentBreadcrumb = { url: nextUrl, label, alias };
        const newBreadcrumbs = [...breadcrumbs, currentBreadcrumb];
        if (route && route.firstChild) {
            // If we are not on our current path yet,
            // there will be more children to look after, to build our breadcrumb
            return this.buildBreadcrumb(route.firstChild, nextUrl, newBreadcrumbs);
        }
        if (!this.includeRoot) {
            // remove the root route
            newBreadcrumbs.shift();
        }
        return newBreadcrumbs;
    }
    set includeRoot(includeRoot) {
        this._includeRoot = includeRoot;
    }
    get includeRoot() {
        return this._includeRoot;
    }
    set rootLabel(rootLabel) {
        this._rootLabel = rootLabel;
    }
    get rootLabel() {
        return this._rootLabel;
    }
    get currentBreadCrumb() {
        return this._currentBreadcrumbs;
    }
    get customBreadCrumb() {
        return this._customBreadcrumbs;
    }
};
BreadcrumbService.ctorParameters = () => [
    { type: Router },
    { type: ActivatedRoute }
];
BreadcrumbService.ɵprov = ɵɵdefineInjectable({ factory: function BreadcrumbService_Factory() { return new BreadcrumbService(ɵɵinject(Router), ɵɵinject(ActivatedRoute)); }, token: BreadcrumbService, providedIn: "root" });
BreadcrumbService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [Router,
        ActivatedRoute])
], BreadcrumbService);

let BreadcrumbComponent = class BreadcrumbComponent {
    constructor(activatedRoute, router, breadcrumbService) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.breadcrumbService = breadcrumbService;
        this.rootLabel = 'Home';
        this.includeRoot = true;
        this.breadcrumbs = [];
    }
    navigateUrl(val) {
        // add query params to URL
        this.router.navigate([val], { queryParamsHandling: 'merge' });
    }
    ngOnInit() {
        this.breadcrumbService.rootLabel = this.rootLabel;
        this.breadcrumbService.includeRoot = this.includeRoot;
        this.breadcrumbService.breadcrumbs$.subscribe(breadcrumbs => {
            this.breadcrumbs = breadcrumbs;
        });
    }
};
BreadcrumbComponent.ctorParameters = () => [
    { type: ActivatedRoute },
    { type: Router },
    { type: BreadcrumbService }
];
__decorate([
    Input(),
    __metadata("design:type", Object)
], BreadcrumbComponent.prototype, "rootLabel", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], BreadcrumbComponent.prototype, "includeRoot", void 0);
BreadcrumbComponent = __decorate([
    Component({
        selector: 'lib-breadcrumb',
        template: "<ul class=\"breadcrumb\" id=\"Breadcrumb_Container_List\">\n  <ng-container *ngFor=\"let breadcrumb of breadcrumbs; last as isLast;\">\n    <li *ngIf=\"breadcrumb.label\" [ngClass]=\"{'active': isLast}\" aria-current=\"page\">\n      <a *ngIf=\"!isLast; else lastRoute\"\n          (click)=\"navigateUrl(breadcrumb.url)\"\n          routerLinkActive=\"active\">{{ breadcrumb.label }}</a>\n      <ng-template #lastRoute>{{ breadcrumb.label }}</ng-template>\n    </li>\n  </ng-container>\n</ul>\n",
        styles: ["@charset \"UTF-8\";.breadcrumb{list-style:none;background:0 0;border-radius:0;padding:0;margin-bottom:20px}.breadcrumb>li{display:inline-block}.breadcrumb>li+li:before{content:\"/\u00A0\";padding:0 5px}.breadcrumb>.active,.breadcrumb>li+li:before{color:#6b6b6b}.breadcrumb a{cursor:pointer}.breadcrumb>li+li::before{padding:0 5px 0 10px}"]
    }),
    __metadata("design:paramtypes", [ActivatedRoute,
        Router,
        BreadcrumbService])
], BreadcrumbComponent);

let BreadcrumbModule = class BreadcrumbModule {
};
BreadcrumbModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            RouterModule
        ],
        declarations: [
            BreadcrumbComponent,
        ],
        exports: [
            BreadcrumbComponent,
        ]
    })
], BreadcrumbModule);

let WizardStepComponent = class WizardStepComponent {
    constructor() {
        this.hidden = false;
        this.isValid = true;
        this.showNext = true;
        this.showPrev = true;
        this.stepCompleted = false;
        this.showProgress = true;
        this.onNext = new EventEmitter();
        this.onPrev = new EventEmitter();
        this.onComplete = new EventEmitter();
        this._isActive = false;
        this.isDisabled = true;
    }
    set isActive(isActive) {
        this._isActive = isActive;
        this.isDisabled = false;
    }
    get isActive() {
        return this._isActive;
    }
};
__decorate([
    Input(),
    __metadata("design:type", String)
], WizardStepComponent.prototype, "title", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardStepComponent.prototype, "hidden", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardStepComponent.prototype, "isValid", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardStepComponent.prototype, "showNext", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardStepComponent.prototype, "showPrev", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardStepComponent.prototype, "stepCompleted", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardStepComponent.prototype, "showProgress", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], WizardStepComponent.prototype, "url", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], WizardStepComponent.prototype, "onNext", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], WizardStepComponent.prototype, "onPrev", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], WizardStepComponent.prototype, "onComplete", void 0);
__decorate([
    Input('isActive'),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], WizardStepComponent.prototype, "isActive", null);
WizardStepComponent = __decorate([
    Component({
        selector: 'lib-wizard-step',
        template: `
    <div *ngIf="isActive">
      <ng-content></ng-content>
    </div>
  `
    }),
    __metadata("design:paramtypes", [])
], WizardStepComponent);

let WizardComponent = class WizardComponent {
    constructor(router) {
        this.router = router;
        this.unsubscribe = new Subject();
        this._steps = [];
        this._isCompleted = false;
        this.displayNav = true;
        this.noHover = false;
        // display step number next to step label
        this.showStepNumber = false;
        // set display progress bar to true
        this.showProgress = true;
        this.onStepChanged = new EventEmitter();
    }
    ngOnInit() {
        this.stepChangeSubscription = this.onStepChanged.pipe(takeUntil(this.unsubscribe))
            .subscribe((step) => {
            // if a url is set then update history state
            if (step.url) {
                this.router.navigate([step.url], { queryParamsHandling: 'merge' });
            }
        });
        // select step based on current url
        this.routerSubscription = this.router.events.pipe(filter(e => e instanceof NavigationEnd))
            .pipe(takeUntil(this.unsubscribe))
            .subscribe((e) => {
            this.markActiveStep();
        });
    }
    ngAfterContentInit() {
        // add all of the steps for the wizard
        this.wizardSteps.forEach(step => this._steps.push(step));
        this.steps[0].isActive = true;
        // mark the active step
        this.markActiveStep();
    }
    markActiveStep() {
        if (this.steps && this.steps.length) {
            // get the first active tab found
            let activeStep = this.steps.find((step) => {
                if (step.url) {
                    return this.router.isActive(step.url, false);
                }
                else {
                    return step.isActive;
                }
            });
            if (!activeStep) {
                // if there is no active step set, activate the first
                activeStep = this.steps[0];
            }
            // go to the active step
            this.goToStepByIndex(this.steps.indexOf(activeStep));
        }
    }
    get steps() {
        // only return visible steps
        return this._steps.filter(step => !step.hidden);
    }
    get progress() {
        return this.steps.filter(step => step.showProgress);
    }
    get isCompleted() {
        return this._isCompleted;
    }
    get activeStep() {
        return this.steps.find(step => step.isActive);
    }
    set activeStep(step) {
        if (step !== this.activeStep && !step.isDisabled) {
            this.activeStep.isActive = false;
            step.isActive = true;
            this.onStepChanged.emit(step);
        }
    }
    get activeStepIndex() {
        return this.steps.indexOf(this.activeStep);
    }
    get hasNextStep() {
        return this.activeStepIndex < this.steps.length - 1;
    }
    get hasPrevStep() {
        return this.activeStepIndex > 0;
    }
    goToStep(step) {
        if (!this.isCompleted) {
            let nextStep;
            for (let i = 0; i < this.steps.length; i += 1) {
                if (this.steps[i] === step) {
                    nextStep = this.steps[i];
                }
            }
            this.activeStep.stepCompleted = true;
            this.activeStep.onNext.emit();
            nextStep.isDisabled = false;
            this.activeStep = nextStep;
        }
    }
    goToStepByIndex(index) {
        // are we advancing the wizard or decrementing it?
        if (this.activeStepIndex > index) {
            // if this was the last step and the wizard was completed we need to reset the completed state
            if (this._isCompleted) {
                this._isCompleted = false;
            }
            let prevStep;
            for (let i = this.activeStepIndex; i > -1; i -= 1) {
                prevStep = this.steps[i];
                prevStep.stepCompleted = false;
                prevStep.isDisabled = false;
                if (i === index) {
                    break;
                }
            }
            this.activeStep = prevStep;
        }
        else {
            let nextStep;
            for (let i = this.activeStepIndex; i < this.steps.length; i += 1) {
                nextStep = this.steps[i];
                nextStep.isDisabled = false;
                if (i === index) {
                    break;
                }
                nextStep.stepCompleted = true;
            }
            this.activeStep = nextStep;
        }
    }
    next() {
        if (this.hasNextStep) {
            const nextStep = this.steps[this.activeStepIndex + 1];
            this.activeStep.stepCompleted = true;
            this.activeStep.onNext.emit();
            nextStep.isDisabled = false;
            this.activeStep = nextStep;
        }
    }
    previous() {
        if (this.hasPrevStep) {
            // if this was the last step and the wizard was completed we need to reset the completed state
            if (this._isCompleted) {
                this._isCompleted = false;
            }
            const prevStep = this.steps[this.activeStepIndex - 1];
            prevStep.stepCompleted = false;
            this.activeStep.onPrev.emit();
            prevStep.isDisabled = false;
            this.activeStep = prevStep;
        }
    }
    complete() {
        this.activeStep.onComplete.emit();
        this._isCompleted = true;
    }
    /**
     * Reset wizard steps to initialized state
     */
    resetSteps() {
        // make sure wizard is not marked as completed
        this._isCompleted = false;
        // loop through all wizard steps and reset
        for (let i = 0; i < this.steps.length; i += 1) {
            this.steps[i].isActive = false;
            this.steps[i].stepCompleted = false;
        }
        this.steps[0].isActive = true;
    }
    ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
};
WizardComponent.ctorParameters = () => [
    { type: Router }
];
__decorate([
    HostBinding('class.wizard'),
    __metadata("design:type", Object)
], WizardComponent.prototype, "true", void 0);
__decorate([
    ContentChildren(WizardStepComponent),
    __metadata("design:type", QueryList)
], WizardComponent.prototype, "wizardSteps", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardComponent.prototype, "displayNav", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardComponent.prototype, "noHover", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardComponent.prototype, "showStepNumber", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], WizardComponent.prototype, "showProgress", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], WizardComponent.prototype, "onStepChanged", void 0);
WizardComponent = __decorate([
    Component({
        selector: 'lib-wizard',
        template: "<div class=\"wizard-container\" [ngClass]=\"{'hide-progress': !showProgress}\">\n  <div class=\"card-header progress\" *ngIf=\"showProgress\">\n    <ul class=\"progress-list\">\n      <li class=\"progress-list-item\" *ngFor=\"let step of progress; let i = index\"\n          [ngClass]=\"{'active': step.isActive, 'enabled': !step.isDisabled, 'disabled': step.isDisabled, 'completed': step.stepCompleted || isCompleted, 'no-hover': noHover}\">\n          <p class=\"progress-list-item-number\" [hidden]=\"!showStepNumber\">{{i + 1}}</p>\n          <p class=\"progress-list-item-text\">{{step.title}}</p>\n      </li>\n    </ul>\n  </div>\n  <div class=\"card-block\">\n    <ng-content></ng-content>\n  </div>\n  <div *ngIf=\"displayNav\">\n    <div class=\"col-md-2 form-group\">\n      <button class=\"btn btn-secondary-paired btn-block\" type=\"button\"\n              (click)=\"previous()\" [hidden]=\"!hasPrevStep || !activeStep.showPrev\" id=\"Wizard_Back_Button\">Previous</button>\n    </div>\n    <div class=\"col-md-8 form-group\"></div>\n    <div class=\"col-md-2 form-group\">\n      <button type=\"button\" class=\"btn btn-primary btn-block\" id=\"Wizard_Save_Button\"\n              (click)=\"complete()\" [disabled]=\"!activeStep.isValid\" [hidden]=\"hasNextStep\">Done</button>\n      <button type=\"button\" class=\"btn btn-primary btn-block\" id=\"Wizard_Next_Button\"\n              (click)=\"next()\" [disabled]=\"!activeStep.isValid\" [hidden]=\"!hasNextStep || !activeStep.showNext\">Next</button>\n    </div>\n  </div>\n</div>\n",
        styles: [":host(.wizard) .wizard-container [hidden]{display:none!important}:host(.wizard) .wizard-container .card-block{margin-top:15px}@media print{:host(.wizard) .wizard-container .card-header{display:none!important}:host(.wizard) .wizard-container .card-block{overflow:hidden!important}}:host(.wizard) .wizard-container.hide-progress .card-block{margin-top:0}@media only screen and (max-width:768px){:host(.wizard) .wizard-container .card-header{display:none}}:host(.wizard) .wizard-container .progress-list-item-text{padding-left:5px}:host(.wizard).hide-steps .wizard-container{padding-top:0;margin-top:-15px}:host(.wizard).hide-steps .wizard-container .card-header{display:none}"]
    }),
    __metadata("design:paramtypes", [Router])
], WizardComponent);

let WizardService = class WizardService {
    constructor() {
        this.displayWizard$ = new EventEmitter();
        this.stepWizard$ = new EventEmitter();
        this.labelWizard$ = new EventEmitter();
    }
    setLabel(id, title, disabled) {
        this.labelWizard$.emit({ id: id, title: title, disabled: disabled });
    }
    setDisplayWizard(display) {
        this.displayWizard = display;
        this.displayWizard$.emit(display);
    }
    isDisplayWizard() {
        return this.displayWizard;
    }
    next() {
        this.stepWizard$.emit('next');
    }
    previous() {
        this.stepWizard$.emit('previous');
    }
    set wizard(wiz) {
        this._wizard = wiz;
    }
    get wizard() {
        return this._wizard;
    }
};
WizardService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [])
], WizardService);

var WizardModule_1;
let WizardModule = WizardModule_1 = class WizardModule {
    static forRoot() {
        return {
            ngModule: WizardModule_1,
            providers: [
                WizardService
            ]
        };
    }
};
WizardModule = WizardModule_1 = __decorate([
    NgModule({
        imports: [
            CommonModule
        ],
        declarations: [
            WizardComponent,
            WizardStepComponent
        ],
        exports: [
            WizardComponent,
            WizardStepComponent
        ]
    })
], WizardModule);

let LoadingIndicatorComponent = class LoadingIndicatorComponent {
    constructor() {
        this.style = 'spinner';
    }
};
__decorate([
    Input(),
    __metadata("design:type", String)
], LoadingIndicatorComponent.prototype, "style", void 0);
LoadingIndicatorComponent = __decorate([
    Component({
        selector: 'lib-loading-indicator',
        template: "<div class=\"animated-loader\" *ngIf=\"style === 'shimmer'\">\n  <div class=\"background-mask header-top\"></div>\n  <div class=\"background-mask header-left\"></div>\n  <div class=\"background-mask header-right\"></div>\n  <div class=\"background-mask header-bottom\"></div>\n  <div class=\"background-mask subheader-left\"></div>\n  <div class=\"background-mask subheader-right\"></div>\n  <div class=\"background-mask subheader-bottom\"></div>\n  <div class=\"background-mask content-top\"></div>\n  <div class=\"background-mask content-first-end\"></div>\n  <div class=\"background-mask content-second-line\"></div>\n  <div class=\"background-mask content-second-end\"></div>\n  <div class=\"background-mask content-third-line\"></div>\n  <div class=\"background-mask content-third-end\"></div>\n</div>\n\n<div *ngIf=\"style === 'spinner'\">\n  <i class=\"icon icon-spinner icon-pulse\" aria-hidden=\"true\"></i>\n  <span class=\"sr-only\">Loading...</span>\n</div>\n",
        styles: [".icon.icon-spinner.icon-pulse{font-size:2.25em;color:#b83b2f;margin:1rem}.icon.icon-spinner.icon-pulse.icon-btn{color:#fff;font-size:2em;text-align:center;vertical-align:text-top;position:relative;bottom:.25em}.btn-load{height:2.85714em}.btn.btn-secondary-paired.disabled .icon.icon-spinner.icon-pulse.icon-btn{color:#b83b2f}.btn.btn-primary.disabled{background-color:#118654;color:#fff}.btn.btn-secondary.disabled{background-color:#3a5a78;color:#fff}.btn.btn-primary.disabled .icon.icon-spinner.icon-pulse.icon-btn,.btn.btn-secondary-paired.disabled .icon.icon-spinner.icon-pulse.icon-btn,.btn.btn-secondary.disabled .icon.icon-spinner.icon-pulse.icon-btn{margin:0}@-webkit-keyframes placeHolderShimmer{0%{background-position:-468px 0}100%{background-position:468px 0}}@keyframes placeHolderShimmer{0%{background-position:-468px 0}100%{background-position:468px 0}}.animated-loader{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards;-webkit-animation-iteration-count:infinite;animation-iteration-count:infinite;-webkit-animation-name:placeHolderShimmer;animation-name:placeHolderShimmer;-webkit-animation-timing-function:linear;animation-timing-function:linear;background:#f6f7f8;background:linear-gradient(to right,#eee 8%,#ddd 18%,#eee 33%);background-size:800px 104px;height:96px;position:relative}.background-mask{background:#fff;position:absolute}.background-mask.header-bottom,.background-mask.header-top,.background-mask.subheader-bottom{top:0;left:40px;right:0;height:10px}.background-mask.header-left,.background-mask.header-right,.background-mask.subheader-left,.background-mask.subheader-right{top:10px;left:40px;height:8px;width:10px}.background-mask.header-bottom{top:18px;height:6px}.background-mask.subheader-left,.background-mask.subheader-right{top:24px;height:6px}.background-mask.header-right,.background-mask.subheader-right{width:auto;left:300px;right:0}.background-mask.subheader-right{left:230px}.background-mask.subheader-bottom{top:30px;height:10px}.background-mask.content-first-end,.background-mask.content-second-end,.background-mask.content-second-line,.background-mask.content-third-end,.background-mask.content-third-line,.background-mask.content-top{top:40px;left:0;right:0;height:6px}.background-mask.content-top{height:20px}.background-mask.content-first-end,.background-mask.content-second-end,.background-mask.content-third-end{width:auto;left:380px;right:0;top:60px;height:8px}.background-mask.content-second-line{top:68px}.background-mask.content-second-end{left:420px;top:74px}.background-mask.content-third-line{top:82px}.background-mask.content-third-end{left:300px;top:88px}"]
    })
], LoadingIndicatorComponent);

var LoadingIndicatorModule_1;
let LoadingIndicatorModule = LoadingIndicatorModule_1 = class LoadingIndicatorModule {
    static forRoot() {
        return {
            ngModule: LoadingIndicatorModule_1,
            providers: []
        };
    }
};
LoadingIndicatorModule = LoadingIndicatorModule_1 = __decorate([
    NgModule({
        imports: [CommonModule],
        declarations: [LoadingIndicatorComponent],
        exports: [LoadingIndicatorComponent]
    })
], LoadingIndicatorModule);

let AccordionPanelDirective = class AccordionPanelDirective {
    constructor() {
        this.expanded = false;
        this.customPanelClass = 'panel-custom';
    }
};
__decorate([
    Input(),
    __metadata("design:type", String)
], AccordionPanelDirective.prototype, "id", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], AccordionPanelDirective.prototype, "title", void 0);
__decorate([
    Input(),
    __metadata("design:type", TemplateRef)
], AccordionPanelDirective.prototype, "customTitle", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AccordionPanelDirective.prototype, "customTitleData", void 0);
__decorate([
    Input(),
    __metadata("design:type", TemplateRef)
], AccordionPanelDirective.prototype, "body", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], AccordionPanelDirective.prototype, "expanded", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], AccordionPanelDirective.prototype, "customPanelClass", void 0);
AccordionPanelDirective = __decorate([
    Directive({
        selector: '[libAccordionPanel]'
    }),
    __metadata("design:paramtypes", [])
], AccordionPanelDirective);

/**
 * Trigger for the accordion component which defines animation states for both expanding and collapsing the accordion panels.
 */
const SlideInOutAnimation = [
    trigger('slideInOut', [
        // Animation state for expanding a panel.
        state('in', style({
            'max-height': '100%', 'opacity': '1', 'visibility': 'visible'
        })),
        // Animation state for collapsing a panel.
        state('out', style({
            'max-height': '0px', 'opacity': '0', 'visibility': 'hidden'
        })),
        // Transition which goes from expanded to collapsed.
        transition('in => out', [group([
                animate('400ms ease-in-out', style({
                    'opacity': '0'
                })),
                animate('600ms ease-in-out', style({
                    'max-height': '0px'
                })),
                animate('700ms ease-in-out', style({
                    'visibility': 'hidden'
                }))
            ])]),
        // Transition which goes from collapsed to expanded.
        transition('out => in', [group([
                animate('1ms ease-in-out', style({
                    'visibility': 'visible'
                })),
                animate('600ms ease-in-out', style({
                    'max-height': '100%'
                })),
                animate('800ms ease-in-out', style({
                    'opacity': '1'
                }))
            ])])
    ]),
];

let AccordionComponent = class AccordionComponent {
    constructor() {
        /**
         * Event Emitter which emits the component ID and the state of the panel. If the accordion panel has been expanded,
         * the event emitter will return true. Otherwise, false is returned for the expanded property.
         */
        this.onToggle = new EventEmitter();
    }
    /**
     * Toggles a panel, and sends notification to the parent component that a given panel has been toggled.
     * @param event The event that triggered the toggle panel.
     * @param panel The panel that was clicked on, or that was selected via keyboard navigation.
     * @param shouldToggle Optional property to toggle the accordion panel. Depending on the user interaction, should
     * this panel be toggled? If both the panel's "expanded" state and shouldToggle are true, then the "expanded"
     * property will be set to false and the panel is closed. The is true for the inverse, when the panel is closed, the
     * panel will be expanded.
     */
    togglePanel(event, panel, shouldToggle) {
        event.preventDefault();
        if (shouldToggle) {
            panel.expanded = !panel.expanded;
        }
        document.getElementById(panel.id).focus();
        this.onToggle.emit({
            id: panel.id,
            expanded: panel.expanded
        });
    }
    /**
     * Returns the previous panel. If there is only 1 panel, the first panel is returned. If the currently active panel
     * is the first panel, the last panel is returned. Otherwise, the previous panel is returned.
     * @param currentPanel The currently active panel.
     */
    getPreviousPanel(currentPanel) {
        if (this.panels.length === 1) {
            return this.panels.first;
        }
        let matchFound = false;
        let previousPanel = null;
        this.panels.forEach(panel => {
            if (!matchFound) {
                if (panel.id === currentPanel.id) {
                    matchFound = true;
                }
                else {
                    previousPanel = panel;
                }
            }
        });
        // If previousPanel is null, return the last panel.
        if (!previousPanel) {
            previousPanel = this.panels.last;
        }
        return previousPanel;
    }
    /**
     * Returns the next panel. If there is only 1 panel, the first panel is returned. If the currently active panel is
     * the last panel, the first panel is returned. Otherwise, the next panel is returned.
     * @param currentPanel The currently active panel.
     */
    getNextPanel(currentPanel) {
        if (this.panels.length === 1) {
            return this.panels.first;
        }
        let indexPos = 0;
        let nextPanel = null;
        this.panels.forEach((panel, index) => {
            // Find the next panel based on the index position of the current panel.
            if (panel.id === currentPanel.id) {
                if (index < this.panels.length - 1) {
                    indexPos = index + 1;
                }
            }
            // When next panel is found, set the next panel.
            if (indexPos === index && indexPos > 0) {
                nextPanel = panel;
            }
        });
        // If nextPanel is null, return the first panel.
        if (!nextPanel) {
            nextPanel = this.panels.first;
        }
        return nextPanel;
    }
    /**
     * Handles keyboard navigation. Depending on the key that was pressed, the user can navigate the accordion panels
     * using the keyboard for accessibility. Navigation can be accomplished using the Tab, Home, End, Up Arrow and Down
     * Arrow keys. Panels can be expanded and/or collapsed using Enter, Space, Left Arrow or Right Arrow keys. Once a
     * user has entered into the accordion, using the up/down arrow keys will keep the user inside the accordion. The
     * user may exit the accordion by using Tab or Shift + Tab.
     * @param event The keyboard event which contains the key that was pressed.
     * @param panel The currently active panel.
     */
    onKeydown(event, panel) {
        switch (event.which) {
            case 13: // Enter Key
            case 32: // Space Bar
                this.togglePanel(event, panel, true);
                break;
            case 35: // End Key
                this.togglePanel(event, this.panels.last);
                break;
            case 36: // Home Key
                this.togglePanel(event, this.panels.first);
                break;
            case 37: // Left Arrow
                panel.expanded = false;
                break;
            case 38: // Up Arrow
                this.togglePanel(event, this.getPreviousPanel(panel));
                break;
            case 39: // Right Arrow
                panel.expanded = true;
                break;
            case 40: // Down Arrow
                this.togglePanel(event, this.getNextPanel(panel));
                break;
        }
    }
};
__decorate([
    ContentChildren(AccordionPanelDirective),
    __metadata("design:type", QueryList)
], AccordionComponent.prototype, "panels", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], AccordionComponent.prototype, "onToggle", void 0);
AccordionComponent = __decorate([
    Component({
        selector: 'lib-accordion',
        template: "<ng-container *ngFor=\"let panel of panels; let i = index\">\n  <div class=\"panel-group\" [id]=\"'ng-kit-panels-' + panel.id + '_Group-' + i\">\n    <!-- Default HIG UX Version of Panel -->\n    <div class=\"panel panel-primary\" *ngIf=\"panel.title\">\n      <a class=\"accordion-toggle toggle align-icon-middle\" (click)=\"togglePanel($event, panel, true)\" href=\"#\"\n         (keydown)=\"onKeydown($event, panel)\" [id]=\"'ng-kit-panels-' + panel.id + i\" [attr.aria-expanded]=\"panel.expanded\"\n         [attr.aria-controls]=\"panel.id + '_Panel'\" [ngClass]=\"{'collapsed': !panel.expanded}\">\n        <div class=\"panel-heading\">\n          <span class=\"panel-title\" *ngIf=\"panel.title\">\n            <span class=\"panel-title-text\">{{panel.title}}</span>\n            <span class=\"icon icon-caret-down pull-right\" [ngClass]=\"{'expanded': panel.expanded}\"></span>\n          </span>\n          <ng-container *ngTemplateOutlet=\"panel.customTitle; context:{panelData:panel}\"></ng-container>\n        </div>\n      </a>\n      <div class=\"panel-collapse\" [ngClass]=\"{'collapse': panel.expanded !== true}\" [@slideInOut]=\"panel.expanded ? 'in' : 'out'\"\n           [id]=\"'ngKit-panel-' + panel.id + '_Panel'\" role=\"region\" [attr.aria-labelledby]=\"panel.id\">\n        <div class=\"panel-body\">\n          <ng-container *ngTemplateOutlet=\"panel.body; context:{}\"></ng-container>\n        </div>\n      </div>\n    </div>\n\n    <!-- Custom Panel -->\n    <div class=\"panel panel-primary\" [ngClass]=\"panel.customPanelClass\" *ngIf=\"!panel.title\">\n      <a href=\"#\" (click)=\"togglePanel($event, panel, true)\" (keydown)=\"onKeydown($event, panel)\" class=\"accordion-toggle toggle align-icon-middle d-block toggle\"\n              [id]=\"'ngKit-panel-' + panel.id\" [ngClass]=\"{'collapsed': !panel.expanded}\" [attr.aria-expanded]=\"panel.expanded\" [attr.aria-controls]=\"panel.id + '_Panel'\">\n              <div class=\"panel-heading\">\n                <span class=\"panel-title custom-panel-title\">\n                  <ng-container *ngTemplateOutlet=\"panel.customTitle; context:{titleData:panel.customTitleData,panelData:panel}\"></ng-container>\n                </span>\n              </div>\n      </a>\n      <div class=\"panel-collapse\" [ngClass]=\"{'collapse': panel.expanded !== true}\" [@slideInOut]=\"panel.expanded ? 'in' : 'out'\"\n           [id]=\"'ngKit-panel-' + panel.id + '_Panel'\" role=\"region\" [attr.aria-labelledby]=\"panel.id\">\n        <div class=\"panel-body\">\n          <ng-container *ngTemplateOutlet=\"panel.body; context:{}\"></ng-container>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-container>\n",
        animations: [
            SlideInOutAnimation
        ],
        styles: [".align-icon-middle span.icon.icon-caret-down::before{vertical-align:middle}"]
    })
], AccordionComponent);

let AccordionModule = class AccordionModule {
};
AccordionModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            PipesModule
        ],
        exports: [AccordionComponent, AccordionPanelDirective],
        declarations: [AccordionComponent, AccordionPanelDirective]
    })
], AccordionModule);

/*
 * Public API Surface of hig-ng-lib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AccordionModule, Address, AddressComponent, AddressForm, AddressModule, AdvancedGridModule, BreadcrumbComponent, BreadcrumbModule, BreadcrumbService, ButtonComponent, ButtonModule, CardModule, CheckboxComponent, CheckboxModule, CustomModalComponent, CustomModalModule, DatepickerComponent, DatepickerModule, EventAggregatorModule, EventAggregatorService, FieldComponentBase, FooterComponent, FooterModule, FormEngineBase, FormEngineDirectiveBase, FormEngineModule, FormGroupHighlightDirective, FormHelperModule, FormUtilitiesService, GoogleAutocompleteModule, GridModule, HeaderComponent, HeaderModule, HeadingComponent, HigLoggerModule, HigLoggerService, HigNgLibModule, HigNgLibService, HigTooltipModule, HiguxModalModule, InfoFieldsModule, InputComponent, InputModule, ListComponent, LoadingIndicatorComponent, LoadingIndicatorModule, LoggerConfig, MedalliaFeedbackModule, MedalliaFeedbackService, MessagingComponent, ModalComponent, ModalScrollDirective, ModalScrollService, PaginatorModel, PaginatorModule, ParagraphComponent, PipesModule, RadioComponent, RadioModule, ScrollingHelper, SelectComponent, SelectModule, TabComponent, TabsComponent, TabsModule, TextareaComponent, TextareaModule, ToggleButtonComponent, ToggleButtonModule, TypeaheadSelectComponent, TypeaheadSelectModule, ValidationErrorComponent, WizardComponent, WizardModule, WizardService, WizardStepComponent, HigTooltipComponent as ɵa, GridComponent as ɵb, AdvancedGridComponent as ɵc, AdvancedGridCellActionComponent as ɵd, PaginatorComponent as ɵe, SafePipe as ɵf, CardComponent as ɵg, GoogleAutocompleteDirective as ɵh, GoogleAutocompleteService as ɵi, ApiKeyConfigService as ɵj, NumbersOnlyDirective as ɵk, CURRENCY_INPUT_MASK_DIRECTIVE_VALUE_ACCESSOR as ɵl, CurrencyInputMaskDirective as ɵm, PhoneNumberDirective as ɵn, FormEngineComponent as ɵo, FormEngineDirective as ɵp, MedalliaFeedbackComponent as ɵq, AddressService as ɵr, AccordionComponent as ɵs, SlideInOutAnimation as ɵt, AccordionPanelDirective as ɵu };
//# sourceMappingURL=hig-ng-lib.js.map
