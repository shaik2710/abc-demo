import { Component, OnInit , Output,EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, Validators } from "@angular/forms";
@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.scss']
})
export class SideBarComponent implements OnInit {
  @Output() sideBarYear = new EventEmitter<String>(); // to pass side bar value to different components
  @Output() sideBarEligible = new EventEmitter<String>();
  @Output() sideBarInEligible = new EventEmitter<String>();
  @Output() sideBarMiddleMarket = new EventEmitter<String>();
  @Output() sideBarGlobalSpeciality = new EventEmitter<String>();
  radioButton :any;
  websiteList: any = ['2018', '2019', '2020','2021']
  segmentList: any = ['middle market' , 'global speciality']
  eligibilityList:any= ['Eligible' ,'Ineligible']
  constructor(public fb: FormBuilder) {}
  // Form Object
  sideBarForm = this.fb.group({
    year: new FormControl('2018', Validators.required),
    middleMarket: new FormControl(true, Validators.required),
    globalSpeciality: new FormControl(false, Validators.required),
    eligible: new FormControl(true, Validators.required),
    inEligible: new FormControl(false, Validators.required),
  })

  ngOnInit(): void {
    console.log(this.sideBarForm.controls.year.value);
  }
  /**
   * Function to check errors
   */
  get f(){
    return this.sideBarForm.controls;
  }

  /**
   * Function used to fetch values from template
   * @param e 
   */
  changeWebsite(e:any) {
    console.log(e.target.value);
    this.sideBarYear.emit(this.sideBarForm.controls.year.value);
    this.sideBarEligible.emit(this.sideBarForm.controls.eligible.value);
    this.sideBarInEligible.emit(this.sideBarForm.controls.inEligible.value);
    this.sideBarMiddleMarket.emit(this.sideBarForm.controls.middleMarket.value);
    this.sideBarGlobalSpeciality.emit(this.sideBarForm.controls.globalSpeciality.value);
  }

  

}
