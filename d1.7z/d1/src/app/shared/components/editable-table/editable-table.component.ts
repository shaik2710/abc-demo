import { Component, OnInit } from '@angular/core';

const USER_INFO = [
 
  { "Segment": "Middle Market", "MLOB": "1234", "MLOB_DESC": "Construction Excess Risk Umbrella", 
  "Reporting line code": "3121", "Comp plan exclude code": "3341", "Reporting line Desc": "DEMO1","Current PRP Eligibility Status": "Eligible"},
  { "Segment": "Middle Market", "MLOB": "4234", "MLOB_DESC": "Construction Excess Risk Umbrellariereioe", 
  "Reporting line code": "3432", "Comp plan exclude code": "4341", "Reporting line Desc": "DEMO2","Current PRP Eligibility Status": "Eligible"},
  { "Segment": "Middle Market", "MLOB": "2123", "MLOB_DESC": "Construction Excess Risk Umbrella operoper", 
  "Reporting line code": "3432", "Comp plan exclude code": "2321", "Reporting line Desc": "DEMO3","Current PRP Eligibility Status": "InEligible"},
  { "Segment": "Middle Market", "MLOB": "2234", "MLOB_DESC": "Construction Excess Risk Umbrella l;dfsld", 
  "Reporting line code": "3422", "Comp plan exclude code": "2311", "Reporting line Desc": "DEMO5","Current PRP Eligibility Status": "InEligible"},
  { "Segment": "Middle Market", "MLOB": "1213", "MLOB_DESC": "Construction Excess Risk Umbrella 3403", 
  "Reporting line code": "3422", "Comp plan exclude code": "2134", "Reporting line Desc": "DEMO6","Current PRP Eligibility Status": "InEligible"},
  { "Segment": "Middle Market", "MLOB": "1123", "MLOB_DESC": "Construction Excess Risk Umbrella dld", 
  "Reporting line code": "3411", "Comp plan exclude code": "2314", "Reporting line Desc": "DEMO7","Current PRP Eligibility Status": "InEligible"},
  { "Segment": "Middle Market", "MLOB": "1244", "MLOB_DESC": "Construction Excess Risk Umbrella oewropwe", 
  "Reporting line code": "3432", "Comp plan exclude code": "2344", "Reporting line Desc": "DEMO3","Current PRP Eligibility Status": "InEligible"},

];

// const USER_SCHEMA = {
//   "name": "text",
//   "occupation": "text",
//   "dateOfBirth": "date",
//   "age": "number",
// }

const USER_SCHEMA = {
  "Segment" : "text", 
  "MLOB": "number", 
  "MLOB_DESC": "text", 
  "Comp plan exclude code": "number",
  "Reporting line code": "number",
  "Reporting line Desc": "text",
  "Current PRP Eligibility Status": "text"
}

@Component({
  selector: 'app-editable-table',
  templateUrl: './editable-table.component.html',
  styleUrls: ['./editable-table.component.scss']
})
export class EditableTableComponent implements OnInit {
  displayedColumns: string[] = ['Segment', 'MLOB', 'MLOB_DESC', 'Comp plan exclude code',
   'Reporting line code','Reporting line Desc','Current PRP Eligibility Status','$$edit'];
  dataSource: any = USER_INFO;
  dataSchema: any = USER_SCHEMA;
  constructor() { }

  ngOnInit(): void {
  }

  
}
