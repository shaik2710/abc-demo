import { MyClickOutsideDirective } from './my-click-outside.directive';

describe('MyClickOutsideDirective', () => {
  it('should create an instance', () => {
    const directive = new MyClickOutsideDirective();
    expect(directive).toBeTruthy();
  });
});
