import { Directive, ElementRef, Renderer2, Input, OnInit } from '@angular/core';

/*
 * should be used this way:
 * <label myCheckbox='small' position='left'>
 *     <input type='checkbox'>
 * </label>
 * myCheckbox = any px or 'small' or 'medium'
 * position = left/right/center
 * shape = circle or square by default
 * */
@Directive({
  selector: '[ myCheckbox ]'
})
export class CheckboxDirective implements OnInit {
  @Input() public myCheckbox: string = ''; // small=24px, medium=32px
  @Input() public position: string = ''; // default always stay right
  @Input() public shape: string = ''; // default blue-square, or green circle
  @Input() public isEpPopup: boolean = false;
  private rootElem: any;
  private newCheckbox: any;
  private sizeMap: any = {
    small: '24px',
    medium: '32px'
  };

  constructor(private el: ElementRef, private renderer: Renderer2) {
  }
// inner elements get initialized before ngOnInit but after constructor
public ngOnInit(): void {
  this.myCheckbox = this.myCheckbox || 'small'; // default small size
  this.rootElem = this.el.nativeElement;

  // create our checkbox
  this.newCheckbox = this.renderer.createElement('span');
  this.renderer.appendChild(this.rootElem, this.newCheckbox);
  if (this.shape === 'circle') {
    this.myCheckbox = 'small'; // circle only support small
    this.renderer.addClass(this.newCheckbox, 'new-circle-checkbox');
  } else {
    this.renderer.addClass(this.newCheckbox, 'new-checkbox');
  }

  // set style to new checkbox
  this.renderer.setStyle(this.newCheckbox, 'width', this.sizeMap[this.myCheckbox]);
  this.renderer.setStyle(this.newCheckbox, 'height', this.sizeMap[this.myCheckbox]);
  this.renderer.setStyle(this.newCheckbox, 'float', this.position);
if (this.position !== 'center') {
      const marginPosition = this.position === 'left' ? 'margin-right' : 'margin-left';
      const marginSize = this.isEpPopup ? '16px' : '8px';
      this.renderer.setStyle(this.newCheckbox, marginPosition, marginSize);
  }
}
}

