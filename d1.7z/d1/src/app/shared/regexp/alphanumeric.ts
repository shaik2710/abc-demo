export const ALPHANUMERIC: RegExp = /^[a-zA-Z0-9() -`~!@#$%^&*\{}[]|:;“‘<,>.?\/+=_]+$/i;
