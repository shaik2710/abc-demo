import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-side-panel',
  templateUrl: './my-side-panel.component.html',
  styleUrls: ['./my-side-panel.component.scss']
})
export class MySidePanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
