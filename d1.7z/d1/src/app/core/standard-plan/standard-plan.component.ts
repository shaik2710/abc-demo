import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-standard-plan',
  templateUrl: './standard-plan.component.html',
  styleUrls: ['./standard-plan.component.scss']
})
export class StandardPlanComponent implements OnInit {
  demoGBTable: Array<any> =  [
        {
        item1: "Middle Market",
        item2: "1234",
        item3: "Construction Excess Risk Umbrella",
        item4: "1111",
        item5: "4321",
        item6: "Demo",
        item7: "Ineligible",

      }, {
        item1: "Middle Market",
        item2: "5678",
        item3: "Contractors Pollution Liability",
        item4: "2222",
        item5: "8765",
        item6: "UI",
        item7: "Eligible",
      },
      {
        item1: "Middle Market",
        item2: "9110",
        item3: "Contractors Prof Protective Indemnity",
        item4: "3333",
        item5: "0912",
        item6: "Awsome",
        item7: "Ineligible",
      },{
        item1: "Middle Market",
        item2: "5678",
        item3: "Contractors Pollution Liability",
        item4: "2222",
        item5: "8765",
        item6: "UI",
        item7: "Eligible",
      },{
        item1: "Middle Market",
        item2: "5678",
        item3: "Contractors Pollution Liability",
        item4: "2222",
        item5: "8765",
        item6: "UI",
        item7: "Eligible",
      },{
        item1: "Middle Market",
        item2: "5678",
        item3: "Contractors Pollution Liability",
        item4: "2222",
        item5: "8765",
        item6: "UI",
        item7: "Eligible",
      },{
        item1: "Middle Market",
        item2: "5678",
        item3: "Contractors Pollution Liability",
        item4: "2222",
        item5: "8765",
        item6: "UI",
        item7: "Eligible",
      },{
        item1: "Middle Market",
        item2: "5678",
        item3: "Contractors Pollution Liability",
        item4: "2222",
        item5: "8765",
        item6: "UI",
        item7: "Eligible",
      },{
        item1: "Middle Market",
        item2: "5678",
        item3: "Contractors Pollution Liability",
        item4: "2222",
        item5: "8765",
        item6: "UI",
        item7: "Eligible",
      }];
    
  value: any = '2018';
  eligible: any = true;
  inEligible: any = false;
  middleMarket: any = true;
  globalSpeciality: any = false;
  constructor() {
    
  }

  ngOnInit(): void {
  }

  /**
   * Function to get value of year from side bar
   * @param year 
   */
  sideBarToYear(year: any) {
    this.value = year;
    console.log(year);
  }

  /**
   * Function to get value of eligibility from side bar
   * @param eleigible 
   */
  sideBarEligible(eleigible: any) {
    this.eligible = eleigible;
  }

  /**
   * Function to get value of inEligiblity from side bar
   * @param inEleigible 
   */
  sideBarInEligible(inEleigible: any) {
    this.inEligible = inEleigible;
  }
  /**
   * Function to get value of middle market from side bar
   * @param middleMarket 
   */
  sideBarMiddleMarket(middleMarket: any) {
    this.middleMarket = middleMarket;
  }
  /**
   * Function to get value of global speciality from side bar
   * @param globalSpeciality 
   */
  sideBarGlobalSpeciality(globalSpeciality: any) {
    this.globalSpeciality = globalSpeciality;
  }

}
