import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardPlanPcComponent } from './standard-plan-pc.component';

describe('StandardPlanPcComponent', () => {
  let component: StandardPlanPcComponent;
  let fixture: ComponentFixture<StandardPlanPcComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StandardPlanPcComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardPlanPcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
