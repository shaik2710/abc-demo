import { Component, OnInit, ViewChild } from '@angular/core';
//import { ModalPopupComponent } from '../../shared/components/modal-popup/modal-popup.component';
//import { ModalConfig } from  '../../shared/components/modal-popup/modal-popup.config';

@Component({
  selector: 'app-standard-plan-pc',
  templateUrl: './standard-plan-pc.component.html',
  styleUrls: ['./standard-plan-pc.component.scss']
})
export class StandardPlanPcComponent implements OnInit {
  @ViewChild('modal')
  //private modal!: ModalPopupComponent;
  
 /* public modalConfig:ModalConfig = {
    modalTitle: "Title",
    onDismiss: () => {return true},
    dismissButtonLabel: "dimiss",
    onClose:() => {return true},
    closeButtonLabel: "close"
  }*/

  demoGBTable: Array<any> =  [
    {
    item1: "Middle Market",
    item2: "1234",
    item3: "Construction Excess Risk Umbrella",
    item4: "1111",
    item5: "4321",
    item6: "Demo",
    item7: "Ineligible",

  }, {
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "UI",
    item7: "Eligible",
  },
  {
    item1: "Middle Market",
    item2: "9110",
    item3: "Contractors Prof Protective Indemnity",
    item4: "3333",
    item5: "0912",
    item6: "Awsome",
    item7: "Ineligible",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "UI",
    item7: "Eligible",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "UI",
    item7: "Eligible",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "UI",
    item7: "Eligible",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "UI",
    item7: "Eligible",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "UI",
    item7: "Eligible",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "UI",
    item7: "Eligible",
  }];
  constructor() { }

  ngOnInit(): void {
  }

  async openModalPopup() {
  //  return await this.modal.open();
  }

}
