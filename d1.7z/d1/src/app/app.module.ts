import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MatTableModule} from '@angular/material/table';
import {MatInputModule} from '@angular/material/input';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { FormsModule } from '@angular/forms';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from '././core/home/home.component';
import { StandardPlanComponent } from '././core/standard-plan/standard-plan.component';
import { SpecialDealComponent } from '././core/special-deal/special-deal.component';
import { StandardPlanPcComponent } from '././core/standard-plan-pc/standard-plan-pc.component';
import { IteratorPipe } from './shared/pipes/iterator/iterator.pipe';
import { MoneyPipe } from './shared/pipes/money/money.pipe';
import { CheckboxDirective } from './shared/directives/checkbox/checkbox.directive';
import { ClickOutsideDirective } from './shared/directives/click/my-click-outside.directive';
import { HeaderComponent } from './core/header/header.component';
import { MySidePanelComponent } from './core/my-side-panel/my-side-panel.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EditableTableComponent } from './shared/components/editable-table/editable-table.component';
import { SideBarComponent } from './shared/components/side-bar/side-bar.component';
import { TableContainerComponent } from './shared/components/table-container/table-container.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModalPopupComponent } from './shared/components/modal-popup/modal-popup.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    StandardPlanComponent,
    SpecialDealComponent,
    StandardPlanPcComponent,
    IteratorPipe,
    MoneyPipe,
    CheckboxDirective,
    ClickOutsideDirective,
    HeaderComponent,
    MySidePanelComponent,
    EditableTableComponent,
    SideBarComponent,
    TableContainerComponent,
   
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    FormsModule,
    MatChipsModule,
    MatIconModule,
    MatToolbarModule,
    MatDividerModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCheckboxModule,
    ReactiveFormsModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent],
 
})
export class AppModule { }
