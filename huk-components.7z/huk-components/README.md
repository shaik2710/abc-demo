# HUK Stencil Component Library

The HUK Stencil Component Library is a HIG InnerSource Project to create and maintain a library of Stencil web components that are built on styles from the HIGUX kit.  Stencil components are transpiled into W3C standard webcomponents and are capable of being integrated into a variety of Javascript frameworks including Angular, React, Vue and more.  To learn more about Stencil and the browsers that support stencil web component technology, check out the sites below.  Please familiarize yourself with <a href="https://stenciljs.com/docs/style-guide">Stencil best practices</a> before contributing code to the repo.  Thanks!

<a href="https://www.stenciljs.com">StencilJS Project</a>
<br/>
<a href="https://www.webcomponents.org">Web Components Support</a>

# Getting Started
We have created a number of ways for developers to get started using the kit.  First off you can <a href="http://d25sv0wtgq18.thehartford.com:4201/">explore many of the components that are part of the kit</a> and their various configurations that map closely to the HIG UI kit on our Angular demo site.  You'll notice this looks very similar to the HIG UI kit demo pages.  Once you have an idea of all the components that are available, <a href="http://d25sv0wtgq18.thehartford.com:8087/HUK#/">head over to the HUK Studio</a> (or Surfer as we know it :^).  The studio will allow you to actively play around with the components and see exactly how they will look in your app.  You can even create a mock layout on the built-in stage.  

Once you are ready to get started coding with the kit, check out our getting started guides for <a href="https://github.thehartford.com/HIG/ews_huk_components/blob/master/docs/Angular%20Getting%20Started%20Guide.md">Angular</a> and <a href="https://github.thehartford.com/HIG/ews_huk_components/blob/master/docs/React%20Getting%20Started%20Guide.md">React</a>.  They will get you running in no time and then use the studio to start adding new components to your application.  If you are planning to use Angular Forms definitely take a look at the <a href="http://d25sv0wtgq18.thehartford.com:4202/">Angular Forms Example app</a>.  There's some really great examples how to build and validate both template and reactive angular forms.

Now go make something great!

# Code Contribution
1. **Fork** This repo into your personal workspace
1. **Clone** Your forked repo into your environment / IDE of choice
1. **Branch** the repo, named `after-your-feature`
1. **Commit** your changes
1. **Pull Request** back to HIS/ews_nghigux. The community will discuss the changes and either request additional commits to your branch, or approve the Pull Request.

# Project Info
- _App Owner_: Kavitha Yalamanchili
- _PlanIT Project_: HIG Innersource App-4453
- Component COM-4247: StencilJS X.X  
- Vendor Product SWP-3549: StencilJS X.X 
