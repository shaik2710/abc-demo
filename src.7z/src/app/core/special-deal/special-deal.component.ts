import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-special-deal',
  templateUrl: './special-deal.component.html',
  styleUrls: ['./special-deal.component.scss']
})
export class SpecialDealComponent implements OnInit {
 // submitData: boolean = false;
  public submitData: boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

}
