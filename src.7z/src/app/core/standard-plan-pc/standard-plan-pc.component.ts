import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { PlanDetailsService } from 'src/app/shared/services/plan-details/plan-details.service';
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { ActionsInfo, AdvancedTableHeader, PagingInfo } from "hig-ng-lib/lib/advanced-grid/advanced-grid.model";

interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-standard-plan-pc',
  templateUrl: './standard-plan-pc.component.html',
  styleUrls: ['./standard-plan-pc.component.scss']
})

export class StandardPlanPcComponent implements OnInit {
  @ViewChild(ModalComponent)
  standardPlanPCEditConfirm!: ModalComponent;

 nonSortableTableHeaders: AdvancedTableHeader[] = [];

  public demoGBTable: Array<any> = [
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: 'Ineligible',
      pay_elty: "Eligible"

    }, {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Ziddle Market",
      mlob: "9110",
      mlob_desc: "Contractors Prof Protective Indemnity",
      cal_elty: "Eligible",
      pay_elty: "Eligible",
    }, {
      complan: "Piddle Market",
      mlob: "5678",
      mlob_desc: "Qontractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "InEligible",
    }, {
      complan: "Abddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "Eligible",
    }, {
      complan: "Middle Market",
      mlob: "5678",
      mlob_desc: "Zontractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "Eligible",
    }, {
      complan: "Ciddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "Eligible"
    }, {
      complan: "Biddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "Ineligible",
    }, {
      complan: "Criddle Market",
      mlob: "5678",
      mlob_desc: "Aontractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "Ineligible",
    },
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    },
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    },
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    },
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    }
  
  ];

  dataTableHeader = [
    {
        title: 'Comp Plan',
        field: 'complan',
    },
    {
        title: 'MLOB',
        field: 'mlob'
    },
    {
        title: 'MLOB_Description',
        field: 'mlob_desc'
    },
    {
        title: 'Calculation Eligibility',
        field: 'cal_elty'
    },
    {
        title: 'Payment Eligibility',
        field: 'pay_elty'
    },
    {
      title: 'Action',
      field: ''
  }
];


businessInfoList = [
  {
      policyNumber: "01SBABG6179",
      policyType: "Business Owner's",
      policyStatus: "Issued",
      policySymbolCode: "SBA",
      regionOfficeCode: "01",
      policyNumberCode: "BG6179",
      policyAccessRoleId: "1",
      isPolicyActive: true,
      insuredName: "ZZZTest148",
      relationshipType: "E",
      policyAccessRoleStatus: "ACT",
      isAdminEligible: true,
      policyEffectiveDate: "2019-04-04",
      policyExpirationDate: "2020-04-04",
      isPHS: true,
      address: {
          addressLine1: "ZZZ1327 FOOTHILL BLVD",
          city: "LA CANADA FLINTRIDGE",
          zipCode: "91011-2238",
          state: "CA"
      },
      businessSegmentDesc:
          "This data is large. However, the column width is " +
          "handled by passing the custom css class name in the header properties",
      policyCreateDate: "2014-05-15",
      sublines: [
          {
              subline: "CA",
              reportingMethod: "phone"
          },
          {
              subline: "GL",
              reportingMethod: "online"
          },
          {
              subline: "CP",
              reportingMethod: "online"
          }
      ],
      productAbbreviatedDesc: "WC",
      sourceSystem: "PS",
      producerCode: "110128",
      premiumAmount: "11368",
      renewalType: "New Business",
      businessName: "ABC Company, LLC",
      isForemost: false
  },
  {
      policyNumber: "01SBABG6005",
      policyType: "Business Owner's",
      policyStatus: "Issued",
      policySymbolCode: "SBA",
      regionOfficeCode: "01",
      policyNumberCode: "BG6005",
      policyAccessRoleId: "1",
      isPolicyActive: true,
      insuredName: "ZZZTest147",
      relationshipType: "E",
      policyAccessRoleStatus: "ACT",
      isAdminEligible: true,
      policyEffectiveDate: "2019-04-04",
      policyExpirationDate: "2020-04-04",
      isPHS: true,
      address: {
          addressLine1: "ZZZ1327 FOOTHILL BLVD",
          city: "LA CANADA FLINTRIDGE",
          zipCode: "91011-2237",
          state: "CA"
      },
      businessSegmentDesc: "Select Customer",
      policyCreateDate: "2014-05-15",
      sublines: [
          {
              subline: "CA",
              reportingMethod: "phone"
          },
          {
              subline: "GL",
              reportingMethod: "online"
          },
          {
              subline: "CP",
              reportingMethod: "online"
          }
      ],
      productAbbreviatedDesc: "WC",
      sourceSystem: "PS",
      producerCode: "110127",
      premiumAmount: "11367",
      renewalType: "New Business",
      businessName: "ABC Company, LLC",
      isForemost: false
  },
  {
      policyNumber: "01SBABG6519",
      policyType: "Business Owner's",
      policyStatus: "Issued",
      policySymbolCode: "SBA",
      regionOfficeCode: "01",
      policyNumberCode: "BG6519",
      policyAccessRoleId: "1",
      isPolicyActive: true,
      insuredName: "ZZZTest326",
      relationshipType: "O",
      policyAccessRoleStatus: "ACT",
      isAdminEligible: true,
      policyEffectiveDate: "2019-07-07",
      policyExpirationDate: "2020-07-07",
      isPHS: true,
      address: {
          addressLine1: "ZZZ1327 FOOTHILL BLVD",
          city: "LA CANADA FLINTRIDGE",
          zipCode: "91011-2416",
          state: "CA"
      },
      businessSegmentDesc: "Select Customer",
      policyCreateDate: "2014-05-15",
      sublines: [
          {
              subline: "CA",
              reportingMethod: "phone"
          },
          {
              subline: "GL",
              reportingMethod: "online"
          },
          {
              subline: "CP",
              reportingMethod: "online"
          }
      ],
      productAbbreviatedDesc: "WC",
      sourceSystem: "PS",
      producerCode: "110306",
      premiumAmount: "11546",
      renewalType: "New Business",
      businessName: "BDF Incorporated",
      isForemost: false
  },
  {
      policyNumber: "20SBAPO2573",
      policyType: "Business Owner's",
      policyStatus: "Issued",
      policySymbolCode: "SBA",
      regionOfficeCode: "20",
      policyNumberCode: "PO2573",
      policyAccessRoleId: "1",
      isPolicyActive: true,
      insuredName: "ZZZTest150",
      relationshipType: "E",
      policyAccessRoleStatus: "ACT",
      isAdminEligible: true,
      policyEffectiveDate: "2019-04-04",
      policyExpirationDate: "2020-04-04",
      isPHS: true,
      address: {
          addressLine1: "ZZZ1327 FOOTHILL BLVD",
          city: "LA CANADA FLINTRIDGE",
          zipCode: "91011-2240",
          state: "CA"
      },
      businessSegmentDesc: "Select Customer",
      policyCreateDate: "2014-05-15",
      sublines: [
          {
              subline: "CA",
              reportingMethod: "phone"
          },
          {
              subline: "GL",
              reportingMethod: "online"
          },
          {
              subline: "CP",
              reportingMethod: "online"
          }
      ],
      productAbbreviatedDesc: "WC",
      sourceSystem: "PS",
      producerCode: "110130",
      premiumAmount: "11370",
      renewalType: "New Business",
      businessName: "CDEFG & Family, Incorporated",
      isForemost: false
  },
  {
      policyNumber: "01SBABG6096",
      policyType: "Business Owner's",
      policyStatus: "Issued",
      policySymbolCode: "SBA",
      regionOfficeCode: "01",
      policyNumberCode: "BG6096",
      policyAccessRoleId: "1",
      isPolicyActive: true,
      insuredName: "ZZZTest328",
      relationshipType: "O",
      policyAccessRoleStatus: "ACT",
      isAdminEligible: true,
      policyEffectiveDate: "2019-07-07",
      policyExpirationDate: "2020-07-07",
      isPHS: true,
      address: {
          addressLine1: "ZZZ1327 FOOTHILL BLVD",
          city: "LA CANADA FLINTRIDGE",
          zipCode: "91011-2418",
          state: "CA"
      },
      businessSegmentDesc: "Select Customer",
      policyCreateDate: "2014-05-15",
      sublines: [
          {
              subline: "CA",
              reportingMethod: "phone"
          },
          {
              subline: "GL",
              reportingMethod: "online"
          },
          {
              subline: "CP",
              reportingMethod: "online"
          }
      ],
      productAbbreviatedDesc: "WC",
      sourceSystem: "PS",
      producerCode: "110308",
      premiumAmount: "11548",
      renewalType: "New Business",
      businessName: "CDEFG & Family, Incorporated",
      isForemost: false
  }
];

tableHeaders = [
  {
      fieldLabel: "Policy#",
      fieldName: "policyNumber"
  },
  {
      fieldLabel: "Type",
      fieldName: "policyType"
  },
  {
      fieldLabel: "Status",
      fieldName: "policyStatus",
      sortable: true
  },
  {
      fieldLabel: "Premium",
      fieldName: "premiumAmount",
    
      sortable: true
  },
  {
      fieldLabel: "Business Segment Description",
      fieldName: "businessSegmentDesc",
      sortable: true,
      customClass: "businessSegmentDesc"
  },
  {
      fieldLabel: "Policy Symbol",
      fieldName: "policySymbolCode",
      sortable: true
  },
  {
      fieldLabel: "RO Code",
      fieldName: "regionOfficeCode",
      sortable: true
  },
  {
      fieldLabel: "Named Insured",
      fieldName: "insuredName",
      sortable: true
  },
  {
      fieldLabel: "Access Role",
      fieldName: "policyAccessRoleStatus",
      sortable: true,
      customClass: "policyAccessRoleStatus"
  },
  {
      fieldLabel: "Effective Date",
      fieldName: "policyEffectiveDate",
      sortable: true
  },
  {
      fieldLabel: "Expiration Date",
      fieldName: "policyExpirationDate",
      sortable: true
  },
  {
      fieldLabel: "Created On",
      fieldName: "policyCreateDate",
      sortable: true
  },
  {
      fieldLabel: "Admin",
      fieldName: "isAdminEligible",
      sortable: true
  },
  {
      fieldLabel: "Renewal Type",
      fieldName: "renewalType",
      sortable: true
  }
];

getDisplayTextForHeaderField = ((column: any): string => {
  if (column.fieldLabel) {
      return column.fieldLabel;
  }
  return (column as string).toUpperCase();
}).bind(this);

getDisplayTextForRecordField = ((columnName: string, record: any): string => {
  return record[columnName];
}).bind(this);

  frmSubscribe = this.fb.group({
    complan: '',
    mlob: '',
    mlob_desc: '',
    cal_elty: '',
    pay_elty: ''
  });


  public showMore = true;
  public year = '2021';
  public title = 'Standard Plan MLOB Eligiblity';
  constructor(public fb: FormBuilder, private planDetailsService: PlanDetailsService) { }

  ngOnInit(): void {
    // this.getStandardPlanPCData();
    this.assignNonSortableTableHeaders();
  }

  private assignNonSortableTableHeaders(): void {
    this.tableHeaders.forEach(th => {
        const clonedTh = Object.assign({}, th);
        clonedTh.sortable = true;
        clonedTh.customClass= undefined;
  
        this.nonSortableTableHeaders.push(clonedTh);
    });
}

  /**
   * Function to hide the side bar
   */
  public toggle(): void {
    this.showMore = !this.showMore;

  }

  public modalOpen(modalData: any): any {
    this.frmSubscribe = this.fb.group({
      complan: modalData.complan,
      mlob: modalData.mlob,
      mlob_desc: modalData.mlob_desc,
      cal_elty: modalData.cal_elty,
      pay_elty: modalData.pay_elty
    });
    this.standardPlanPCEditConfirm.show();

  }



  public getStandardPlanPCData(): void {
    this.planDetailsService.getStandardPlanPC().subscribe(data => {
      this.demoGBTable = data ? data : this.demoGBTable;
    });

  }
}
