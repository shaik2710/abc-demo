import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { PlanDetailsService } from 'src/app/shared/services/plan-details/plan-details.service';
import { ModalComponent } from '../../shared/components/modal/modal.component';


interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-standard-plan-pc',
  templateUrl: './standard-plan-pc.component.html',
  styleUrls: ['./standard-plan-pc.component.scss']
})

export class StandardPlanPcComponent implements OnInit {
  @ViewChild(ModalComponent)
  standardPlanPCEditConfirm!: ModalComponent;

  public demoGBTable: Array<any> = [
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    }, {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Aiddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "InEligible",
    },
    {
      complan: "Ziddle Market",
      mlob: "9110",
      mlob_desc: "Contractors Prof Protective Indemnity",
      cal_elty: "Eligible",
      pay_elty: "Eligible",
    }, {
      complan: "Piddle Market",
      mlob: "5678",
      mlob_desc: "Qontractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "InEligible",
    }, {
      complan: "Abddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Eligible",
      pay_elty: "Eligible",
    }, {
      complan: "Middle Market",
      mlob: "5678",
      mlob_desc: "Zontractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "Eligible",
    }, {
      complan: "Ciddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "Eligible"
    }, {
      complan: "Biddle Market",
      mlob: "5678",
      mlob_desc: "Contractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "Ineligible",
    }, {
      complan: "Criddle Market",
      mlob: "5678",
      mlob_desc: "Aontractors Pollution Liability",
      cal_elty: "Ineligible",
      pay_elty: "Ineligible",
    },
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    },
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    },
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    },
    {
      complan: 'Middle Market',
      mlob: '1234',
      mlob_desc: 'Construction Excess Risk Umbrella',
      cal_elty: "Ineligible",
      pay_elty: "Eligible"

    }
  
  ];

  dataTableHeader = [
    {
        title: 'Comp Plan',
        field: 'complan',
    },
    {
        title: 'MLOB',
        field: 'mlob'
    },
    {
        title: 'MLOB_Description',
        field: 'mlob_desc'
    },
    {
        title: 'Calculation Eligibility',
        field: 'cal_elty'
    },
    {
        title: 'Payment Eligibility',
        field: 'pay_elty'
    },
    {
      title: 'Action',
      field: ''
  }
];

  frmSubscribe = this.fb.group({
    complan: '',
    mlob: '',
    mlob_desc: '',
    cal_elty: '',
    pay_elty: ''
  });


  public showMore = true;
  public year = '2021';
  public title = 'Standard Plan MLOB Eligiblity';
  constructor(public fb: FormBuilder, private planDetailsService: PlanDetailsService) { }

  ngOnInit(): void {
    // this.getStandardPlanPCData();
  }

  /**
   * Function to hide the side bar
   */
  public toggle(): void {
    this.showMore = !this.showMore;

  }

  public modalOpen(modalData: any): any {
    this.frmSubscribe = this.fb.group({
      complan: modalData.complan,
      mlob: modalData.mlob,
      mlob_desc: modalData.mlob_desc,
      cal_elty: modalData.cal_elty,
      pay_elty: modalData.pay_elty
    });
    this.standardPlanPCEditConfirm.show();

  }



  public getStandardPlanPCData(): void {
    this.planDetailsService.getStandardPlanPC().subscribe(data => {
      this.demoGBTable = data ? data : this.demoGBTable;
    });

  }
}
