import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-deal',
  templateUrl: './new-deal.component.html',
  styleUrls: ['./new-deal.component.scss']
})
export class NewDealComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
