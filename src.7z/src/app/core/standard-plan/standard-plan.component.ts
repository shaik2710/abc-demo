import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { PlanDetailsService } from 'src/app/shared/services/plan-details/plan-details.service';
import { ModalComponent } from '../../shared/components/modal/modal.component';

@Component({
  selector: 'app-standard-plan',
  templateUrl: './standard-plan.component.html',
  styleUrls: ['./standard-plan.component.scss']
})
export class StandardPlanComponent implements OnInit {
  @ViewChild(ModalComponent)
  standardPlanGBEditConfirm!: ModalComponent;
  showFiller = false;
  frmGbEligibility = this.fb.group({
    lineCovgCode: '',
    lineCovgDesc: '',
    calEligibility: '',
    pymtEligibility: ''
  });

  public demoGBTable: Array<any> = [
    {
      lineCovgCode: 'STD',
      lineCovgDesc: 'Short Time Disability',
      calEligibility: 'Eligiblie',
      pymtEligibility: 'Eligiblie'
    },
    {
      lineCovgCode: 'LTD',
      lineCovgDesc: 'Long Time Disability',
      calEligibility: 'Eligiblie',
      pymtEligibility: 'Eligiblie'
    },
    {
      lineCovgCode: 'LTD',
      lineCovgDesc: 'Long Time Disability',
      calEligibility: 'InEligiblie',
      pymtEligibility: 'Eligiblie'
    },
    {
      lineCovgCode: 'STD',
      lineCovgDesc: 'Short Time Disability',
      calEligibility: 'Eligiblie',
      pymtEligibility: 'Eligiblie'
    },
    {
      lineCovgCode: 'LTD',
      lineCovgDesc: 'Long Time Disability',
      calEligibility: 'InEligible',
      pymtEligibility: 'InEligiblie'
    },
    {
      lineCovgCode: 'STD',
      lineCovgDesc: 'Short Time Disability',
      calEligibility: 'InEligible',
      pymtEligibility: 'InEligiblie'
    },
  ];
  public dataTableHeader: Array<any> = [
    { id: 'lineCovgCode', header: 'Line Coverage Code' },
    { id: 'lineCovgDesc', header: 'Line Coverage Description' },
    { id: 'calEligibility', header: 'Calculation Eligbility' },
    { id: 'pymtEligibility', header: 'Payment Eligbility' }
  ];
  public title = 'Standard Plan GB Eligibility';

  public currentItem: boolean;

  public showMore: boolean;
  value: any = '2018';
  eligible: any = true;
  inEligible: any = false;
  middleMarket: any = true;
  globalSpeciality: any = false;
  constructor(public fb: FormBuilder, private planDetailsService: PlanDetailsService) {
    this.showMore = true;
    this.currentItem = true;
  }

  ngOnInit(): void {
    //  this.getStandardPlanGBData();
  }

  public getStandardPlanGBData(): void {
    this.planDetailsService.getStandardPlanGB().subscribe(data => {
      this.demoGBTable = data ? data : this.demoGBTable;
    });
  }

  public tableData(value: any): void {
    if (value === 'true') {
      this.currentItem = true;
    } else if (value === 'false') {
      this.currentItem = false;
    }
  }

  /**
   * Function to change the hide side bar
   */
  public toggle(): void {
    this.showMore = !this.showMore;
  }

  public modalOpen(modalData: any): any {
    this.frmGbEligibility = this.fb.group({
      lineCovgCode: modalData.response.lineCovgCode,
      lineCovgDesc: modalData.response.lineCovgDesc,
      calEligibility: modalData.response.calEligibility,
      pymtEligibility: modalData.response.pymtEligibility
    });
    this.standardPlanGBEditConfirm.show();

  }

}
