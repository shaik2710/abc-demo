import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-special-deal-main-page',
  templateUrl: './special-deal-main-page.component.html',
  styleUrls: ['./special-deal-main-page.component.scss']
})
export class SpecialDealMainPageComponent implements OnInit {
  demoGBTable: Array<any> =  [
    {
    item1: "Middle Market",
    item2: "1234",
    item3: "Construction Excess Risk Umbrella",
    item4: "1111",
    item5: "4321",
    item6: "Ineligible",
    item7: "X",

  }, {
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "Eligible",
    item7: "-",
  },
  {
    item1: "Middle Market",
    item2: "9110",
    item3: "Contractors Prof Protective Indemnity",
    item4: "3333",
    item5: "0912",
    item6: "Ineligible",
    item7: "-",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "Eligible",
    item7: "-",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "Eligible",
    item7: "-",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "Eligible",
    item7: "X",
  },{
    item1: "Middle Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "Eligible",
    item7: "X",
  },{
    item1: "Market",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "Eligible",
    item7: "-",
  },{
    item1: "Middle ",
    item2: "5678",
    item3: "Contractors Pollution Liability",
    item4: "2222",
    item5: "8765",
    item6: "Eligible",
    item7: "X",
  }];
  constructor(private route: Router) { }

  ngOnInit(): void {
  }
  btnClick=  () => {
    this.route.navigateByUrl('/newdeal');
};
}
