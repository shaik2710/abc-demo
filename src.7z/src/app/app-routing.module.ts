import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './core/header/header.component';
import { HomeComponent } from './core/home/home.component';
import { StandardPlanComponent } from '././core/standard-plan/standard-plan.component';
import { SpecialDealComponent } from '././core/special-deal/special-deal.component';
import { StandardPlanPcComponent } from '././core/standard-plan-pc/standard-plan-pc.component';
import { SpecialDealMainPageComponent } from '././core/special-deal-main-page/special-deal-main-page.component';
import { NewDealComponent } from '././core/new-deal/new-deal.component';
const routes: Routes = [
  { path: 'header-component', component: HeaderComponent },
  { path: 'home-component', component: HomeComponent },
  { path: 'standardPlanGB-component', component: StandardPlanComponent },
  { path: 'standardPlanPC-component', component: StandardPlanPcComponent },
  { path: '', redirectTo: '/home-component', pathMatch: 'full' }, // redirect to `home-component`
  { path: 'specialdeal', component: SpecialDealComponent },
  { path: 'specialdealmainpage', component: SpecialDealMainPageComponent},
  { path: 'newdeal', component: NewDealComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
