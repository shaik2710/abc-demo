import { NgModule } from '@angular/core';
import { APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA,  NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { GridModule, AdvancedGridModule } from 'hig-ng-lib';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from '././core/home/home.component';
import { StandardPlanComponent } from '././core/standard-plan/standard-plan.component';
import { SpecialDealComponent } from '././core/special-deal/special-deal.component';
import { StandardPlanPcComponent } from '././core/standard-plan-pc/standard-plan-pc.component';
import { IteratorPipe } from './shared/pipes/iterator/iterator.pipe';
import { MoneyPipe } from './shared/pipes/money/money.pipe';
import { HeaderComponent } from './core/header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SideBarComponent } from './shared/components/side-bar/side-bar.component';
import { TableContainerComponent } from './shared/components/table-container/table-container.component';
import { ModalComponent } from './shared/components/modal/modal.component';
import { DropDownMultiselectComponent } from './shared/components/drop-down-multiselect/drop-down-multiselect.component';
import { SearchComponent } from './shared/components/search/search.component';
import { SpecialDealMainPageComponent } from './core/special-deal-main-page/special-deal-main-page.component';
import { NewDealComponent } from './core/new-deal/new-deal.component';
import { SortDirective } from './shared/directives/sort.directive';
import { AppConfig } from '../config/config';
import {AppConstant} from '../config/constants';
import {LoggerService} from './shared/services/logger/logger.service';
import { ErrorService } from './shared/services/error.service';
import {HttpServiceInterceptor} from './shared/services/http/http-interceptor';

// Load config file prior to app creation, method must return a Promise
export function initializeApp(appConfig: AppConfig): any{
  // invoke the load method in our config service.
  // Angular will delay the app initialization until the promise is resolved
  return () => appConfig.load();
}

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    StandardPlanComponent,
    SpecialDealComponent,
    StandardPlanPcComponent,
    IteratorPipe,
    MoneyPipe,
    HeaderComponent,
    SideBarComponent,
    TableContainerComponent,
    ModalComponent,
    DropDownMultiselectComponent,
    SearchComponent,
    SpecialDealMainPageComponent,
    NewDealComponent,
    SortDirective
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AdvancedGridModule
  ],
  providers: [
    AppConfig,
    {
      provide: APP_INITIALIZER,
      useFactory: initializeApp,
      deps: [AppConfig],
      multi: true
    } ,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpServiceInterceptor,
      multi: true
    },
    LoggerService,
    ErrorService
  ],
  bootstrap: [AppComponent],
  schemas: [

    NO_ERRORS_SCHEMA , CUSTOM_ELEMENTS_SCHEMA
  ],
  entryComponents: [ModalComponent]
})
export class AppModule { }
