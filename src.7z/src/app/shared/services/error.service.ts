import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ErrorMessage } from '../model/error-message';

@Injectable()
export class ErrorService {
  private errorMsg = new ErrorMessage();
  public errorMessage: BehaviorSubject<ErrorMessage> = new BehaviorSubject<ErrorMessage>(this.errorMsg);

  constructor() {
  }

  setError(error: ErrorMessage) {
    this.errorMessage.next(error);
  }
}
