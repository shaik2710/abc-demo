import { Injectable } from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpHeaders,
  HttpInterceptor,
  HttpParams,
  HttpRequest,
  HttpResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { ErrorService } from '../error.service';
import { ErrorMessage } from '../../model/error-message';
import { environment } from '../../../../environments/environment';
import { LoggerService } from '../logger/logger.service';
import { AppConstant } from '../../../../config/constants';

export class ExtendedHttpHeaders extends HttpHeaders {
  errorHandler?: Function;
}

@Injectable()
export class HttpServiceInterceptor implements HttpInterceptor {
  private errorSkipURLS = [ ];

  private corsSkipURLS = [
    'api.thehartford.com'
  ];
  // IE/Edge cache GET requests however the below APIs return empty response when additional cache bust param is added
  private cacheBustSkipURLS = [
    'api.thehartford.com/cl/documents/'
  ];
  constructor(public router: Router,
              public errorService: ErrorService,
              public logger: LoggerService) {
  }


  // add custom headers to request
  public prepareHeader(url: string): any {
    const bypass = false;
    // Prevent Ajax Request Caching for Internet Explorer but doesn't work for datapower
    if (bypass) {
      return {};
    }
    const headers = {};
   
    return headers;
  }

  public skipErrorCatch(url: string) {
    return false;
  }

  public skipCacheBust(url: string) {
    const skip = false;
    return skip;
  }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const customReq = request;

    return next
      .handle(request.clone({}));
  }

  getErrorStatusCode(res: any): number {
    if (res) {
      if (res.hasOwnProperty('status')) {
        return res.status;
      } else if (res.error && res.error.hasOwnProperty('status')) {
        return res.error.status;
      }
    }
    return 500;
  }

  public catchErrors(res: any) {
    // catch non-200 service responses
    const errorStatus = this.getErrorStatusCode(res);
    if (errorStatus < 200 || errorStatus >= 300) {
      // US_2754 redirect non-200 responses to Error page
      const errorMsg = new ErrorMessage();

      if (this.errorService) {
        this.errorService.setError(errorMsg);
      }

    }
    return throwError(res);
  }
}
