import { Injectable } from '@angular/core';
import { Observable, throwError, of as observableOf } from 'rxjs';
import { AppConstant } from '../../../../config/constants';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlanDetailsService {

  constructor(private http: HttpClient) { }

  public getStandardPlanPC(): Observable<any> {
    const path = '/v1/lobs';
    return this.http.get(path);
    // return observableOf(response);
  }

  public getStandardPlanGB(): Observable<any> {
    const path = AppConstant.API_HOST_ROOT;
    return this.http.get(path);
  }

}
