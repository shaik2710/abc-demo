import { Injectable } from '@angular/core';
import { Observable, throwError, of as observableOf } from 'rxjs';
import { AppConstant } from '../../../../config/constants';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlanDetailsService {

  constructor(private http: HttpClient) { }

  public getStandardPlanPC(): Observable<any> {
    const path = AppConstant.API_HOST_ROOT + '/v1/lobs';
    const response = [{ "lobId": 200, "lobCd": "PL", "lobDescription": "Personal Lines", "displayIndicator": "Y" }, { "lobId": 201, "lobCd": "MLC", "lobDescription": "Middle & Large Commercial And Global Specialty", "displayIndicator": "Y" }, { "lobId": 202, "lobCd": "GB", "lobDescription": "Group Benefits", "displayIndicator": "Y" }]
    // return this.http.get(path);
    return observableOf(response);
  }

  public getStandardPlanGB(): Observable<any> {
    const path = AppConstant.API_HOST_ROOT;
    return this.http.get(path);
  }

}
