import {Injectable} from '@angular/core';
import {environment} from '../../../../environments/environment';

@Injectable()
export class LoggerService {

  log(...args: any[]) {
    //if in karma and flag set don't log
   /* if (window.hasOwnProperty('__karma__') && window['__karma__'].hasOwnProperty('noLogging')) {
      return;
    }*/
    //Don't log in production
    if (environment.production) {
      return;
    }
    if (console) {
      try {
        console.log.apply(this, args);
      } catch (e) {
        const message = Array.prototype.slice.apply(args).join(' ');
        console.log(message);
      }
    }
  }

  debug(...args: any[]) {
    //if in karma and flag set don't log
  /*  if (window.hasOwnProperty('__karma__') && window['__karma__'].hasOwnProperty('start')) {
      return;
    } */
    //Don't log in production
    if (environment.production) {
      return;
    }
    if (console) {
      try {
        console.log.apply(this, args);
      } catch (e) {
        const message = Array.prototype.slice.apply(args).join(' ');
        console.log(message);
      }
    }
  }

  error(...args: any[]) {
    if (console) {
      try {
        if (console.error) {
          console.error.apply(this, args);
        } else {
          console.log.apply(this, args);
        }

      } catch (e) {
        const message = Array.prototype.slice.apply(args).join(' ');
        console.log(message);
      }
    }

  }

  //TODO we should look at error and info logging
}
