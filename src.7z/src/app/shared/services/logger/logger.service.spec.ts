import {TestBed, inject} from '@angular/core/testing';

import {LoggerService} from './logger.service';

describe('LoggerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoggerService]
    });
  });

  it('should load', inject([LoggerService], (service: LoggerService) => {
    expect(service).toBeTruthy();
  }));

  it('should handle a log command', inject([LoggerService], (service: LoggerService) => {
    expect(service.log).toBeDefined();
    const test = () => {
      service.log('Testing logger - This should show up');
    };
    expect(test).not.toThrow();
  }));
  it('should handle a log command', inject([LoggerService], (service: LoggerService) => {
    expect(service.debug).toBeDefined();
    const test = () => {
      service.debug('Testing logger - This should nto show up');
    };
    expect(test).not.toThrow();
  }));
});
