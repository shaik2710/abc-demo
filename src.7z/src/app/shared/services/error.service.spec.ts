import { TestBed, inject } from '@angular/core/testing';

import { ErrorService } from './error.service';
import { ErrorMessage } from 'app/shared/model/error-message';

describe('ErrorService', () => {
  let service: ErrorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ErrorService]
    });
  });

  beforeEach(inject([ErrorService], (ErrorService) => {
    service = ErrorService;
  }));


  it('should be Injected', () => {
    expect(service).toBeTruthy();
  });

  it('should set error message setError()', (done) => {
    const errorMessage = new ErrorMessage();
    errorMessage.pageTitle = 'Test Error Title';
    errorMessage.pageMessage = 'Test Error Message';

    service.setError(errorMessage);
    service.errorMessage.subscribe(message => {
      expect(message).not.toBe(null);
      expect(message.pageTitle).toBe('Test Error Title');
      expect(message.pageMessage).toBe('Test Error Message');
      done();
    },  done.fail);
  });
});
