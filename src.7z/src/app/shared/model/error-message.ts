export class ErrorMessage {
  public pageTitle = '';
  public pageMessage = '';
  public tryAgainMsg = '';
  public returnMsg = '';
}
