export class PlanDetailsGB {
    public lineCovgCode?: string | null | undefined;
    public lineCovgDesc?: string | undefined;
    public calEligibility?: string | null | undefined;
    public pymtEligibility?: string | null | undefined;

    constructor(details?: any) {
      if (details) {
        this.lineCovgCode = details.lineCovgCode;
        this.lineCovgDesc = details.lineCovgDesc;
        this.calEligibility = details.calEligibility;
        this.pymtEligibility = details.pymtEligibility;
      }
    }
}
