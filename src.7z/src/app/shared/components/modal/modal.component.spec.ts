import {TestBed, inject} from '@angular/core/testing';
import {Renderer2} from '@angular/core';
import {ModalComponent} from './modal.component';
class MockRenderer2 {
  addClass(el: any, name: string): boolean {
    return true;
  }
  removeClass(el: string, name: string) {

  }
}

describe('ModalComponent', () => {
  let component: ModalComponent;
  let renderer: Renderer2;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ModalComponent,
        {
          provide: Renderer2,
          useClass: MockRenderer2
        }
      ],
    })
      .compileComponents();
    component = TestBed.inject(ModalComponent);
  });
  beforeEach(inject([Renderer2],
    (Renderer2: Renderer2) => {
      renderer = Renderer2;
      // set up spies
      spyOn(renderer, 'addClass');
      spyOn(renderer, 'removeClass');
    }));
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  describe('show/hide', () => {
    it('should show the modal', () => {
      component.show();
      expect(component.visible).toBeTruthy();
      expect(renderer.addClass).toHaveBeenCalled();
      expect(renderer.removeClass).not.toHaveBeenCalled();
    });
    it('should hide the modal', () => {
      component.hide();
      expect(component.visible).toBeFalsy();
      expect(renderer.addClass).not.toHaveBeenCalled();
      expect(renderer.removeClass).toHaveBeenCalled();
    });
  });
  describe('clickedOutBox', () => {
    it('should be close Popup click outside box', () => {
      const event = {
        target: {
          className: 'modal fade in'
        }
      };
      spyOn(component, 'clickedOutBox').and.callThrough();
      component.hideOnClickAnyWhere = true;
      component.clickedOutBox(event);
      component.hide();
      expect(component.clickedOutBox).toHaveBeenCalled();
    });
    it('should not be close Popup click outside box', () => {
      const event = {
        target: {
          className: 'modal fade in'
        }
      };
      spyOn(component, 'clickedOutBox').and.callThrough();
      component.hideOnClickAnyWhere = false;
      component.clickedOutBox(event);
      component.hide();
      expect(component.clickedOutBox).toHaveBeenCalled();
    });
  });
});