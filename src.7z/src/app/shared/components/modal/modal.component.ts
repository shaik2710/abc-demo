import { Component, HostListener, Input, Output, EventEmitter, ViewEncapsulation, Injector, Renderer2, OnDestroy } from '@angular/core';
import { DOCUMENT } from '@angular/common';
@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class ModalComponent implements OnDestroy {
  private document: Document;
  private renderer: Renderer2;
  @Input() showFooter = true;
  @Input() showHeader = true;
  @Input() showAlertIconHeader = false;
  @Input() showBody: any;
  @Input()
  title!: string;
  @Input() hideHeaderContent = true;
  // Setting default iconType as Success Check Mark
  @Input() iconType = 'icon-check-mark';
  @Input()
  modalId!: string;
  @Output() onClose = new EventEmitter<any>();
  public visible = false;
  public visibleAnimate = false;
  @Input()
  hideOnClickAnyWhere!: boolean;

  constructor (
    injector: Injector
  ) {
    this.document = injector.get(DOCUMENT);
    this.renderer = injector.get(Renderer2);
  }

  public show(): void {
    this.visible = true;
    // hide browser scrollbar to prevent double scrollbars when modal open
    this.renderer.addClass(this.document.body, 'modal-open');
    setTimeout(() => this.visibleAnimate = true, 100);
  }
  public hide(): void {
    this.onClose.emit({});
    this.visibleAnimate = false;
    // set browser scrollbar back to normal
    this.renderer.removeClass(this.document.body, 'modal-open');
    setTimeout(() => this.visible = false, 300);
  }
  // Keyboard Navigation Handlers
  @HostListener('document:keydown', ['$event'])
  handleKeydownEvent(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.hide();
    }
  }
  // click anywhere outside the modal box the popup(session timeout) will close
  public clickedOutBox(event: { target: any; }) {
    if (event.target.className === 'modal fade in' && this.hideOnClickAnyWhere) {
      this.hide();
    }
  }
 
  ngOnDestroy() {
    // hide modal window
    this.hide();
  }
}