import { Component, OnInit } from '@angular/core';
// import { IDropdownSettings } from 'ng-multiselect-dropdown';


@Component({
  selector: 'app-drop-down-multiselect',
  templateUrl: './drop-down-multiselect.component.html',
  styleUrls: ['./drop-down-multiselect.component.scss']
})
export class DropDownMultiselectComponent implements OnInit {
    dropdownList : Array<any> = [];
    selectedItems : any;
    dropdownSettings = {};
    
  constructor( ) {

   }
  ngOnInit(): void {
    this.dropdownList = [
      { item_id: 1, item_text: 'Broker' },
      { item_id: 2, item_text: 'Governing Master Producer' },
      { item_id: 3, item_text: 'Master producer' },
      { item_id: 4, item_text: 'producer' },
      { item_id: 5, item_text: 'Governing Master Producer' },
      { item_id: 6, item_text: 'Governing Master Producer' },
      { item_id: 7, item_text: 'Governing Master Producer' },
      { item_id: 8, item_text: 'Governing Master Producer' },
      { item_id: 9, item_text: 'Governing Master Producer' },
      { item_id: 10, item_text: 'Governing Master Producer' },
      { item_id: 11, item_text: 'Governing Master Producer' },
      { item_id: 12, item_text: 'Governing Master Producer' },
      { item_id: 13, item_text: 'Governing Master Producer' }
    ];

   this.dropdownSettings =  {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      allowSearchFilter: true
    };
  }
    onItemSelect(item: any) {
      console.log(item);
    }
    onSelectAll(items: any) {
      console.log(items);
    }

  
}