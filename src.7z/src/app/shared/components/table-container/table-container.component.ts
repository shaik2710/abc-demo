import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter
} from '@angular/core';


@Component({
  selector: 'app-table-container',
  templateUrl: './table-container.component.html',
  styleUrls: ['./table-container.component.scss'],
})
export class TableContainerComponent implements OnInit {
  @Input() public showMore = true;
  @Input() public demoGBTable: Array<any> = [{}];
  @Input() public dataTableHeader: Array<any> = [{}];
  @Input() public title?: string;
  @Output() childEvent = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
    console.log('dataTableHeader', this.dataTableHeader);
    console.log('demoGBTable', this.demoGBTable);
  }

  public open(value: any): void {
    this.childEvent.emit({
      response: value
    });
  }
}
