import { Input } from "@angular/core";
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OperatorFunction} from 'rxjs';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {debounceTime, distinctUntilChanged, map, startWith} from 'rxjs/operators';


export interface User {
  name: string;
}


const states = ['Broker', 'Governing Master Producer', 'Master producer', 'Producer'];
  
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  @Input() submitData: boolean= false;
  public model: any;

  myControl = new FormControl();
  options: User[] = [
    {name: 'Broker'},
    {name: 'Governing Master Producer'},
    {name: 'Master Producer'},
    { name: 'Producer'}
  ];
  filteredOptions!: Observable<User[]>;
  constructor(private route: Router) { }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this._filter(name) : this.options.slice())
      );
  }

  displayFn(user: User): string {
    return user && user.name ? user.name : '';
  }

  private _filter(name: string): User[] {
    const filterValue = name.toLowerCase();

    return this.options.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }
  search: OperatorFunction<string, readonly string[]> = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 2 ? []
        : states.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )
  btnClick=  () => {
    this.route.navigateByUrl('/specialdealmainpage');
};
}