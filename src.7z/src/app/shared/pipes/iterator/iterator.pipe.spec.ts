import { IteratorPipe } from './iterator.pipe';

describe('IteratorPipe', () => {
  it('create an instance', () => {
    const pipe = new IteratorPipe();
    expect(pipe).toBeTruthy();
  });
});
