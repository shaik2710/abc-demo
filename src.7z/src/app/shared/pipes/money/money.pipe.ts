import { Pipe, PipeTransform } from '@angular/core';

/************************
* usage:
* let some = 11;
* {{some | myMoney}}
* output: $11.00
* {{some | myMoney:''}} // sometimes we don't need $ symbol
* output: 11.00
* let some = 11.123;
* {{some | myMoney:'£'}}
* output: £11.12
* for credits -
* let some = 12.32
* {{some | myMoney:'$':true}}
* output: ($12.32)
* ***********************/

@Pipe({
    name: 'money'
})

export class MoneyPipe implements PipeTransform {

    public transform(value: any, symbol?: string, credit?: boolean): string {
        symbol = symbol === '' ? symbol : (symbol || '$');
        let negativeSign = '';
        value = parseFloat(value);
        if (isNaN(value)) {
            return '';
        }
        if (value < 0) {
            negativeSign = '-';
            value = Math.abs(value);
        }

        const [integer, decimal] = (value.toFixed(2)).split('.');
        const integerLength = integer.length, remainder = integerLength % 3;
        // every 3 digits add a com
        const loopCount = (integerLength - remainder) / 3;

        const threeNumbers = [];
        // put each 3-digits part to an array so i can join them with ,
        for (let i = 0, j = 0; i < loopCount; i++ , j -= 3) {
            threeNumbers.unshift(integer.substr(j - 3, 3));
        }
        // integer.substr(0, 0) will return a empty ''
        if (remainder !== 0) {
            threeNumbers.unshift(integer.substr(0, remainder));
        }
        if (credit || negativeSign === '-' ) {
            return '(' + symbol + threeNumbers.join(',') + '.' + decimal + ')';
        } else {
            return symbol + threeNumbers.join(',') + '.' + decimal;
        }
    }
    public format(value: any): string {
       return '$' + Math.abs(value);
    }

    // converts -0.09999999 to 0.09 without rounding
    public formatTo2Decimal(value: number): number {
        return Math.floor(Math.abs(value) * 100) / 100;
    }
    
}


