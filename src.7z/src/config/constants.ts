export class AppConstant {
  // environment API uris
  static API_HOST_ROOT_PROD = '';
  static API_HOST_ROOT_TEST = 'https://qa-agency-comp-api.paas02.thehartford.com/agency-comp-api';
  static API_HOST_ROOT_DEV = 'https://dev-agency-comp-api.paas02.thehartford.com/agency-comp-api';
  // use this proxy's settings for localhost testing
  static API_LOCAL_PROXY_HOST = 'dev-business';
  // static API values
  static API_CLIENT_ID = '';
  static API_VERSION = '';
  static SCOPE = '';
  static APP_NAME = 'my-act';
  static ERROR_PAGE_URL = '/error';
  static CANCEL_REDIRECT_URL = '';
  static RETURN_TO_POLICIES_URL = '';
  static ANALYTICS_PROD_URL = '';
  static ANALYTICS_TEST_URL = '';
  static ACT_ROOT_PATH = '/home';

  // Employee Impersonation flow error message
  static IMPERSONATION_ERROR_MSG = '';

  // Requestor object
  static REQUESTOR = {
    firstName: '',
    lastName: '',
    email: ''
  };

  static getHost() {
    return window.location.hostname.split('.')[0] || '';
  }
  /**
   * returns true if host is local env
   */
  static isHostLocal(): boolean {
    const host = AppConstant.getHost();
    if (host === 'local' || host === 'localhost') {
      return true;
    }
    return false;
  }

  // get the host name from the browser window
  static getHostname() {
    const host = AppConstant.getHost();
    if (host === 'local' || host === 'localhost') {
      // use active proxy for localhost
      return AppConstant.API_LOCAL_PROXY_HOST;
    }
    return host;
  }
   // get current origin
   static getCurrentOrigin() {
    return window.location.origin;
  }
  // Determine the target environment for tealium
  static get TARGET_ENV_TEALIUM(): string {
    const host = AppConstant.getHost().toLowerCase();
    switch (host) {
      case 'dev-business':
      case 'int-business':
      case 'int2-business':
        return 'dev';
      case 'ltq-business':
      case 'qa-business':
      case 'qa2-business':
      case 'qa3-business':
        return 'qa';
      case 'business':
        return 'prod';
      default:
        return 'qa';
    }
  }
  // determines test/prod values to use based on environment
  static get ENV(): string {
    const host = AppConstant.getHostname().toLowerCase();
    switch (host) {
      case ('dev-business'):
      case ('int-business'):
      case ('int2-business'):
        return 'dev';
      case 'ltq-business':
      case 'qa-business':
      case 'qa2-business':
      case 'qa3-business':
        return 'test';
      case 'business':
        return 'prod';
      default:
        return 'test';
    }
  }
  // some DP environments require a target param passed w/the request
  static get TARGET_ENV(): string {
    const host = AppConstant.getHostname().toLowerCase();
    switch (host) {
      case 'ltq-business':
        return 'ltq';
      case 'qa2-business':
        return 'qa2';
      case 'qa3-business':
        return 'qa3';
      case 'int-business':
        return 'int';
      case 'int2-business':
        return 'int2';
        case 'qa-business':
          return 'qa';
      case 'dev-business':
        return 'dev';
      default:
        return '';
    }
  }

 
  // For documents : ECM has INT, QA, PTE and PROD env's
  // for dev/int/int2 we need to send target_env as INT
  // for ltq/qa we need to send qa as target_env or we can skip sending target_env as default is qa for ltq/qa
  // for qa2 we need to send target_env as qa2 as it needs to be validated against CIAM PTE env
  static get TARGET_ENV_DOC(): string {
    if (AppConstant.ENV === 'dev') {
      return 'int';
    } else if (AppConstant.TARGET_ENV === 'qa2') {
      return 'qa2';
    } else {
      return '';
    }
  }
  static get API_HOST_ROOT(): string {
    switch (AppConstant.ENV) {
      case ('prod'):
        return AppConstant.API_HOST_ROOT_PROD;
      case ('test'):
        return AppConstant.API_HOST_ROOT_TEST;
      default:
        return AppConstant.API_HOST_ROOT_DEV;
    }
  }
  static get ANALYTICS_LOCATION_URL(): string {
    if (AppConstant.ENV === 'prod') {
      return AppConstant.ANALYTICS_PROD_URL;
    } else {
      return AppConstant.ANALYTICS_TEST_URL;
    }
  }
  static get JWT_HOST(): string {
    return AppConstant.API_HOST_ROOT + '/authorize';
  }
  static get API_HOST(): string {
    return AppConstant.API_HOST_ROOT + '/business/';
  }
  static get API_HOST_CLAIM(): string {
    return AppConstant.API_HOST_ROOT + '/ent/';
  }
  static get API_HOST_DOCUMENTS(): string {
    return AppConstant.API_HOST_ROOT + '/cl/';
  }
  static get API_HOST_EDGE(): string {
    return AppConstant.API_HOST_ROOT + '/cl/endorsements/';
  }
  static get API_HOST_EBC(): string {
    if (AppConstant.isHostLocal()) {
      return 'http://local.thehartford.com:4200/agent/';
    }
    return AppConstant.API_HOST_ROOT + '/agent/';
  }

  // For profile page CIAM redirection we will get CIAM URL from this function
  static get CIAM_TARGET_URL(): any {
    const host = AppConstant.getHostname().toLowerCase();
    // TODO : Add more env specific URL's as and when we get them from CIAM team
    switch (host) {
      case 'dev-business':
        return { rootUrl : 'https://account-dev.thehartford.com', appId : 'OBSC'};
      case 'int-business':
        return { rootUrl : 'https://account-dev.thehartford.com', appId : 'OBSC_INT'};
      case 'int2-business':
        return { rootUrl : 'https://account-dev.thehartford.com', appId : 'OBSC_INT2'};
      case 'qa2-business':
        return { rootUrl : 'https://account-pte.thehartford.com', appId : 'OBSC'};
      case 'qa3-business':
        return { rootUrl : 'https://account-qa.thehartford.com', appId : 'OBSC_QA3'};
      case 'qa-business':
        return { rootUrl : 'https://account-qa.thehartford.com', appId : 'OBSC'};
      case 'ltq-business':
        return { rootUrl : 'https://account-qa.thehartford.com', appId : 'OBSC_LTQ'};
      default:
        return { rootUrl : 'https://account.thehartford.com', appId : 'OBSC'};
    }
  }

  static get ACT_APP_CONFIG(): any {
    return {
      apiClientId: AppConstant.API_CLIENT_ID,
      apiAuthorize: AppConstant.JWT_HOST,
      apiRoot: AppConstant.API_HOST_ROOT,
      apiRootEdge: AppConstant.API_HOST_EDGE,
      apiVersion: AppConstant.API_VERSION,
      targetEnv: AppConstant.TARGET_ENV,
      scopes: [AppConstant.SCOPE],
      appName: AppConstant.APP_NAME,
      errorPageUrl: AppConstant.ERROR_PAGE_URL,
      cancelRedirectUrl: AppConstant.CANCEL_REDIRECT_URL,
      requestor: AppConstant.REQUESTOR,
      returnToPoliciesUrl: AppConstant.RETURN_TO_POLICIES_URL,
      rootPath: AppConstant.ACT_ROOT_PATH,
      featuresFlag: this.getFeaturesFlag()
    }
  }
  /**
   * returns features flag
   */
  static getFeaturesFlag(): any {
    // const features = JSON.parse(JSON.stringify(featuresConfig['default'] || featuresConfig || null));
    // if (features && features.features) {
    //   return {
    //     wcPropertyChange: features.features.wcPropertyChange,
    //     wcLiabilityChange: features.features.wcLiabilityChange,
    //     wcWOSChange: features.features.wcWOSChange,
    //     wcPayrollChange: features.features.wcPayrollChange
    //   };
    // }
    // return null;
  }


}

