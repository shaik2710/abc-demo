import { Injectable } from '@angular/core';


export interface IAppConfig {
  features: {
    [name: string]: boolean;
  };
}

@Injectable()
export class AppConfig {
  static settings: IAppConfig;

  /**
   * Sets config properties from static config.json file.
   * May also be loaded via http service as long as services returns a Promise
   * @returns {Promise<void>}
   */
  load() {
    return new Promise<void>((resolve) => {
      // set imported json to settings config 
      resolve();
    });
  }
}