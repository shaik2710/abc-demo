/** @deprecated Since v11.0, unused by the Angular tooling */
export declare function isFile(filePath: string): boolean;
/** @deprecated Since v11.0, unused by the Angular tooling */
export declare function isDirectory(filePath: string): boolean;
