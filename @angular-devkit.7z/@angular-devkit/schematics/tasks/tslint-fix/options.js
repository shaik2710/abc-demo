"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TslintFixName = void 0;
/** @deprecated since version 11. Use `ng lint --fix` directly instead. */
exports.TslintFixName = 'tslint-fix';
