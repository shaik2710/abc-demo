export declare function checkPort(port: number, host: string): Promise<number>;
