export declare function findAllNodeModules(from: string, root?: string): string[];
