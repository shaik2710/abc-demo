export declare function isWebpackFiveOrHigher(): boolean;
export declare function withWebpackFourOrFive<T, R>(webpackFourValue: T, webpackFiveValue: R): any;
