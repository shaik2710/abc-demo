declare const _default: import("webpack").loader.Loader;
export default _default;
