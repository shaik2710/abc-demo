import { Configuration } from 'webpack';
import { WebpackConfigOptions } from '../../utils/build-options';
export declare function getWorkerConfig(wco: WebpackConfigOptions): Configuration;
