import { Configuration } from 'webpack';
import { WebpackConfigOptions } from '../../utils/build-options';
export declare function getCommonConfig(wco: WebpackConfigOptions): Configuration;
